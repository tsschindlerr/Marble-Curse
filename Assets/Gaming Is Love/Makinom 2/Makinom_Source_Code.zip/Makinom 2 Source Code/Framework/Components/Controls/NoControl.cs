
using UnityEngine;
using System.Collections;

namespace GamingIsLove.Makinom.Components
{
	[AddComponentMenu("Makinom/Controls/No Control")]
	public class NoControl : MonoBehaviour
	{

	}
}
