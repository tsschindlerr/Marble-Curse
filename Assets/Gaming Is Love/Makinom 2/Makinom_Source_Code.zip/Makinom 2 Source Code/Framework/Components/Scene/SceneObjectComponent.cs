
using UnityEngine;
using GamingIsLove.Makinom.UI;
using System.Collections.Generic;

namespace GamingIsLove.Makinom.Components
{
	[AddComponentMenu("Makinom/Scenes/Scene Object")]
	public class SceneObjectComponent : BaseConditionComponent, IContent, ITypeContent, IPortraitContent,
		ICustomTextCodes, IHUDUpdate, ISerializationCallbackReceiver
	{
		[System.NonSerialized]
		public Settings settings = new Settings();

		[SerializeField]
		[HideInInspector]
		protected ComponentDataFile serialize_setting;


		// ingame
		protected bool isInitialized = false;

		protected SceneObject sceneObject;

		protected SceneObjectTypeWrapper sceneObjectType;

		protected bool cursorChanged = false;

		public virtual bool SceneObjectActive
		{
			get
			{
				return this.CheckConditions(Maki.Game.Player.GameObject, false);
			}
		}

		protected Notify updateHUDHandler;
		public event Notify UpdateHUD
		{
			add { this.updateHUDHandler += value; }
			remove { this.updateHUDHandler -= value; }
		}


		/*
		============================================================================
		Auto start functions
		============================================================================
		*/
		protected override void OnEnable()
		{
			if(Maki.Initialized)
			{
				this.Init();
			}
		}

		protected virtual void OnDisable()
		{
			this.CursorExit();
		}

		protected override void Start()
		{
			this.Init();
		}

		protected virtual void Init()
		{
			if(!this.isInitialized)
			{
				this.isInitialized = true;
				bool check = true;
				if(ConditionAutoCheckType.Start == this.conditionSetting.autoCheckType)
				{
					check = this.CheckAutoDestroy();
				}
				if(check)
				{
					this.ResetSceneObject();
				}
			}
		}

		public virtual void ResetSceneObject()
		{
			if(this.settings.custom)
			{
				this.LoadSceneObject(this.settings.customSceneObject);
			}
			else
			{
				this.LoadSceneObject(this.settings.sceneObject.StoredAsset != null ? this.settings.sceneObject.StoredAsset.Settings : null);
			}
		}

		public virtual void LoadSceneObject(SceneObject sceneObject)
		{
			if(sceneObject != null)
			{
				this.sceneObject = sceneObject;
				if(this.sceneObject.TypeData != null)
				{
					this.sceneObjectType = new SceneObjectTypeWrapper(this.sceneObject.TypeData, this);
				}
				if(this.sceneObject.ownObjectVariables)
				{
					if(this.sceneObject.useObjectVariables)
					{
						this.sceneObject.objectVariables.AddComponent(this.gameObject);
					}
				}
				else if(this.sceneObjectType != null &&
					this.sceneObjectType.Settings.useObjectVariables)
				{
					this.sceneObjectType.Settings.objectVariables.AddComponent(this.gameObject);
				}
				if(this.updateHUDHandler != null)
				{
					this.updateHUDHandler();
				}
			}
		}


		/*
		============================================================================
		Cursor functions
		============================================================================
		*/
		public virtual void CursorEnter()
		{
			if(this.CheckConditions(Maki.Game.Player.GameObject, false) &&
				this.sceneObject != null)
			{
				this.cursorChanged = this.sceneObject.Cursor.SetCursor();
			}
		}

		public virtual void CursorExit()
		{
			if(this.cursorChanged)
			{
				this.cursorChanged = false;
				if(this.sceneObject != null)
				{
					this.sceneObject.Cursor.ResetCursor();
				}
			}
		}


		/*
		============================================================================
		Content functions
		============================================================================
		*/
		public virtual VariableHandler GetUsedHandler()
		{
			if(this.sceneObject.useObjectVariableTextCodes)
			{
				ObjectVariablesComponent objVariables = ComponentHelper.
					GetInChildren<ObjectVariablesComponent>(this.gameObject);
				if(objVariables != null)
				{
					return objVariables.Handler;
				}
			}
			return Maki.Game.Variables;
		}

		public virtual void ReplaceCustomTextCodes(ref string text, VariableHandler handler)
		{
			for(int i = 0; i < this.settings.customTextCode.Length; i++)
			{
				this.settings.customTextCode[i].Replace(ref text, handler);
			}
			if(this.sceneObject != null)
			{
				this.sceneObject.ReplaceCustomTextCodes(ref text, handler);
			}
			if(this.sceneObjectType != null)
			{
				this.sceneObjectType.ReplaceCustomTextCodes(ref text, handler);
			}
		}

		public virtual int ID
		{
			get
			{
				return this.sceneObject != null ?
					this.sceneObject.ID : -1;
			}
		}

		public virtual string GetName()
		{
			if(this.sceneObject != null)
			{
				string name = this.sceneObject.GetName();
				VariableHandler handler = this.GetUsedHandler();
				this.ReplaceCustomTextCodes(ref name, handler);
				return TextHelper.ReplaceVariables(name, handler);
			}
			return "";
		}

		public virtual string GetShortName()
		{
			if(this.sceneObject != null)
			{
				string shortName = this.sceneObject.GetShortName();
				VariableHandler handler = this.GetUsedHandler();
				this.ReplaceCustomTextCodes(ref shortName, handler);
				return TextHelper.ReplaceVariables(shortName, handler);
			}
			return "";
		}

		public virtual string GetDescription()
		{
			if(this.sceneObject != null)
			{
				string description = this.sceneObject.GetDescription();
				VariableHandler handler = this.GetUsedHandler();
				this.ReplaceCustomTextCodes(ref description, handler);
				return TextHelper.ReplaceVariables(description, handler);
			}
			return "";
		}

		public virtual Sprite GetIconSprite()
		{
			return this.sceneObject != null ?
				this.sceneObject.GetIconSprite() : null;
		}

		public virtual Texture GetIconTexture()
		{
			return this.sceneObject != null ?
				this.sceneObject.GetIconTexture() : null;
		}

		public virtual string GetIconTextCode()
		{
			return this.sceneObject != null ?
				this.sceneObject.GetIconTextCode() : null;
		}

		public virtual string GetCustomContent(string contentKey)
		{
			if(this.sceneObject != null)
			{
				string content = this.sceneObject.GetCustomContent(contentKey);
				VariableHandler handler = this.GetUsedHandler();
				this.ReplaceCustomTextCodes(ref content, handler);
				return TextHelper.ReplaceVariables(content, handler);
			}
			return "";
		}

		public virtual IPortrait GetPortrait(PortraitTypeAsset portraitType)
		{
			return this.sceneObject != null ?
				this.sceneObject.GetPortrait(portraitType) : null;
		}

		public virtual IContent GetTypeContent()
		{
			return this.sceneObjectType;
		}

		public virtual bool NoTooltip
		{
			get { return this.sceneObject != null && this.sceneObject.noTooltip; }
		}

		public virtual SceneObject SceneObject
		{
			get { return this.sceneObject; }
		}


		/*
		============================================================================
		Gizmo functions
		============================================================================
		*/
		protected virtual void OnDrawGizmos()
		{
			Gizmos.DrawIcon(transform.position, "/GamingIsLove/Makinom/Components/SceneObjectComponent Icon.png");
		}


		/*
		============================================================================
		Serialization functions
		============================================================================
		*/
		public override void OnBeforeSerialize()
		{
			base.OnBeforeSerialize();
			this.serialize_setting = this.settings.GetData().GetComponentDataFile("settings", false);
		}

		public override void OnAfterDeserialize()
		{
			base.OnAfterDeserialize();
			if(this.serialize_setting != null)
			{
				this.settings.SetData(this.serialize_setting.ToDataObject());
				this.serialize_setting = null;
			}
		}


		/*
		============================================================================
		Settings class
		============================================================================
		*/
		public class Settings : BaseData
		{
			[EditorHelp("Custom Scene Object", "Create a custom scene object and define it's content in this component.\n" +
				"If disabled, uses a scene object set up in the editor.")]
			public bool custom = false;

			[EditorCondition("custom", true)]
			[EditorAutoInit]
			public SceneObject customSceneObject;

			[EditorHelp("Scene Object", "Select the scene object that will be used.", "")]
			[EditorElseCondition]
			public AssetSelection<SceneObjectAsset> sceneObject = new AssetSelection<SceneObjectAsset>();

			[EditorArray("Add Text Code", "Adds a custom text code.", "",
				"Remove", "Removes this custom text code.", "", enbox=true)]
			[EditorEndCondition]
			public CustomTextCode[] customTextCode = new CustomTextCode[0];

			public Settings()
			{

			}
		}
	}
}
