
using UnityEngine;
using GamingIsLove.Makinom.Schematics;
using System.Collections.Generic;

namespace GamingIsLove.Makinom.Components
{
	[AddComponentMenu("Makinom/Machines/Render Machine")]
	public class RenderMachineComponent : BaseMachineComponent, ISerializationCallbackReceiver
	{
		[System.NonSerialized]
		public Settings settings = new Settings();

		[SerializeField]
		[HideInInspector]
		protected ComponentDataFile serialize_setting;

		public override bool CanRestart(GameObject startingObject)
		{
			return this.settings.startSetting.CanStart(this, startingObject);
		}


		/*
		============================================================================
		Renderer functions
		============================================================================
		*/
		protected virtual void OnBecameInvisible()
		{
			if(this.settings.startSetting.isBecameInvisible &&
				this.settings.startSetting.CanStart(this, Maki.Game.Player.GameObject))
			{
				this.StartMachine(Maki.Game.Player.GameObject,
					this.startVariableSetting.HasStartVariables ?
						this.startVariableSetting.GetStartVariables(
							this.startVariableSetting.NeedsCall ?
								new DataCall(this.gameObject, Maki.Game.Player.GameObject,
									this.assetSetting.inputID.GetInputID(this.gameObject, Maki.Game.Player.GameObject)) : null) :
						null);
			}
		}

		protected virtual void OnBecameVisible()
		{
			if(this.settings.startSetting.isBecameVisible &&
				this.settings.startSetting.CanStart(this, Maki.Game.Player.GameObject))
			{
				this.StartMachine(Maki.Game.Player.GameObject,
					this.startVariableSetting.HasStartVariables ?
						this.startVariableSetting.GetStartVariables(
							this.startVariableSetting.NeedsCall ?
								new DataCall(this.gameObject, Maki.Game.Player.GameObject,
									this.assetSetting.inputID.GetInputID(this.gameObject, Maki.Game.Player.GameObject)) : null) :
						null);
			}
		}

		protected virtual void OnPreCull()
		{
			if(this.settings.startSetting.isPreCull &&
				this.settings.startSetting.CanStart(this, Maki.Game.Player.GameObject))
			{
				this.StartMachine(Maki.Game.Player.GameObject,
					this.startVariableSetting.HasStartVariables ?
						this.startVariableSetting.GetStartVariables(
							this.startVariableSetting.NeedsCall ?
								new DataCall(this.gameObject, Maki.Game.Player.GameObject,
									this.assetSetting.inputID.GetInputID(this.gameObject, Maki.Game.Player.GameObject)) : null) :
						null);
			}
		}

		protected virtual void OnWillRenderObject()
		{
			if(this.settings.startSetting.isWillRenderObject &&
				this.settings.startSetting.CanStart(this, Maki.Game.Player.GameObject))
			{
				this.StartMachine(Maki.Game.Player.GameObject,
					this.startVariableSetting.HasStartVariables ?
						this.startVariableSetting.GetStartVariables(
							this.startVariableSetting.NeedsCall ?
								new DataCall(this.gameObject, Maki.Game.Player.GameObject,
									this.assetSetting.inputID.GetInputID(this.gameObject, Maki.Game.Player.GameObject)) : null) :
						null);
			}
		}

		protected virtual void OnRenderObject()
		{
			if(this.settings.startSetting.isRenderObject &&
				this.settings.startSetting.CanStart(this, Maki.Game.Player.GameObject))
			{
				this.StartMachine(Maki.Game.Player.GameObject,
					this.startVariableSetting.HasStartVariables ?
						this.startVariableSetting.GetStartVariables(
							this.startVariableSetting.NeedsCall ?
								new DataCall(this.gameObject, Maki.Game.Player.GameObject,
									this.assetSetting.inputID.GetInputID(this.gameObject, Maki.Game.Player.GameObject)) : null) :
						null);
			}
		}


		/*
		============================================================================
		Camera only functions
		============================================================================
		*/
		protected virtual void OnPreRender()
		{
			if(this.settings.startSetting.isPreRender &&
				this.settings.startSetting.CanStart(this, Maki.Game.Player.GameObject))
			{
				this.StartMachine(Maki.Game.Player.GameObject,
					this.startVariableSetting.HasStartVariables ?
						this.startVariableSetting.GetStartVariables(
							this.startVariableSetting.NeedsCall ?
								new DataCall(this.gameObject, Maki.Game.Player.GameObject,
									this.assetSetting.inputID.GetInputID(this.gameObject, Maki.Game.Player.GameObject)) : null) :
						null);
			}
		}

		protected virtual void OnPostRender()
		{
			if(this.settings.startSetting.isPostRender &&
				this.settings.startSetting.CanStart(this, Maki.Game.Player.GameObject))
			{
				this.StartMachine(Maki.Game.Player.GameObject,
					this.startVariableSetting.HasStartVariables ?
						this.startVariableSetting.GetStartVariables(
							this.startVariableSetting.NeedsCall ?
								new DataCall(this.gameObject, Maki.Game.Player.GameObject,
									this.assetSetting.inputID.GetInputID(this.gameObject, Maki.Game.Player.GameObject)) : null) :
						null);
			}
		}


		/*
		============================================================================
		Editor functions
		============================================================================
		*/
		protected virtual void OnDrawGizmos()
		{
			Gizmos.DrawIcon(transform.position, "/GamingIsLove/Makinom/Components/RenderMachineComponent Icon.png");
		}


		/*
		============================================================================
		Serialization functions
		============================================================================
		*/
		public override void OnBeforeSerialize()
		{
			base.OnBeforeSerialize();
			this.serialize_setting = this.settings.GetData().GetComponentDataFile("settings", false);
		}

		public override void OnAfterDeserialize()
		{
			base.OnAfterDeserialize();
			if(this.serialize_setting != null)
			{
				this.settings.SetData(this.serialize_setting.ToDataObject());
				this.serialize_setting = null;
			}
		}


		/*
		============================================================================
		Settings class
		============================================================================
		*/
		public class Settings : BaseData
		{
			[EditorFoldout("Start Settings", "Define the start settings of this machine.", "")]
			[EditorEndFoldout]
			public RenderMachineStartSetting startSetting = new RenderMachineStartSetting();

			public Settings()
			{

			}
		}
	}
}
