﻿
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	[EditorSettingInfo("Game Object", "A game object is the origin.")]
	public class GameObjectRaycastType<T> : BaseRaycastType<T> where T : IObjectSelection, new()
	{
		public T usedObject = new T();

		[EditorSeparator]
		[EditorHelp("Distance", "The distance the raycast will use.\n" +
			"If nothing is hit within this distance, no target will be found.", "")]
		public FloatValue<T> distance = new FloatValue<T>(100.0f);

		[EditorSeparator]
		[EditorHelp("Use Cursor Position", "Use the current cursor/mouse position as target for the raycast.", "")]
		public bool useCursorPosition = false;

		[EditorSeparator]
		[EditorTitleLabel("Direction")]
		[EditorLabel("The direction in local space the raycast will be sent to.")]
		[EditorCondition("useCursorPosition", false)]
		[EditorEndCondition]
		public Vector3Value<T> direction = new Vector3Value<T>(Vector3Direction.Forward);

		public GameObjectRaycastType()
		{

		}

		public override string ToString()
		{
			return "Game Object";
		}

		protected virtual Ray GetRay(ref bool found, IDataCall call, RaycastType raycastType,
			int layerMask, Vector3 originOffset, Camera camera, float distance)
		{
			GameObject gameObject = this.usedObject.GetObject(call);
			if(gameObject != null)
			{
				found = true;
				Vector3 origin = gameObject.transform.position + originOffset;
				return new Ray(origin, this.useCursorPosition ?
					VectorHelper.GetDirection(origin,
						VectorHelper.ScreenToScenePosition(
							VectorHelper.GetMousePosition(originOffset),
							distance, raycastType, layerMask, camera)) :
					gameObject.transform.TransformDirection(this.direction.GetValue(call)));
			}
			return new Ray(Vector3.zero, Vector3.forward);
		}

		public override RaycastOutput Raycast(IDataCall call, RaycastType raycastType,
			int layerMask, Vector3 originOffset, bool storeCoords, Camera camera)
		{
			bool found = false;
			float tmpDistance = this.distance.GetValue(call);
			Ray ray = this.GetRay(ref found, call, raycastType, layerMask, originOffset, camera, tmpDistance);

			if(found)
			{
				RaycastOutput hit = null;
				if(RaycastHelper.Raycast(raycastType,
					ray.origin, ray.direction, out hit, tmpDistance, layerMask, storeCoords))
				{
					return hit;
				}
			}
			return null;
		}

		public override List<RaycastOutput> RaycastAll(IDataCall call, RaycastType raycastType,
			int layerMask, Vector3 originOffset, bool storeCoords, Camera camera)
		{
			bool found = false;
			float tmpDistance = this.distance.GetValue(call);
			Ray ray = this.GetRay(ref found, call, raycastType, layerMask, originOffset, camera, tmpDistance);

			if(found)
			{
				return RaycastHelper.RaycastAll(raycastType, ray.origin, ray.direction, tmpDistance, layerMask, storeCoords);
			}
			return null;
		}
	}
}
