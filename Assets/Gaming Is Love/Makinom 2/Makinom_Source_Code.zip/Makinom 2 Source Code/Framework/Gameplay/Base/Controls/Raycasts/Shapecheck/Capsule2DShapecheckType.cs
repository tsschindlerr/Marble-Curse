﻿
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	[EditorSettingInfo("Capsule 2D", "Checks if colliders fall within a capsule (uses 'Collider2D').")]
	public class Capsule2DShapecheckType<T> : BaseShapecheckType<T> where T : IObjectSelection, new()
	{
		[EditorHelp("Capsule Direction", "Select the direction of the shape cast.")]
		public CapsuleDirection2D direction = CapsuleDirection2D.Vertical;

		[EditorSeparator]
		[EditorTitleLabel("Origin")]
		[EditorLabel("The point in 2D space where the shape originates.\n" +
			"Ignores the Z-axis.")]
		public Vector3Value<T> origin = new Vector3Value<T>();

		[EditorSeparator]
		[EditorTitleLabel("Size")]
		[EditorLabel("The size of the shape.\n" +
			"Ignores the Z-axis.")]
		public Vector3Value<T> size = new Vector3Value<T>();

		[EditorHelp("Angle", "The angle of the shape (in degrees).", "")]
		[EditorSeparator]
		[EditorTitleLabel("Angle")]
		public FloatValue<T> angle = new FloatValue<T>();


		// depth
		[EditorHelp("Minimum Depth", "Only include objects with a Z coordinate (depth) greater than this value.", "")]
		[EditorSeparator]
		[EditorTitleLabel("Minimum Depth")]
		public FloatValue<T> minDepth = new FloatValue<T>(typeof(FloatValue_NegativeInfinityType<T>));

		[EditorHelp("Maximum Depth", "Only include objects with a Z coordinate (depth) less than this value.", "")]
		[EditorSeparator]
		[EditorTitleLabel("Maximum Depth")]
		public FloatValue<T> maxDepth = new FloatValue<T>(typeof(FloatValue_InfinityType<T>));

		public Capsule2DShapecheckType()
		{

		}

		public override string ToString()
		{
			return "Capsule 2D";
		}

		public override bool Is2D
		{
			get { return true; }
		}

		public override bool Check(IDataCall call, int layerMask)
		{
			return Physics2D.OverlapCapsule(
				this.origin.GetValue(call), this.size.GetValue(call), this.direction,
				this.angle.GetValue(call), layerMask,
				this.minDepth.GetValue(call), this.maxDepth.GetValue(call)) != null;
		}

		public override Collider Overlap(IDataCall call, int layerMask)
		{
			return null;
		}

		public override Collider[] OverlapAll(IDataCall call, int layerMask)
		{
			return null;
		}

		public override Collider2D Overlap2D(IDataCall call, int layerMask)
		{
			return Physics2D.OverlapCapsule(
				this.origin.GetValue(call), this.size.GetValue(call), this.direction,
				this.angle.GetValue(call), layerMask,
				this.minDepth.GetValue(call), this.maxDepth.GetValue(call));
		}

		public override Collider2D[] OverlapAll2D(IDataCall call, int layerMask)
		{
			return Physics2D.OverlapCapsuleAll(
				this.origin.GetValue(call), this.size.GetValue(call), this.direction,
				this.angle.GetValue(call), layerMask,
				this.minDepth.GetValue(call), this.maxDepth.GetValue(call));
		}
	}
}
