
using UnityEngine;
using GamingIsLove.Makinom.Reflection;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	public class InputKeyAsset : MakinomGenericAsset<InputKey>
	{
		public InputKeyAsset()
		{

		}

		public override string DataName
		{
			get { return "Input Key"; }
		}
	}

	[TextCode(typeof(InputKeyAsset), "Input Key", "<inputkey.",
		new string[] { "<inputkey.name=", "<inputkey.shortname=", "<inputkey.description=", "<inputkey.icon=", "<inputkey.custom guid=\"" },
		new string[] { "Name", "Short Name", "Description", "Icon", "Custom Content" })]
	[EditorLanguageExport("InputKey")]
	public class InputKey : BaseLanguageData, IContent
	{
		[EditorHelp("In Fixed Update", "This input key will store input for fixed update ticks.\n" +
			"Since fixed update isn't bound to the current frame, it'll lose down and up input events of the frame.\n" +
			"Storing the input of a frame for fixed update allows using input in machines running in 'Fixed Update'.", "")]
		[EditorFoldout("Key Settings", "Set where this key will get it's input from.\n" +
			"Despite the selected input origin, all keys can get input from HUDs.", "")]
		[EditorEndFoldout]
		public bool inFixedUpdate = true;


		// input ID setup
		[EditorArray("Add Input ID", "Adds an input setup for an input ID.", "",
			"Remove", "Removes this input ID.", "", isCopy = true, isMove = true, noRemoveCount = 1,
			foldout = true, foldoutText = new string[] {
				"Input ID Setting", "Define the input ID and assigned input settings.", ""
		}, callbackRemove = "key:removed")]
		public InputIDKey[] input = new InputIDKey[] { new InputIDKey() };


		// in-game
		protected bool isCollection = false;

		protected bool blocked = false;

		public InputKey()
		{

		}

		public InputKey(string name) : base(name)
		{

		}

		public InputKey(string name, KeyCode positiveKey, KeyCode negativeKey, InputHandling handling) : base(name)
		{
			this.input = new InputIDKey[] { new InputIDKey(positiveKey, negativeKey, handling) };
		}

		protected Notify resetHandler;
		public virtual event Notify OnReset
		{
			add { this.resetHandler += value; }
			remove { this.resetHandler -= value; }
		}

		public virtual void CheckIsCollection()
		{
			this.isCollection = false;
			for(int i = 0; i < this.input.Length; i++)
			{
				if(this.input[i].settings.IsCollection)
				{
					this.isCollection = true;
					break;
				}
			}
		}

		public virtual InputIDKey GetHeldKey()
		{
			if(!this.blocked)
			{
				for(int i = 0; i < this.input.Length; i++)
				{
					if(this.input[i].HoldTimeout > 0)
					{
						return this.input[i];
					}
					else
					{
						InputIDKey key = this.input[i].settings.GetHeldKey();
						if(key != null)
						{
							return key;
						}
					}
				}
			}
			return null;
		}


		/*
		============================================================================
		Input functions
		============================================================================
		*/
		public virtual void Tick()
		{
			if(!this.blocked)
			{
				for(int i = 0; i < this.input.Length; i++)
				{
					this.input[i].Tick(this.realID);
				}
			}
		}

		public virtual void TickCollection()
		{
			if(!this.blocked &&
				this.isCollection)
			{
				for(int i = 0; i < this.input.Length; i++)
				{
					this.input[i].TickCollection(this.realID);
				}
			}
		}

		public virtual void TickCollection2ndPass()
		{
			if(!this.blocked &&
				this.isCollection)
			{
				for(int i = 0; i < this.input.Length; i++)
				{
					if(!this.input[i].InputReceived)
					{
						this.input[i].TickCollection(this.realID);
					}
				}
			}
		}

		public virtual bool GetAnyButton()
		{
			for(int i = 0; i < this.input.Length; i++)
			{
				if(this.input[i].GetButton())
				{
					return true;
				}
			}
			return false;
		}

		public virtual int GetAnyButtonInputID()
		{
			for(int i = 0; i < this.input.Length; i++)
			{
				if(this.input[i].GetButton())
				{
					return this.input[i].inputID;
				}
			}
			return -1;
		}

		public static bool GetButton(InputKeyAsset asset)
		{
			return asset != null && asset.Settings.GetButton(Maki.Control.InputID);
		}

		public static bool GetButton(InputKeyAsset asset, int inputID)
		{
			return asset != null && asset.Settings.GetButton(inputID);
		}

		public virtual bool GetButton(int inputID)
		{
			for(int i = 0; i < this.input.Length; i++)
			{
				if(this.input[i].inputID == inputID)
				{
					return this.input[i].GetButton();
				}
			}
			return false;
		}

		public static float GetAxis(InputKeyAsset asset)
		{
			return asset != null ? asset.Settings.GetAxis(Maki.Control.InputID) : 0;
		}

		public static float GetAxis(InputKeyAsset asset, int inputID)
		{
			return asset != null ? asset.Settings.GetAxis(inputID) : 0;
		}

		public virtual float GetAxis(int inputID)
		{
			if(!this.blocked)
			{
				for(int i = 0; i < this.input.Length; i++)
				{
					if(this.input[i].inputID == inputID)
					{
						return this.input[i].GetAxis(this.realID);
					}
				}
			}
			return 0;
		}

		public virtual float GetAnyAxis()
		{
			for(int i = 0; i < this.input.Length; i++)
			{
				float axis = this.input[i].GetAxis(this.realID);
				if(axis != 0)
				{
					return axis;
				}
			}
			return 0;
		}

		public virtual int GetAnyAxisInputID()
		{
			for(int i = 0; i < this.input.Length; i++)
			{
				if(this.input[i].GetAxis(this.realID) != 0)
				{
					return this.input[i].inputID;
				}
			}
			return -1;
		}

		public virtual void SetDownTime(int inputID)
		{
			for(int i = 0; i < this.input.Length; i++)
			{
				if(this.input[i].inputID == inputID ||
					inputID == -1)
				{
					this.input[i].SetDownTime();
				}
			}
		}

		public virtual void ReleaseDownTime(int inputID)
		{
			for(int i = 0; i < this.input.Length; i++)
			{
				if(this.input[i].inputID == inputID ||
					inputID == -1)
				{
					this.input[i].ReleaseDownTime();
				}
			}
		}

		public virtual void SetAxis(int inputID, float value)
		{
			for(int i = 0; i < this.input.Length; i++)
			{
				if(this.input[i].inputID == inputID ||
					inputID == -1)
				{
					this.input[i].CodeAxis = value;
				}
			}
		}

		public virtual void SetAxisHUD(int inputID, float value)
		{
			for(int i = 0; i < this.input.Length; i++)
			{
				if(this.input[i].inputID == inputID ||
					inputID == -1)
				{
					this.input[i].HUDAxis = value;
				}
			}
		}

		public virtual void SetAxisSchematic(int inputID, float value, float time)
		{
			for(int i = 0; i < this.input.Length; i++)
			{
				if(this.input[i].inputID == inputID ||
					inputID == -1)
				{
					this.input[i].SetAxisSchematic(value, time);
				}
			}
		}

		public virtual InputHandling GetHandling(int inputID)
		{
			for(int i = 0; i < this.input.Length; i++)
			{
				if(this.input[i].inputID == inputID)
				{
					return this.input[i].handling;
				}
			}
			return InputHandling.Any;
		}

		public virtual bool Blocked
		{
			get { return this.blocked; }
			set
			{
				this.blocked = value;
				this.Reset();
			}
		}

		public virtual void Reset()
		{
			for(int i = 0; i < this.input.Length; i++)
			{
				this.input[i].Reset();
			}
			if(this.resetHandler != null)
			{
				this.resetHandler();
			}
		}

		public virtual void Clear()
		{
			for(int i = 0; i < this.input.Length; i++)
			{
				this.input[i].Clear();
			}
			if(this.resetHandler != null)
			{
				this.resetHandler();
			}
		}


		/*
		============================================================================
		Fixed update functions
		============================================================================
		*/
		public virtual void StoreForFixedUpdate()
		{
			if(this.inFixedUpdate)
			{
				for(int i = 0; i < this.input.Length; i++)
				{
					this.input[i].StoreForFixedUpdate(this.realID);
				}
			}
		}

		public virtual void FixedTick()
		{
			if(this.inFixedUpdate)
			{
				for(int i = 0; i < this.input.Length; i++)
				{
					this.input[i].FixedTick();
				}
			}
		}

		public virtual void LateFixedTick()
		{
			if(this.inFixedUpdate)
			{
				for(int i = 0; i < this.input.Length; i++)
				{
					this.input[i].LateFixedTick();
				}
			}
		}


		/*
		============================================================================
		Rebind functions
		============================================================================
		*/
		public virtual void Rebind(int inputID, BaseInputIDKeySetting rebind)
		{
			for(int i = 0; i < this.input.Length; i++)
			{
				if(this.input[i].inputID == inputID)
				{
					this.input[i].Rebind = rebind;
					break;
				}
			}
		}

		public virtual bool IsInput(int inputID, BaseInputIDKeySetting input)
		{
			for(int i = 0; i < this.input.Length; i++)
			{
				if(this.input[i].inputID == inputID)
				{
					if(this.input[i].Rebind != null)
					{
						return this.input[i].Rebind.IsInput(inputID, input);
					}
					else
					{
						return this.input[i].settings.IsInput(inputID, input);
					}
				}
			}
			return false;
		}

		public virtual void RebindReset(int inputID, BaseInputIDKeySetting rebind)
		{
			for(int i = 0; i < this.input.Length; i++)
			{
				if(this.input[i].inputID == inputID)
				{
					if(this.input[i].Rebind != null &&
						this.input[i].Rebind.IsInput(inputID, rebind))
					{
						this.input[i].Rebind = null;
					}
					break;
				}
			}
		}

		public virtual BaseInputIDKeySetting GetBinding(int inputID)
		{
			for(int i = 0; i < this.input.Length; i++)
			{
				if(this.input[i].inputID == inputID)
				{
					if(this.input[i].Rebind != null)
					{
						return this.input[i].Rebind;
					}
					else
					{
						return this.input[i].settings;
					}
				}
			}
			return null;
		}

		public virtual string GetInputInfo(int inputID)
		{
			for(int i = 0; i < this.input.Length; i++)
			{
				if(this.input[i].inputID == inputID)
				{
					if(this.input[i].Rebind != null)
					{
						return this.input[i].Rebind.GetInputInfo();
					}
					else
					{
						return this.input[i].settings.GetInputInfo();
					}
				}
			}
			return "";
		}

		public virtual DataObject SaveRebind()
		{
			DataObject data = new DataObject();
			for(int i = 0; i < this.input.Length; i++)
			{
				if(this.input[i].Rebind != null)
				{
					data.Set(i.ToString(), this.input[i].Rebind.SaveGame());
				}
			}
			return data;
		}

		public virtual void LoadRebind(DataObject data)
		{
			if(data != null)
			{
				for(int i = 0; i < this.input.Length; i++)
				{
					this.input[i].Rebind = BaseInputIDKeySetting.Load(data.GetFile(i.ToString()));
				}
			}
		}
	}
}
