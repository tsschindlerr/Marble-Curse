﻿
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	[EditorSettingInfo("Capsule 3D", "Checks if colliders are within a capsule shape (uses 'Collider').")]
	public class Capsule3DShapecheckType<T> : BaseShapecheckType<T> where T : IObjectSelection, new()
	{
		[EditorTitleLabel("Point 1")]
		[EditorLabel("The centre of the sphere at the start of the capsule.")]
		public Vector3Value<T> point1 = new Vector3Value<T>();

		[EditorSeparator]
		[EditorTitleLabel("Point 2")]
		[EditorLabel("The centre of the sphere at the end of the capsule.")]
		public Vector3Value<T> point2 = new Vector3Value<T>();

		[EditorHelp("Radius", "The radius of the capsule.", "")]
		[EditorSeparator]
		[EditorTitleLabel("Radius")]
		public FloatValue<T> radius = new FloatValue<T>();

		public Capsule3DShapecheckType()
		{

		}

		public override string ToString()
		{
			return "Capsule 3D";
		}

		public override bool Check(IDataCall call, int layerMask)
		{
			return Physics.CheckCapsule(
				this.point1.GetValue(call), this.point2.GetValue(call),
				this.radius.GetValue(call), layerMask);
		}

		public override Collider Overlap(IDataCall call, int layerMask)
		{
			Collider[] collider = Physics.OverlapCapsule(
				this.point1.GetValue(call), this.point2.GetValue(call),
				this.radius.GetValue(call), layerMask);

			return collider != null && collider.Length > 0 ? collider[0] : null;
		}

		public override Collider[] OverlapAll(IDataCall call, int layerMask)
		{
			return Physics.OverlapCapsule(
				this.point1.GetValue(call), this.point2.GetValue(call),
				this.radius.GetValue(call), layerMask);
		}

		public override Collider2D Overlap2D(IDataCall call, int layerMask)
		{
			return null;
		}

		public override Collider2D[] OverlapAll2D(IDataCall call, int layerMask)
		{
			return null;
		}
	}
}
