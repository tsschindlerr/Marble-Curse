﻿
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	[EditorSettingInfo("Circle 2D", "Checks if colliders fall within a circle (uses 'Collider2D').")]
	public class Cirlce2DShapecheckType<T> : BaseShapecheckType<T> where T : IObjectSelection, new()
	{
		[EditorTitleLabel("Origin")]
		[EditorLabel("The point in 2D space where the shape originates.\n" +
			"Ignores the Z-axis.")]
		public Vector3Value<T> origin = new Vector3Value<T>();

		[EditorHelp("Radius", "The radius of the shape.", "")]
		[EditorSeparator]
		[EditorTitleLabel("Radius")]
		public FloatValue<T> radius = new FloatValue<T>();


		// depth
		[EditorHelp("Minimum Depth", "Only include objects with a Z coordinate (depth) greater than this value.", "")]
		[EditorSeparator]
		[EditorTitleLabel("Minimum Depth")]
		public FloatValue<T> minDepth = new FloatValue<T>(typeof(FloatValue_NegativeInfinityType<T>));

		[EditorHelp("Maximum Depth", "Only include objects with a Z coordinate (depth) less than this value.", "")]
		[EditorSeparator]
		[EditorTitleLabel("Maximum Depth")]
		public FloatValue<T> maxDepth = new FloatValue<T>(typeof(FloatValue_InfinityType<T>));

		public Cirlce2DShapecheckType()
		{

		}

		public override string ToString()
		{
			return "Circle 2D";
		}

		public override bool Is2D
		{
			get { return true; }
		}

		public override bool Check(IDataCall call, int layerMask)
		{
			return Physics2D.OverlapCircle(
				this.origin.GetValue(call), this.radius.GetValue(call),
				layerMask, this.minDepth.GetValue(call), this.maxDepth.GetValue(call)) != null;
		}

		public override Collider Overlap(IDataCall call, int layerMask)
		{
			return null;
		}

		public override Collider[] OverlapAll(IDataCall call, int layerMask)
		{
			return null;
		}

		public override Collider2D Overlap2D(IDataCall call, int layerMask)
		{
			return Physics2D.OverlapCircle(
				this.origin.GetValue(call), this.radius.GetValue(call),
				layerMask, this.minDepth.GetValue(call), this.maxDepth.GetValue(call));
		}

		public override Collider2D[] OverlapAll2D(IDataCall call, int layerMask)
		{
			return Physics2D.OverlapCircleAll(
				this.origin.GetValue(call), this.radius.GetValue(call),
				layerMask, this.minDepth.GetValue(call), this.maxDepth.GetValue(call));
		}
	}
}
