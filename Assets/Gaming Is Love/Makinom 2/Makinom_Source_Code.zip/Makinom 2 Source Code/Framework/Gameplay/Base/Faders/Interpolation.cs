﻿
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	public class Interpolation : BaseData
	{
		[EditorHelp("Interpolation", "Select the interpolation that will be used:", "")]
		[EditorInfo(settingBaseType = typeof(BaseInterpolation), settingAutoSetup = "settings")]
		public string type = typeof(LinearInterpolation).ToString();

		public BaseInterpolation settings = new LinearInterpolation();

		public Interpolation()
		{

		}

		public override void EditorAutoSetup(string fieldName)
		{
			if("settings" == fieldName)
			{
				if(!this.settings.IsType(this.type))
				{
					DataObject data = this.settings.GetData();
					object tmpSettings = ReflectionTypeHandler.Instance.CreateInstance(
						this.type, typeof(BaseInterpolation));
					if(tmpSettings is BaseInterpolation)
					{
						this.settings = (BaseInterpolation)tmpSettings;
						this.settings.SetData(data);
					}
					else
					{
						this.settings = new LinearInterpolation();
						this.settings.SetData(data);
						this.type = this.settings.GetType().ToString();
					}
				}
			}
		}

		public abstract class Instance<T>
		{
			protected T start;

			protected T target;

			protected float elapsedTime = 0;

			protected float duration = 0;

			public virtual T Start
			{
				get { return this.start; }
				set
				{
					this.start = value;
					this.UpdateDistance();
				}
			}

			public virtual T Target
			{
				get { return this.target; }
				set
				{
					this.target = value;
					this.UpdateDistance();
				}
			}

			public virtual float Duration
			{
				get { return this.duration; }
				set { this.duration = value; }
			}

			public virtual float ElapsedTime
			{
				get { return this.elapsedTime; }
				set { this.elapsedTime = value; }
			}

			public virtual bool Finished
			{
				get { return this.elapsedTime >= this.duration; }
			}

			public virtual void Init(T start, T end, float duration)
			{
				this.start = start;
				this.target = end;
				this.elapsedTime = 0;
				this.duration = duration;
			}

			public virtual void UpdateDistance()
			{

			}

			public abstract T Tick(float deltaTime);

			public virtual void Revert()
			{
				T tmp = this.start;
				this.start = this.target;
				this.target = tmp;
				this.UpdateDistance();
			}
		}


		/*
		============================================================================
		Float functions
		============================================================================
		*/
		public virtual FloatInstance CreateFloat()
		{
			return this.settings.CreateFloat();
		}

		public virtual FloatInstance CreateFloat(float start, float end, float duration)
		{
			FloatInstance instance = this.settings.CreateFloat();
			instance.Init(start, end, duration);
			return instance;
		}

		public abstract class FloatInstance : Instance<float>
		{

		}


		/*
		============================================================================
		Vector2 functions
		============================================================================
		*/
		public virtual Vector2Instance CreateVector2()
		{
			return this.settings.CreateVector2();
		}

		public virtual Vector2Instance CreateVector2(UnityEngine.Vector2 start, UnityEngine.Vector2 end, float duration)
		{
			Vector2Instance instance = this.settings.CreateVector2();
			instance.Init(start, end, duration);
			return instance;
		}

		public abstract class Vector2Instance : Instance<UnityEngine.Vector2>
		{

		}


		/*
		============================================================================
		Vector3 functions
		============================================================================
		*/
		public virtual Vector3Instance CreateVector3()
		{
			return this.settings.CreateVector3();
		}

		public virtual Vector3Instance CreateVector3(UnityEngine.Vector3 start, UnityEngine.Vector3 end, float duration)
		{
			Vector3Instance instance = this.settings.CreateVector3();
			instance.Init(start, end, duration);
			return instance;
		}

		public abstract class Vector3Instance : Instance<UnityEngine.Vector3>
		{

		}


		/*
		============================================================================
		Quaternion functions
		============================================================================
		*/
		public virtual QuaternionInstance CreateQuaternion()
		{
			return this.settings.CreateQuaternion();
		}

		public virtual QuaternionInstance CreateQuaternion(UnityEngine.Quaternion start, UnityEngine.Quaternion end, float duration)
		{
			QuaternionInstance instance = this.settings.CreateQuaternion();
			instance.Init(start, end, duration);
			return instance;
		}

		public abstract class QuaternionInstance : Instance<UnityEngine.Quaternion>
		{

		}


		/*
		============================================================================
		Color functions
		============================================================================
		*/
		public virtual ColorInstance CreateColor()
		{
			return this.settings.CreateColor();
		}

		public virtual ColorInstance CreateColor(UnityEngine.Color start, UnityEngine.Color end, float duration)
		{
			ColorInstance instance = this.settings.CreateColor();
			instance.Init(start, end, duration);
			return instance;
		}

		public abstract class ColorInstance : Instance<UnityEngine.Color>
		{
			public abstract void Tick(ref Color value, float deltaTime, bool fadeRed, bool fadeGreen, bool fadeBlue, bool fadeAlpha);
		}
	}
}
