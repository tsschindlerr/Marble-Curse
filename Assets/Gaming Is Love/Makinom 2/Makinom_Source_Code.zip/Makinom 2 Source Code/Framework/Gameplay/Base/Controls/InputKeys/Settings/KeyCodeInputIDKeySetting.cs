﻿
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	[EditorSettingInfo("Key Code", "The key mapped to the selected key code is used.")]
	public class KeyCodeInputIDKeySetting : BaseInputIDKeySetting
	{
		// key code
		[EditorHelp("Positive Key", "Select the Key Code of the key used for the positive axis value.\n" +
			"If this key isn't used for axis input (e.g. horizontal selection), you only need to define a positive key.")]
		public KeyCode positiveKey = KeyCode.None;

		[EditorHelp("Negative Key", "Select the Key Code of the key used for the negative axis value.\n" +
			"If this key isn't used for axis input (e.g. horizontal selection), you only need to define a positive key.")]
		public KeyCode negativeKey = KeyCode.None;

		public KeyCodeInputIDKeySetting()
		{

		}

		public KeyCodeInputIDKeySetting(KeyCode positiveKey, KeyCode negativeKey)
		{
			this.positiveKey = positiveKey;
			this.negativeKey = negativeKey;
		}

		public override bool IsInput(int inputID, BaseInputIDKeySetting input)
		{
			KeyCodeInputIDKeySetting tmp = input as KeyCodeInputIDKeySetting;
			if(tmp != null)
			{
				return this.positiveKey == tmp.positiveKey &&
					this.negativeKey == tmp.negativeKey;
			}
			return false;
		}

		public override string GetInputInfo()
		{
			if(KeyCode.None != this.positiveKey)
			{
				if(KeyCode.None != this.negativeKey)
				{
					return this.positiveKey.ToString() + " " + this.negativeKey.ToString();
				}
				else
				{
					return this.positiveKey.ToString();
				}
			}
			else if(KeyCode.None != this.negativeKey)
			{
				return this.negativeKey.ToString();
			}
			return "";
		}

		public override bool HasInputHandling
		{
			get { return true; }
		}


		/*
		============================================================================
		Input functions
		============================================================================
		*/
		public override void TickBlocked(InputIDKey inputKey, int inputKeyID)
		{
			if(inputKey.inputHoldTime > 0 ||
				inputKey.inputMaxHoldTime > 0)
			{
				if(Input.GetKeyUp(this.positiveKey) ||
					Input.GetKeyUp(this.negativeKey))
				{
					inputKey.ReleaseDownTime();
				}
				else if(Input.GetKeyDown(this.positiveKey) ||
					Input.GetKeyDown(this.negativeKey))
				{
					inputKey.SetTriggerReleaseTimeout();
				}
			}
		}

		public override void Tick(InputIDKey inputKey, int inputKeyID)
		{
			// trigger count
			if((Input.GetKeyDown(this.positiveKey) && !Input.GetKey(this.negativeKey)) ||
				(Input.GetKeyDown(this.negativeKey) && !Input.GetKey(this.positiveKey)))
			{
				inputKey.IncreaseTriggerCount();
			}

			if(inputKey.CheckTriggerCount())
			{
				// set input down time
				if(inputKey.inputHoldTime > 0 ||
					inputKey.inputMaxHoldTime > 0)
				{
					if(Input.GetKeyDown(this.positiveKey) || Input.GetKeyDown(this.negativeKey))
					{
						inputKey.SetDownTime();
						return;
					}
					else if(Input.GetKeyUp(this.positiveKey) || Input.GetKeyUp(this.negativeKey))
					{
						inputKey.ReleaseDownTime();
						if(InputHandling.Hold == inputKey.handling)
						{
							return;
						}
					}
				}

				// positive key
				if((InputHandling.Down == inputKey.handling && Input.GetKeyDown(this.positiveKey)) ||
					(InputHandling.Hold == inputKey.handling && Input.GetKey(this.positiveKey)) ||
					(InputHandling.Up == inputKey.handling && Input.GetKeyUp(this.positiveKey)) ||
					(InputHandling.Any == inputKey.handling &&
						(Input.GetKeyDown(this.positiveKey) || Input.GetKey(this.positiveKey) ||
						Input.GetKeyUp(this.positiveKey))))
				{
					inputKey.Timeout = Time.realtimeSinceStartup + inputKey.inputTimeout;
					inputKey.UpdateAxis = 1;
					inputKey.InputReceived = true;
				}
				// negative key
				else if((InputHandling.Down == inputKey.handling && Input.GetKeyDown(this.negativeKey)) ||
					(InputHandling.Hold == inputKey.handling && Input.GetKey(this.negativeKey)) ||
					(InputHandling.Up == inputKey.handling && Input.GetKeyUp(this.negativeKey)) ||
					(InputHandling.Any == inputKey.handling &&
						(Input.GetKeyDown(this.negativeKey) || Input.GetKey(this.negativeKey) ||
						Input.GetKeyUp(this.negativeKey))))
				{
					inputKey.Timeout = Time.realtimeSinceStartup + inputKey.inputTimeout;
					inputKey.UpdateAxis = -1;
					inputKey.InputReceived = true;
				}
				if((InputHandling.Up == inputKey.handling || !inputKey.InputReceived) &&
					(Input.GetKeyUp(this.positiveKey) || Input.GetKeyUp(this.negativeKey)))
				{
					inputKey.ResetTriggerCount();
				}
			}
		}
	}
}
