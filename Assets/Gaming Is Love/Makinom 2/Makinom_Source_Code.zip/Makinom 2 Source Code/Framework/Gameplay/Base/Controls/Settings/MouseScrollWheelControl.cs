﻿
using System.Collections.Generic;
using UnityEngine;

namespace GamingIsLove.Makinom
{
	public class MouseScrollWheelControl : BaseData
	{
		[EditorHelp("Use Scroll Wheel", "Use scroll wheel axis input.")]
		public bool useScrollWheel = false;

		[EditorHelp("Invert Axis", "The scroll wheel axis will be inverted, " +
			"i.e. 1 will become -1, -1 will become 1.", "")]
		[EditorIndent]
		[EditorCondition("useScrollWheel", true)]
		public bool invertAxis = false;

		[EditorHelp("Axis Factor", "The scroll wheel axis value will be multiplied by this value.", "")]
		[EditorIndent]
		public float axisFactor = 1;

		[EditorHelp("Limit Axis", "Limits the axis value to be between 2 defined values (included).\n" +
			"The limit is used after the axis factor.", "")]
		[EditorIndent]
		public bool limitAxis = false;

		[EditorHelp("Minimum Axis", "The minimum value the axis can have (lower limit).", "")]
		[EditorIndent(2)]
		[EditorCondition("limitAxis", true)]
		public float minAxis = -1;

		[EditorHelp("Maximum Axis", "The maximum value the axis can have (upper limit).", "")]
		[EditorIndent(2)]
		[EditorEndCondition(2)]
		public float maxAxis = 1;

		public MouseScrollWheelControl()
		{

		}

		public virtual float GetAxis()
		{
			if(this.useScrollWheel)
			{
				float value = this.axisFactor * (this.invertAxis ? -Input.mouseScrollDelta.y : Input.mouseScrollDelta.y);
				if(this.limitAxis)
				{
					if(value < this.minAxis)
					{
						value = this.minAxis;
					}
					else if(value > this.maxAxis)
					{
						value = this.maxAxis;
					}
				}
				return value;
			}
			return 0;
		}
	}
}
