﻿
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	public enum GyroscopeInputType { Attitude, Gravity, RotationRate, RotationRateUnbiased, UserAcceleration }
	public enum GyroscopeAttitudeType { Real, Clamp01, HalfClamp, Normalized }

	[EditorSettingInfo("Gyroscope", "A selected axis of gyroscope data of a device is used.")]
	public class GyroscopeInputIDKeySetting : BaseInputIDKeySetting
	{
		// gyroscope
		[EditorHelp("Gyroscope Type", "Select which value of the gyroscope will be used:\n" +
			"- Attitude: The orientation of the device in space (euler angles).\n" +
			"- Gravity: The gravity acceleration vector.\n" +
			"- Rotation Rate: The rotation rate measured by the device.\n" +
			"- Rotation Rate Unbiased: The unbiased rotation rate measured by the device.\n" +
			"- User Acceleration: The acceleration that the user is giving the device.", "")]
		public GyroscopeInputType gyroscopeType = GyroscopeInputType.Attitude;

		[EditorHelp("Attitude Type", "Select how the attitude value will be interpreted:\n" +
			"- Real: The real value will be used (0-360).\n" +
			"- Clamp 01: The value will be clamped between 0 and 1 (i.e. divided by 360).\n" +
			"- Half Clamp: The value will be clamped between -1 and 1 (i.e. 0 to 180 will be -1 to 0, 180 to 360 will be 0 to 1).\n" +
			"- Normalized: The Vector3 value will be normalized.", "")]
		public GyroscopeAttitudeType attitudeType = GyroscopeAttitudeType.Clamp01;


		// vector3 axis information
		[EditorHelp("Axis", "Select the axis of the Vector3 that will be used.", "")]
		[EditorSeparator]
		public AxisType axisType = AxisType.X;

		[EditorHelp("Use Absolute Value", "Use the absolute value of the axis, i.e. -0.2 will become 0.2.", "")]
		public bool axisAbsoluteValue = true;

		[EditorHelp("Button Check", "A button press is recognized based on the selected check function.\n" +
			"The input can be recognized if the selected axis value is equal, not equal, less or greater than a defined value.\n" +
			"Range inclusive checks if the value is between two defined values, including the values.\n" +
			"Range exclusive checks if the value is between two defined values, excluding the values.\n" +
			"Approximately checks if the value is similar to the defined value.", "")]
		public ValueCheck<GameObjectSelection> axisButtonCheck = new ValueCheck<GameObjectSelection>();

		public GyroscopeInputIDKeySetting()
		{

		}


		/*
		============================================================================
		Input functions
		============================================================================
		*/
		public override void Tick(InputIDKey inputKey, int inputKeyID)
		{
			if(GyroscopeInputType.Attitude == this.gyroscopeType)
			{
				Vector3 attitude = Input.gyro.attitude.eulerAngles;
				if(GyroscopeAttitudeType.Clamp01 == this.attitudeType)
				{
					attitude /= 360.0f;
				}
				else if(GyroscopeAttitudeType.HalfClamp == this.attitudeType)
				{
					attitude -= new Vector3(180.0f, 180.0f, 180.0f);
					attitude /= 180.0f;
				}
				else if(GyroscopeAttitudeType.Normalized == this.attitudeType)
				{
					attitude = attitude.normalized;
				}

				inputKey.UpdateAxis = VectorHelper.GetAxisValue(attitude, this.axisType);
			}
			else if(GyroscopeInputType.Gravity == this.gyroscopeType)
			{
				inputKey.UpdateAxis = VectorHelper.GetAxisValue(Input.gyro.gravity, this.axisType);
			}
			else if(GyroscopeInputType.RotationRate == this.gyroscopeType)
			{
				inputKey.UpdateAxis = VectorHelper.GetAxisValue(Input.gyro.rotationRate, this.axisType);
			}
			else if(GyroscopeInputType.RotationRateUnbiased == this.gyroscopeType)
			{
				inputKey.UpdateAxis = VectorHelper.GetAxisValue(Input.gyro.rotationRateUnbiased, this.axisType);
			}
			else if(GyroscopeInputType.UserAcceleration == this.gyroscopeType)
			{
				inputKey.UpdateAxis = VectorHelper.GetAxisValue(Input.gyro.userAcceleration, this.axisType);
			}

			if(this.axisButtonCheck.Check(
				this.axisAbsoluteValue ? Mathf.Abs(inputKey.UpdateAxis) : inputKey.UpdateAxis,
				this.axisButtonCheck.NeedsCall ? new DataCall(inputKey.inputID) : null))
			{
				inputKey.InputReceived = true;
			}
		}
	}
}
