﻿
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	[EditorSettingInfo("None", "No direct input is used. Input from a HUD or code can still be used.")]
	public class NoneInputIDKeySetting : BaseInputIDKeySetting
	{
		public NoneInputIDKeySetting()
		{

		}
	}
}
