
using UnityEngine;
using GamingIsLove.Makinom.Components;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	public class ObjectSelectionSetting : BaseData
	{
		// selection keys
		[EditorHelp("Use Input Keys", "Use input keys to select an object.")]
		[EditorFoldout("Selection Input Settings", "Use input keys to select a game object with a 'Selectable Object' component attached.")]
		public bool useInputKeys = false;

		[EditorHelp("Only Visible Objects", "Only game objects visible to the camera will be selected " +
			"(based on the 'Visibility Settings' in the game settings).\n" +
			"If disabled, game objects that are off-screen can also be selected.\n" +
			"This is used when using input keys or schematic nodes for object selection.", "")]
		public bool onlyVisible = false;


		// input keys
		[EditorFoldout("Nearest Object", "The key used to select the nearest object to the player.")]
		[EditorEndFoldout]
		[EditorCondition("useInputKeys", true)]
		[EditorAutoInit]
		public AudioInputSelection nearestObjectKeySettings;

		[EditorFoldout("Left Object", "The key used to select the next object to the left of the selected object.")]
		[EditorEndFoldout]
		[EditorAutoInit]
		public AudioInputSelection leftObjectKeySettings;

		[EditorFoldout("Right Object", "The key used to select the next object to the right of the currently selected object.")]
		[EditorEndFoldout]
		[EditorAutoInit]
		public AudioInputSelection rightObjectKeySettings;

		[EditorFoldout("Remove Selection", "The key used to remove the selection, i.e. unselect the current object.")]
		[EditorEndFoldout]
		[EditorAutoInit]
		public AudioInputSelection removeSelectionKeySettings;

		[EditorFoldout("Selection Range", "Define the range in which objects can be selected using input keys.", "")]
		[EditorEndFoldout(2)]
		[EditorEndCondition]
		public RangeValue range = new RangeValue(20);


		// mouse/touch
		[EditorHelp("Use Cursor Over", "Select a game object when the cursor is over it.")]
		[EditorFoldout("Mouse/Touch Control", "Use mouse/touch input to select a game object with a 'Selectable Object' component.")]
		public bool useCursorOver = false;

		[EditorCondition("useCursorOver", false)]
		[EditorEndCondition]
		public MouseTouchControl mouseTouch = new MouseTouchControl();

		[EditorHelp("Distance", "The distance the raycast will use.\n" +
			"If nothing is hit within this distance, no object will be selected.", "")]
		[EditorSeparator]
		[EditorTitleLabel("Raycast Settings")]
		[EditorLabel("Uses a raycast at the cursor/click/touch screen position to find selectable objects.")]
		[EditorCondition("mouseTouch.Active", true)]
		[EditorCondition("useCursorOver", true)]
		public float distance = 100.0f;

		[EditorHelp("Layer Mask", "Select the layers the raycast will use.\n" +
			"Only objects on the selected layers can be hit by the raycast.", "")]
		public LayerMask layerMask = -1;

		[EditorHelp("Auto Remove", "Remove the selection (i.e. unselect) if no selectable object was clicked.", "")]
		[EditorEndFoldout]
		[EditorEndCondition]
		public bool rayAutoRemove = false;


		// cursor
		[EditorHelp("Use Cursor", "The selected object is marked with a cursor.", "")]
		[EditorFoldout("Cursor Settings", "Mark the currently selected object with a cursor prefab.")]
		public bool useCursor = false;

		[EditorHelp("Prefab", "Select the prefab used as cursor object.", "")]
		[EditorCondition("useCursor", true)]
		[EditorAutoInit]
		public AssetSource<GameObject> cursorPrefab;

		[EditorEndFoldout]
		[EditorEndCondition]
		public MountSettings cursorMount = new MountSettings();

		public ObjectSelectionSetting()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(this.useInputKeys &&
				data.Contains<DataObject>("nearestObjectKey"))
			{
				this.nearestObjectKeySettings = new AudioInputSelection();
				this.nearestObjectKeySettings.inputKey.SetData(data.GetFile("nearestObjectKey"));

				this.leftObjectKeySettings = new AudioInputSelection();
				this.leftObjectKeySettings.inputKey.SetData(data.GetFile("leftObjectKey"));

				this.rightObjectKeySettings = new AudioInputSelection();
				this.rightObjectKeySettings.inputKey.SetData(data.GetFile("rightObjectKey"));

				this.removeSelectionKeySettings = new AudioInputSelection();
				this.removeSelectionKeySettings.inputKey.SetData(data.GetFile("removeSelectionKey"));
			}
		}

		public bool CheckKeys()
		{
			if(this.useInputKeys)
			{
				// select nearest
				if(this.nearestObjectKeySettings.GetButton())
				{
					Maki.Game.Interactions.Selected = Maki.Game.Interactions.GetNearestSelectable(Maki.Game.Player.GameObject, this.range);
					return true;
				}
				// select left
				if(this.leftObjectKeySettings.GetButton())
				{
					Maki.Game.Interactions.Selected = Maki.Game.Interactions.GetLeftSelectable(Maki.Game.Player.GameObject,
						Maki.Game.Interactions.Selected != null ? Maki.Game.Interactions.Selected.gameObject : null,
						this.range);
					return true;
				}
				// select right
				if(this.rightObjectKeySettings.GetButton())
				{
					Maki.Game.Interactions.Selected = Maki.Game.Interactions.GetRightSelectable(Maki.Game.Player.GameObject,
						Maki.Game.Interactions.Selected != null ? Maki.Game.Interactions.Selected.gameObject : null,
						this.range);
					return true;
				}
				// remove selection
				if(this.removeSelectionKeySettings.GetButton())
				{
					Maki.Game.Interactions.Selected = null;
					return true;
				}
			}
			if(this.useCursorOver)
			{
				Ray ray = Maki.Game.Camera.ScreenPointToRay(Input.mousePosition);
				RaycastOutput hit = null;
				if(RaycastHelper.Raycast(Maki.GameSettings.raycastType,
					ray.origin, ray.direction, out hit, this.distance, this.layerMask))
				{
					SelectableObject so = hit.transform.GetComponentInChildren<SelectableObject>();
					if(so != null || this.rayAutoRemove)
					{
						Maki.Game.Interactions.Selected = so;
					}
				}
			}
			else if(this.mouseTouch.Active)
			{
				Vector3 point = Vector3.zero;
				if(this.mouseTouch.Interacted(ref point) &&
					Maki.Game.Camera != null)
				{
					Ray ray = Maki.Game.Camera.ScreenPointToRay(point);
					RaycastOutput hit = null;
					if(RaycastHelper.Raycast(Maki.GameSettings.raycastType,
						ray.origin, ray.direction, out hit, this.distance, this.layerMask))
					{
						SelectableObject so = hit.transform.GetComponentInChildren<SelectableObject>();
						if(so != null || this.rayAutoRemove)
						{
							Maki.Game.Interactions.Selected = so;
						}
					}
				}
			}
			return false;
		}


		/*
		============================================================================
		Cursor functions
		============================================================================
		*/
		public GameObject CreateCursor()
		{
			if(this.useCursor)
			{
				GameObject prefab = this.cursorPrefab;
				if(prefab != null)
				{
					return UnityWrapper.Instantiate(prefab);
				}
			}
			return null;
		}
	}
}
