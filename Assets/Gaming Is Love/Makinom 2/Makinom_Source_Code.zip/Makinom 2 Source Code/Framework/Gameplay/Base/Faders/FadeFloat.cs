﻿
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	public class FadeFloat
	{
		protected bool isFading = false;

		protected FadeType fadeType = FadeType.Fade;

		protected bool reverting = false;

		protected float currentValue = 0;

		protected Interpolation.FloatInstance interpolation;


		// delegates
		protected SetFloat setValue;

		protected GetFloat deltaTime;

		protected bool inPause = false;

		public FadeFloat(FadeType fadeType, float time, Interpolation interpolation, bool inPause)
		{
			this.fadeType = fadeType;
			this.interpolation = interpolation.CreateFloat(0, 0,
				FadeType.Flash == this.fadeType ? time / 2 : time);
			this.inPause = inPause;
		}

		public FadeFloat(FadeType fadeType, float time, float currentValue,
			float startValue, float endValue, Interpolation interpolation, bool inPause)
		{
			this.fadeType = fadeType;
			this.currentValue = currentValue;
			this.interpolation = interpolation.CreateFloat(startValue, endValue,
				FadeType.Flash == this.fadeType ? time / 2 : time);
			this.inPause = inPause;

			this.isFading = true;
		}

		public FadeFloat(FadeType fadeType, float time, float currentValue,
			float startValue, float endValue, Interpolation interpolation,
			SetFloat setValue, GetFloat deltaTime, bool inPause)
		{
			this.fadeType = fadeType;
			this.currentValue = currentValue;
			this.interpolation = interpolation.CreateFloat(startValue, endValue,
				FadeType.Flash == this.fadeType ? time / 2 : time);
			this.setValue = setValue;
			this.deltaTime = deltaTime;
			this.inPause = inPause;

			this.setValue(this.currentValue);
			this.isFading = true;
		}

		public virtual bool InPause
		{
			get { return this.inPause; }
			set { this.inPause = value; }
		}

		public virtual void Start(float startValue, float endValue)
		{
			this.currentValue = startValue;
			this.interpolation.Init(startValue, endValue, this.interpolation.Duration);
			if(this.setValue != null)
			{
				this.setValue(this.currentValue);
			}
			this.isFading = true;
		}


		/*
		============================================================================
		Fade functions
		============================================================================
		*/
		public virtual bool IsFading
		{
			get { return this.isFading; }
			set { this.isFading = false; }
		}

		/// <summary>
		/// Updates the faded value using the provided delegate functions.
		/// </summary>
		/// <returns><c>true</c> if the fade duration was finished in this update.</returns>
		public virtual bool Tick()
		{
			this.currentValue = this.interpolation.Duration > 0 ?
				this.interpolation.Tick(this.deltaTime == null ? Maki.Game.DeltaTime : this.deltaTime()) :
				this.interpolation.Target;

			if(this.setValue != null)
			{
				this.setValue(this.currentValue);
			}

			if(this.interpolation.Finished)
			{
				if(FadeType.Fade == this.fadeType)
				{
					this.isFading = false;
					return true;
				}
				else if(FadeType.Blink == this.fadeType)
				{
					this.reverting = !this.reverting;
					this.interpolation.ElapsedTime = 0;
					this.interpolation.Revert();
				}
				else if(FadeType.Flash == this.fadeType)
				{
					if(this.reverting)
					{
						this.isFading = false;
						return true;
					}
					else
					{
						this.reverting = true;
						this.interpolation.ElapsedTime = 0;
						this.interpolation.Revert();
					}
				}
			}
			return false;
		}

		/// <summary>
		/// Updates the passed on value.
		/// </summary>
		/// <param name="value">The value that will be set.</param>
		/// <param name="deltaTime">The delta time used for fading.</param>
		/// <returns><c>true</c> if the fade duration was finished in this update.</returns>
		public virtual bool Tick(ref float value, float deltaTime)
		{
			this.currentValue = this.interpolation.Duration > 0 ?
				this.interpolation.Tick(deltaTime) :
				this.interpolation.Target;

			value = this.currentValue;

			if(this.interpolation.Finished)
			{
				if(FadeType.Fade == this.fadeType)
				{
					this.isFading = false;
					return true;
				}
				else if(FadeType.Blink == this.fadeType)
				{
					this.reverting = !this.reverting;
					this.interpolation.ElapsedTime = 0;
					this.interpolation.Revert();
				}
				else if(FadeType.Flash == this.fadeType)
				{
					if(this.reverting)
					{
						this.isFading = false;
						return true;
					}
					else
					{
						this.reverting = true;
						this.interpolation.ElapsedTime = 0;
						this.interpolation.Revert();
					}
				}
			}
			return false;
		}
	}
}
