﻿
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	[EditorSettingInfo("Unity Input Manager", "A key defined in the Unity input manager is used.")]
	public class UnityInputManagerInputIDKeySetting : BaseInputIDKeySetting
	{
		// input name
		[EditorHelp("Input Name", "The name of the Unity input manager key.\n" +
			"The name must match the spelling of the name given in the Unity input manager.", "")]
		[EditorWidth(true)]
		public string keyName = "";

		[EditorHelp("Is Joypad Axis", "The used Unity input manager key is a joypad axis.\n" +
			"A joypad axis dont have down/hold/up actions, enable this option if you want to use them.", "")]
		public bool isJoypadAxis = false;

		[EditorHelp("Up/Down Full Axis", "Input of 'Up' or 'Down' input handling will be interpreted as full axis value of 1/-1.\n" +
			"E.g. enable this setting when using 'Down' input handling for UI horizontal/vertical axis input coming from joypad axis, " +
			"as otherwise the value received when 'Down' is registered will be too low.", "")]
		[EditorIndent]
		[EditorCondition("isJoypadAxis", true)]
		[EditorEndCondition]
		public bool joypadUpDownFullAxis = false;


		// in-game
		private float lastJoypadAxis = 0;

		public UnityInputManagerInputIDKeySetting()
		{

		}

		public override bool IsInput(int inputID, BaseInputIDKeySetting input)
		{
			UnityInputManagerInputIDKeySetting tmp = input as UnityInputManagerInputIDKeySetting;
			if(tmp != null)
			{
				return this.keyName == tmp.keyName;
			}
			return false;
		}

		public override string GetInputInfo()
		{
			return this.keyName;
		}

		public override bool HasInputHandling
		{
			get { return true; }
		}

		public override void Clear()
		{
			this.lastJoypadAxis = 0;
		}


		/*
		============================================================================
		Input functions
		============================================================================
		*/
		public override void TickBlocked(InputIDKey inputKey, int inputKeyID)
		{
			if(inputKey.inputHoldTime > 0 ||
				inputKey.inputMaxHoldTime > 0)
			{
				if(this.isJoypadAxis)
				{
					float tmpAxis = Time.timeScale == 0 ?
						Input.GetAxisRaw(this.keyName) :
						Input.GetAxis(this.keyName);

					if(tmpAxis == 0 && this.lastJoypadAxis != 0)
					{
						this.lastJoypadAxis = tmpAxis;
						inputKey.ReleaseDownTime();
					}
					else if(tmpAxis != this.lastJoypadAxis)
					{
						this.lastJoypadAxis = tmpAxis;
						inputKey.SetTriggerReleaseTimeout();
					}
				}
				else
				{
					if(Input.GetButtonUp(this.keyName))
					{
						inputKey.ReleaseDownTime();
					}
					else if(Input.GetButtonDown(this.keyName))
					{
						inputKey.SetTriggerReleaseTimeout();
					}
				}
			}
		}

		public override void Tick(InputIDKey inputKey, int inputKeyID)
		{
			if(this.isJoypadAxis)
			{
				inputKey.UpdateAxis = Time.timeScale == 0 ?
					Input.GetAxisRaw(this.keyName) : Input.GetAxis(this.keyName);

				// trigger count
				if(inputKey.UpdateAxis != 0 && this.lastJoypadAxis == 0)
				{
					inputKey.IncreaseTriggerCount();
				}

				if(inputKey.CheckTriggerCount())
				{
					// set input down time
					if(inputKey.inputHoldTime > 0 ||
						inputKey.inputMaxHoldTime > 0)
					{
						// down
						if(inputKey.UpdateAxis != 0 && this.lastJoypadAxis == 0)
						{
							inputKey.SetDownTime();
							this.lastJoypadAxis = inputKey.UpdateAxis;
							return;
						}
						// up
						else if(inputKey.UpdateAxis == 0 && this.lastJoypadAxis != 0)
						{
							inputKey.ReleaseDownTime();
							if(InputHandling.Hold == inputKey.handling)
							{
								this.lastJoypadAxis = inputKey.UpdateAxis;
								return;
							}
						}
					}

					if((InputHandling.Down == inputKey.handling && inputKey.UpdateAxis != 0 && this.lastJoypadAxis == 0) ||
						(InputHandling.Hold == inputKey.handling && inputKey.UpdateAxis != 0 && this.lastJoypadAxis != 0) ||
						(InputHandling.Up == inputKey.handling && inputKey.UpdateAxis == 0 && this.lastJoypadAxis != 0) ||
						(InputHandling.Any == inputKey.handling &&
							((inputKey.UpdateAxis != 0 && this.lastJoypadAxis == 0) ||
							(inputKey.UpdateAxis != 0 && this.lastJoypadAxis != 0) ||
							(inputKey.UpdateAxis == 0 && this.lastJoypadAxis != 0))))
					{
						if(this.joypadUpDownFullAxis)
						{
							// down
							if(inputKey.UpdateAxis != 0 && this.lastJoypadAxis == 0)
							{
								inputKey.UpdateAxis = inputKey.ManipulateAxisValue(inputKey.UpdateAxis > 0 ? 1 : -1);
							}
							// up
							else if(inputKey.UpdateAxis == 0 && this.lastJoypadAxis != 0)
							{
								this.lastJoypadAxis = inputKey.ManipulateAxisValue(this.lastJoypadAxis > 0 ? 1 : -1);
							}
						}

						if(InputHandling.Up == inputKey.handling ||
							(InputHandling.Any == inputKey.handling && inputKey.UpdateAxis == 0))
						{
							float tmp = inputKey.UpdateAxis;
							inputKey.SetUpdateAxisUnmanipulated(this.lastJoypadAxis);
							this.lastJoypadAxis = tmp;
							inputKey.ResetTriggerCount();
						}
						else
						{
							this.lastJoypadAxis = inputKey.UpdateAxis;
						}
						inputKey.Timeout = Time.realtimeSinceStartup + inputKey.inputTimeout;
						inputKey.InputReceived = true;
					}
					else
					{
						if(inputKey.UpdateAxis == 0 && this.lastJoypadAxis != 0)
						{
							inputKey.ResetTriggerCount();
						}
						this.lastJoypadAxis = inputKey.UpdateAxis;
					}
				}
				else
				{
					this.lastJoypadAxis = inputKey.UpdateAxis;
				}
			}
			else
			{
				inputKey.UpdateAxis = Time.timeScale == 0 ?
					Input.GetAxisRaw(this.keyName) : Input.GetAxis(this.keyName);

				// trigger count
				if(Input.GetButtonDown(this.keyName))
				{
					inputKey.IncreaseTriggerCount();
				}

				if(inputKey.CheckTriggerCount())
				{
					// set input down time
					if(inputKey.inputHoldTime > 0)
					{
						if(Input.GetButtonDown(this.keyName))
						{
							inputKey.SetDownTime();
							return;
						}
						else if(Input.GetButtonUp(this.keyName))
						{
							inputKey.ReleaseDownTime();
							if(InputHandling.Hold == inputKey.handling)
							{
								return;
							}
						}
					}

					if((InputHandling.Down == inputKey.handling && Input.GetButtonDown(this.keyName)) ||
						(InputHandling.Hold == inputKey.handling && Input.GetButton(this.keyName)) ||
						(InputHandling.Up == inputKey.handling && Input.GetButtonUp(this.keyName)) ||
						(InputHandling.Any == inputKey.handling &&
							(Input.GetButtonDown(this.keyName) || Input.GetButton(this.keyName) ||
							Input.GetButtonUp(this.keyName))))
					{
						inputKey.Timeout = Time.realtimeSinceStartup + inputKey.inputTimeout;

						inputKey.InputReceived = true;
					}
					if(Input.GetButtonUp(this.keyName))
					{
						inputKey.ResetTriggerCount();
					}
				}
			}
		}

		public override float GetAxis(InputIDKey inputKey, int inputKeyID)
		{
			if(this.isJoypadAxis &&
				!inputKey.InputReceived)
			{
				return 0;
			}
			return inputKey.UpdateAxis;
		}
	}
}
