﻿
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	[EditorSettingInfo("Quadratic/Quadratic In", "Quadratic easing in, accelerating from zero velocity.",
		sortIndex=1)]
	public class QuadraticInInterpolation : BaseInterpolation
	{
		public QuadraticInInterpolation()
		{

		}

		public override float UpdateFloat(float start, float distance, float elapsedTime, float duration)
		{
			elapsedTime = (elapsedTime > duration) ? 1.0f : elapsedTime / duration;
			return distance * elapsedTime * elapsedTime + start;
		}
	}

	[EditorSettingInfo("Quadratic/Quadratic Out", "Quadratic easing out, decelerating to zero velocity.",
		sortIndex=1)]
	public class QuadraticOutInterpolation : BaseInterpolation
	{
		public QuadraticOutInterpolation()
		{

		}

		public override float UpdateFloat(float start, float distance, float elapsedTime, float duration)
		{
			elapsedTime = (elapsedTime > duration) ? 1.0f : elapsedTime / duration;
			return -distance * elapsedTime * (elapsedTime - 2) + start;
		}
	}

	[EditorSettingInfo("Quadratic/Quadratic In + Out", "Quadratic easing in/out, acceleration until halfway, then deceleration.",
		sortIndex=1)]
	public class QuadraticInOutInterpolation : BaseInterpolation
	{
		public QuadraticInOutInterpolation()
		{

		}

		public override float UpdateFloat(float start, float distance, float elapsedTime, float duration)
		{
			elapsedTime = (elapsedTime > duration) ? 2.0f : elapsedTime / (duration / 2);
			if(elapsedTime < 1)
			{
				return distance / 2 * elapsedTime * elapsedTime + start;
			}
			elapsedTime--;
			return -distance / 2 * (elapsedTime * (elapsedTime - 2) - 1) + start;
		}
	}
}
