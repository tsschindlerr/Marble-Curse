﻿
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	public abstract class BaseAssetSource : BaseTypeData
	{
		/*
		============================================================================
		Editor functions
		============================================================================
		*/
		public virtual bool EditorHasAssetField
		{
			get { return false; }
		}

		public virtual Object EditorAsset
		{
			get { return null; }
			set { }
		}

		public virtual bool HasAsset
		{
			get { return false; }
		}

		public virtual void EditorBefore()
		{

		}

		public virtual bool EditorAfter(bool assetChanged, string assetPath)
		{
			return false;
		}

		public virtual string GetInfoText()
		{
			return "";
		}
	}

	public abstract class BaseAssetSource<T> : BaseAssetSource where T : UnityEngine.Object
	{
		public abstract T Get();
	}
}
