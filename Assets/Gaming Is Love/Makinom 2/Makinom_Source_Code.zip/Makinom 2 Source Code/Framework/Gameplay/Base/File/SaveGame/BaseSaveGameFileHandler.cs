﻿
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	public abstract class BaseSaveGameFileHandler : BaseTypeData
	{
		public abstract void SaveFile(int index, string data);

		public abstract string LoadFile(int index);

		public abstract void DeleteFile(int index);

		public abstract bool FileExists(int index);
	}
}
