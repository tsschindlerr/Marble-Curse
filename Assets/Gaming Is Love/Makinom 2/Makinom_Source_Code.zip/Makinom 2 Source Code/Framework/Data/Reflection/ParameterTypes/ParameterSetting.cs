﻿
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom.Reflection
{
	public class ParameterSetting<T> : BaseData where T : IObjectSelection, new()
	{
		[EditorHelp("Value Type", "Select the value type that will be used:", "")]
		[EditorInfo(settingBaseType = typeof(BaseParameterType), settingAutoSetup = "settings")]
		public string type = "";

		public BaseParameterType<T> settings = new StringParameterType<T>();

		public ParameterSetting()
		{
			this.type = this.settings.GetGenericTypeName();
		}

		public override void EditorAutoSetup(string fieldName)
		{
			if("settings" == fieldName)
			{
				if(!this.settings.IsType(this.type))
				{
					DataObject data = this.settings.GetData();

					System.Type tmpType = ReflectionTypeHandler.Instance.GetType(this.type, typeof(BaseParameterType));
					if(tmpType != null)
					{
						object tmpSettings = ReflectionTypeHandler.Instance.CreateInstance(
							tmpType.MakeGenericType(typeof(T)));
						if(tmpSettings is BaseParameterType<T>)
						{
							this.settings = (BaseParameterType<T>)tmpSettings;
							this.settings.SetData(data);
						}
						else
						{
							this.settings = new StringParameterType<T>();
							this.settings.SetData(data);
							this.type = this.settings.GetGenericTypeName();
						}
					}
					else
					{
						this.settings = new StringParameterType<T>();
						this.settings.SetData(data);
						this.type = this.settings.GetGenericTypeName();
					}
				}
			}
		}

		public override string ToString()
		{
			return this.settings.ToString();
		}

		public static ParameterSetting<T> UpgradeData(DataObject data)
		{
			int tmp = 0;
			data.Get("type", ref tmp);

			BaseParameterType<T> settings = null;
			if(tmp == 0)
			{
				settings = new StringParameterType<T>();
			}
			else if(tmp == 1)
			{
				settings = new BoolParameterType<T>();
			}
			else if(tmp == 2)
			{
				settings = new IntParameterType<T>();
			}
			else if(tmp == 3)
			{
				settings = new FloatParameterType<T>();
			}
			else if(tmp == 4)
			{
				settings = new Vector2ParameterType<T>();
			}
			else if(tmp == 5)
			{
			}
			else if(tmp == 6)
			{
				settings = new QuaternionParameterType<T>();
			}
			else if(tmp == 7)
			{
				settings = new ColorParameterType<T>();
			}
			else if(tmp == 8)
			{
				settings = new LayerMaskParameterType<T>();
			}
			else if(tmp == 9)
			{
				settings = new GameObjectParameterType<T>();
			}
			else if(tmp == 10)
			{
				settings = new PrefabParameterType<T>();
			}
			else if(tmp == 11)
			{
				settings = new AudioClipParameterType<T>();
			}
			else if(tmp == 12)
			{
				settings = new AudioMixerParameterType<T>();
			}
			else if(tmp == 13)
			{
				settings = new AudioMixerGroupParameterType<T>();
			}
			else if(tmp == 14)
			{
				settings = new SpriteParameterType<T>();
			}
			else if(tmp == 15)
			{
				settings = new TextureParameterType<T>();
			}
			else if(tmp == 16)
			{
				settings = new MaterialParameterType<T>();
			}
			else if(tmp == 17)
			{
				settings = new PhysicMaterialParameterType<T>();
			}
			else if(tmp == 18)
			{
				settings = new PhysicsMaterial2DParameterType<T>();
			}
			else if(tmp == 19)
			{
				settings = new ComponentParameterType<T>();
			}
			else if(tmp == 20)
			{
				settings = new EnumParameterType<T>();
			}
			else if(tmp == 21)
			{
				settings = new TransformParameterType<T>();
			}

			if(settings == null)
			{
				settings = new StringParameterType<T>();
			}
			settings.SetData(data);

			ParameterSetting<T> parameter = new ParameterSetting<T>();
			parameter.settings = settings;
			parameter.type = parameter.settings.GetGenericTypeName();
			return parameter;
		}
	}
}
