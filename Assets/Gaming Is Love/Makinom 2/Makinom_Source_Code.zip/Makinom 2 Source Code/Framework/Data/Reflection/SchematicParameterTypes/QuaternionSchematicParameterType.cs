﻿
using UnityEngine;
using GamingIsLove.Makinom.Schematics;
using System.Collections.Generic;

namespace GamingIsLove.Makinom.Reflection
{
	[EditorSettingInfo("Quaternion", "A Quaternion value (uses a Vector3 as euler angles).")]
	public class QuaternionSchematicParameterType : BaseSchematicParameterType
	{
		[EditorTitleLabel("Quaternion Value")]
		public Vector3Value<SchematicObjectSelection> vector3Value = new Vector3Value<SchematicObjectSelection>();

		public QuaternionSchematicParameterType()
		{

		}

		public override string ToString()
		{
			return this.vector3Value.ToString();
		}

		public override bool NeedsCall
		{
			get
			{
				return this.vector3Value.NeedsCall;
			}
		}

		public override System.Type GetParameterType()
		{
			return typeof(Quaternion);
		}

		public override object GetParameterValue(Schematic schematic)
		{
			return Quaternion.Euler(this.vector3Value.GetValue(schematic));
		}
	}
}
