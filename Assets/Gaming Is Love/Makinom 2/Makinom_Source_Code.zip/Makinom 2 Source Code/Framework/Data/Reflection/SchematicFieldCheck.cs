
using UnityEngine;
using UnityEngine.Audio;
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.Schematics;
using System.Collections.Generic;
using System.Reflection;

namespace GamingIsLove.Makinom.Reflection
{
	public class SchematicFieldCheck : BaseData
	{
		// field
		[EditorHelp("Field Name", "The name of the field that will be checked.", "")]
		[EditorHide]
		[EditorWidth(true)]
		[EditorReflectionField(EditorReflectionFieldType.Field, typeof(Component))]
		public string fieldName = "";

		[EditorHelp("Is Property", "Check the value of a property.\n" +
			"If disabled, the value of a field will be checked.", "")]
		public bool isProperty = false;

		[EditorHelp("Is Array", "The field/property is an array.\n" +
			"A defined index of the array is used.", "")]
		public bool isArray = false;

		[EditorHelp("Array Index", "The index of the array that will be used.", "")]
		[EditorCondition("isArray", true)]
		[EditorAutoInit]
		[EditorEndCondition]
		public FloatValue<SchematicObjectSelection> arrayIndex;

		public SchematicParameterSetting valueType = new SchematicParameterSetting();

		public SchematicFieldCheck()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(data.Contains<int>("type"))
			{
				this.valueType = SchematicParameterSetting.UpgradeData(data);
			}
		}

		public System.Type FieldType
		{
			get
			{
				return this.valueType.settings is EnumSchematicParameterType ?
					null :
					this.valueType.settings.GetParameterType();
			}
		}

		private bool CheckArrayValue(Schematic schematic, object value)
		{
			System.Array array = value as System.Array;
			if(array != null)
			{
				object checkValue = this.valueType.settings is EnumSchematicParameterType ?
					(int)array.GetValue((int)this.arrayIndex.GetValue(schematic)) :
					array.GetValue((int)this.arrayIndex.GetValue(schematic));
				return checkValue != null && checkValue.Equals(this.valueType.settings.GetParameterValue(schematic));
			}
			else
			{
				System.Collections.IList list = value as System.Collections.IList;
				if(list != null)
				{
					object checkValue = this.valueType.settings is EnumSchematicParameterType ?
						(int)list[(int)this.arrayIndex.GetValue(schematic)] :
						list[(int)this.arrayIndex.GetValue(schematic)];
					return checkValue != null && checkValue.Equals(this.valueType.settings.GetParameterValue(schematic));
				}
			}
			return false;
		}

		public bool Check(object instance, System.Type instanceType, Schematic schematic, bool isStatic)
		{
			if(this.fieldName != "")
			{
				if(this.isProperty)
				{
					PropertyInfo propertyInfo = Maki.ReflectionHandler.GetProperty(
						this.fieldName, ref instance, ref instanceType);
					if(propertyInfo != null)
					{
						try
						{
							if(this.isArray)
							{
								return this.CheckArrayValue(schematic,
									propertyInfo.GetValue(isStatic ? null : instance, null));
							}
							else
							{
								object value = this.valueType.settings is EnumSchematicParameterType ?
									(int)propertyInfo.GetValue(isStatic ? null : instance, null) :
									propertyInfo.GetValue(isStatic ? null : instance, null);
								return value != null && value.Equals(this.valueType.settings.GetParameterValue(schematic));
							}
						}
						catch(System.Exception ex)
						{
							Debug.LogWarning("Property change failed (" + instanceType + "): " +
								this.fieldName + "\n" + ex.Message + "\n" + ex.StackTrace);
						}
					}
					else
					{
						Debug.LogWarning("Property not found (" + instanceType + "): " + this.fieldName);
					}
				}
				else
				{
					FieldInfo fieldInfo = Maki.ReflectionHandler.GetField(
						this.fieldName, ref instance, ref instanceType);
					if(fieldInfo != null)
					{
						try
						{
							if(this.isArray)
							{
								return this.CheckArrayValue(schematic,
									fieldInfo.GetValue(isStatic ? null : instance));
							}
							else
							{
								object value = this.valueType.settings is EnumSchematicParameterType ?
									(int)fieldInfo.GetValue(isStatic ? null : instance) :
									fieldInfo.GetValue(isStatic ? null : instance);
								return value != null && value.Equals(this.valueType.settings.GetParameterValue(schematic));
							}
						}
						catch(System.Exception ex)
						{
							Debug.LogWarning("Field change failed (" + instanceType + "): " +
								this.fieldName + "\n" + ex.Message + "\n" + ex.StackTrace);
						}
					}
					else
					{
						Debug.LogWarning("Field not found (" + instanceType + "): " + this.fieldName);
					}
				}
			}
			return false;
		}

		public override string ToString()
		{
			return this.fieldName + " == " + this.valueType.ToString();
		}
	}
}
