﻿
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom.Reflection
{
	[EditorSettingInfo("Audio Clip", "An audio clip.")]
	public class AudioClipParameterType<T> : BaseParameterType<T> where T : IObjectSelection, new()
	{
		[EditorHelp("Audio Clip", "Select the audio clip that will be used as parameter.", "")]
		public AssetSource<AudioClip> audioClip = new AssetSource<AudioClip>();

		public AudioClipParameterType()
		{

		}

		public override string ToString()
		{
			return this.audioClip.ToString();
		}

		public override System.Type GetParameterType()
		{
			return typeof(AudioClip);
		}

		public override object GetParameterValue(IDataCall call)
		{
			return this.audioClip.StoredAsset;
		}
	}
}
