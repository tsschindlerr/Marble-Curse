﻿
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom.Reflection
{
	[EditorSettingInfo("Float", "A float value.")]
	public class FloatParameterType<T> : BaseParameterType<T> where T : IObjectSelection, new()
	{
		[EditorHelp("Float Value", "Define the float value that will be used as parameter.", "")]
		public FloatValue<T> floatValue = new FloatValue<T>();

		public FloatParameterType()
		{

		}

		public override string ToString()
		{
			return this.floatValue.ToString();
		}

		public override bool NeedsCall
		{
			get
			{
				return this.floatValue.NeedsCall;
			}
		}

		public override System.Type GetParameterType()
		{
			return typeof(float);
		}

		public override object GetParameterValue(IDataCall call)
		{
			return this.floatValue.GetValue(call);
		}
	}
}
