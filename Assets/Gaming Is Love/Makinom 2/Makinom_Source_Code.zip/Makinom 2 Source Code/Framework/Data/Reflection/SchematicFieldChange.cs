
using UnityEngine;
using UnityEngine.Audio;
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.Schematics;
using System.Collections.Generic;
using System.Reflection;

namespace GamingIsLove.Makinom.Reflection
{
	public class SchematicFieldChange : FieldChange
	{
		// field
		[EditorHelp("Is Property", "Change the value of a property.\n" +
			"If disabled, the value of a field will be changed.", "")]
		public bool isProperty = false;

		[EditorHelp("Is Array", "The field/property is an array.\n" +
			"A defined index of the array is used.", "")]
		public bool isArray = false;

		[EditorHelp("Increase Size", "Increase the array's size if the array index exceed's the current size.", "")]
		[EditorIndent]
		[EditorCondition("isArray", true)]
		public bool increaseArraySize = false;

		[EditorHelp("Array Index", "The index of the array that will be used.", "")]
		[EditorAutoInit]
		[EditorEndCondition]
		public FloatValue<SchematicObjectSelection> arrayIndex;

		public SchematicParameterSetting valueType = new SchematicParameterSetting();

		public SchematicFieldChange()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(data.Contains<int>("type"))
			{
				this.valueType = SchematicParameterSetting.UpgradeData(data);
			}
		}

		public override bool IsProperty
		{
			get { return this.isProperty; }
		}

		public override System.Type FieldType
		{
			get
			{
				return this.valueType.settings is EnumSchematicParameterType ?
					null :
					this.valueType.settings.GetParameterType();
			}
		}

		private bool SetArrayValue(Schematic schematic, ref object value)
		{
			bool changed = false;
			System.Array array = value as System.Array;
			if(array != null)
			{
				int index = (int)this.arrayIndex.GetValue(schematic);
				if(this.increaseArraySize &&
					array.Length <= index)
				{
					changed = true;
					System.Type elementType = array.GetType().GetElementType();
					System.Array tmp = System.Array.CreateInstance(elementType, index + 1);
					System.Array.Copy(array, tmp, array.Length);
					for(int i = array.Length; i < tmp.Length; i++)
					{
						tmp.SetValue(ReflectionTypeHandler.Instance.CreateInstance(elementType), i);
					}
					tmp.SetValue(this.valueType.settings.GetParameterValue(schematic), index);
					value = System.Convert.ChangeType(tmp, array.GetType());
				}
				else
				{
					array.SetValue(this.valueType.settings.GetParameterValue(schematic), index);
				}
			}
			else
			{
				System.Collections.IList list = value as System.Collections.IList;
				if(list != null)
				{
					int index = (int)this.arrayIndex.GetValue(schematic);
					if(this.increaseArraySize &&
						list.Count <= index)
					{
						System.Type elementType = list.GetType().IsGenericType ?
							list.GetType().GetGenericArguments()[0] :
							list.GetType().GetElementType();
						if(elementType != null)
						{
							for(int i = list.Count; i <= index; i++)
							{
								list.Add(ReflectionTypeHandler.Instance.CreateInstance(elementType));
							}
						}
					}
					list[index] = this.valueType.settings.GetParameterValue(schematic);
				}
			}
			return changed;
		}

		public void Change(object instance, System.Type instanceType, Schematic schematic, bool isStatic)
		{
			if(this.fieldName != "")
			{
				if(this.isProperty)
				{
					PropertyInfo propertyInfo = Maki.ReflectionHandler.GetProperty(
						this.fieldName, ref instance, ref instanceType);
					if(propertyInfo != null)
					{
						try
						{
							if(this.isArray)
							{
								object value = propertyInfo.GetValue(isStatic ? null : instance, null);
								if(this.SetArrayValue(schematic, ref value))
								{
									propertyInfo.SetValue(isStatic ? null : instance, value, null);
								}
							}
							else
							{
								propertyInfo.SetValue(isStatic ? null : instance, this.valueType.settings.GetParameterValue(schematic), null);
							}
						}
						catch(System.Exception ex)
						{
							Debug.LogWarning("Property change failed (" + instanceType + "): " +
								this.fieldName + "\n" + ex.Message + "\n" + ex.StackTrace);
						}
					}
					else
					{
						Debug.LogWarning("Property not found (" + instanceType + "): " + this.fieldName);
					}
				}
				else
				{
					FieldInfo fieldInfo = Maki.ReflectionHandler.GetField(
						this.fieldName, ref instance, ref instanceType);
					if(fieldInfo != null)
					{
						try
						{
							if(this.isArray)
							{
								object value = fieldInfo.GetValue(isStatic ? null : instance);
								if(this.SetArrayValue(schematic, ref value))
								{
									fieldInfo.SetValue(isStatic ? null : instance, value);
								}
							}
							else
							{
								fieldInfo.SetValue(isStatic ? null : instance, this.valueType.settings.GetParameterValue(schematic));
							}
						}
						catch(System.Exception ex)
						{
							Debug.LogWarning("Field change failed (" + instanceType + "): " +
								this.fieldName + "\n" + ex.Message + "\n" + ex.StackTrace);
						}
					}
					else
					{
						Debug.LogWarning("Field not found (" + instanceType + "): " + this.fieldName);
					}
				}
			}
		}

		public override string ToString()
		{
			return this.fieldName + " = " + this.valueType.ToString();
		}
	}
}
