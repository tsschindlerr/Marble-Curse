
using UnityEngine;

namespace GamingIsLove.Makinom
{
	public class MusicClipsSettings : GenericAssetListSettings<MusicClipAsset, MusicClipSetting>
	{
		public MusicClipsSettings(MakinomProjectAsset project)
		{
			this.LoadProject(project);
			this.CreateGUIDLookup();
		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public override string Filename
		{
			get { return "Music Clips"; }
		}
	}
}

