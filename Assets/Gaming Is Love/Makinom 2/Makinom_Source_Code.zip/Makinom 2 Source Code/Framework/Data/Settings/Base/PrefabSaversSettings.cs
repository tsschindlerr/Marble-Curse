﻿
using UnityEngine;
using GamingIsLove.Makinom.Components;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	public class PrefabSaversSettings : GenericAssetListSettings<PrefabSaverAsset, PrefabSaver>
	{
		// in-game
		protected Dictionary<GameObject, PrefabSaver> savers = new Dictionary<GameObject, PrefabSaver>();

		public PrefabSaversSettings(MakinomProjectAsset project)
		{
			this.LoadProject(project);
			this.CreateGUIDLookup();
		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public override string Filename
		{
			get { return "Prefab Savers"; }
		}


		/*
		============================================================================
		Prefab functions
		============================================================================
		*/
		public virtual void Init()
		{
			this.savers.Clear();

			for(int i = 0; i < this.assets.Count; i++)
			{
				if(this.assets[i].Settings.prefab.StoredAsset != null)
				{
					this.savers.Add(this.assets[i].Settings.prefab.StoredAsset, this.assets[i].Settings);
				}
			}
		}

		public virtual void AddPrefabInstance(GameObject prefab, GameObject instance)
		{
			if(instance != null)
			{
				PrefabSaver prefabSaver = null;
				if(this.savers.TryGetValue(prefab, out prefabSaver))
				{
					instance.AddComponent<PrefabSaverComponent>().PrefabSaver = prefabSaver;
				}
			}
		}
	}
}
