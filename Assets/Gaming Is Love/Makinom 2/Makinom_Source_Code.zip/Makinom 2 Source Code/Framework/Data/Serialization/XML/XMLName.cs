
namespace GamingIsLove.Makinom.IO
{
	/// <summary>
	/// Contains all XML node names.
	/// </summary>
	public static class XMLName
	{
		/*
		============================================================================
		XML syntax strings
		============================================================================
		*/
		public static string CDATA_OPEN = "<![CDATA[";

		public static string CDATA_CLOSE = "]]>";

		public static string NEW_LINE = "\n";

		public static string TAB = "\t";

		public static string OPEN = "<";

		public static string OPEN_CLOSE = "</";

		public static string CLOSE = ">";

		public static string CLOSE_IMMEDIATE = "/>";

		public static string SPACE = " ";

		public static string EQUALS = "=";

		public static string QUOTE = "\"";

		public static string COMMENT_OPEN = "<!--";

		public static string COMMENT_CLOSE = "-->";

		public static string SLASH = "/";

		public static string QUESTION = "?";


		/*
		============================================================================
		Base data strings
		============================================================================
		*/
		public static string FLOAT = "_float";

		public static string BOOL = "_bool";

		public static string STRING = "_string";

		public static string STRING_CL = "/_string";

		public static string INT_ARRAYS = "_intarrays";

		public static string INT_ARRAYS_CL = "/_intarrays";

		public static string FLOAT_ARRAYS = "_floatarrays";

		public static string FLOAT_ARRAYS_CL = "/_floatarrays";

		public static string BOOL_ARRAYS = "_boolarrays";

		public static string BOOL_ARRAYS_CL = "/_boolarrays";

		public static string STRING_ARRAYS = "_stringarrays";

		public static string STRING_ARRAYS_CL = "/_stringarrays";

		public static string SUB_ARRAYS = "_subarrays";

		public static string SUB_ARRAYS_CL = "/_subarrays";

		public static string GENERALASSET = "_generalasset";
	}
}

