﻿
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	[EditorHelp("Node Group", "Use node groups to organize your nodes.", "")]
	public class NodeGroup : BaseNode
	{
		public static Vector2 DefaultSize = new Vector2(267, 115);

		[EditorHelp("Name", "The name of this node group.", "")]
		[EditorWidth(true)]
		public string name = "Group";

		[EditorHelp("Color", "The color of this node group.", "")]
		public Color groupColor = new Color(Random.Range(0.0f, 1.0f), Random.Range(0.0f, 1.0f), Random.Range(0.0f, 1.0f), 1);

		[EditorHelp("Text Color", "The text color of this node group (i.e. for the name)", "")]
		public Color textColor = Color.white;

		[EditorHide]
		public Vector2 size = NodeGroup.DefaultSize;


		// in-editor
		private int ownIndex = -1;

		private List<BaseNode> nodes;

		public NodeGroup()
		{

		}

		public NodeGroup(int count)
		{
			this.name = "Group " + (count + 1);
		}

		public void ClearNodes()
		{
			if(this.nodes != null)
			{
				this.nodes.Clear();
			}
			else
			{
				this.nodes = new List<BaseNode>();
			}
			this.size = NodeGroup.DefaultSize;
		}

		public int OwnIndex
		{
			get { return this.ownIndex; }
			set { this.ownIndex = value; }
		}

		public List<BaseNode> Nodes
		{
			get { return this.nodes; }
		}

		public void AddNode(BaseNode node)
		{
			this.nodes.Add(node);
		}

		public void RemoveNode(BaseNode node)
		{
			this.nodes.Remove(node);
		}
	}
}
