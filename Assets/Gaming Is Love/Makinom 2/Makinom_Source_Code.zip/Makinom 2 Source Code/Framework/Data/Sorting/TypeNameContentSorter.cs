
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	public class TypeNameContentSorter<T> : IComparer<T> where T : IContent
	{
		private bool invert = false;

		public TypeNameContentSorter(bool invert)
		{
			this.invert = invert;
		}

		public int Compare(T x, T y)
		{
			IContent xType = TypeContentHelper.Get(x);
			IContent yType = TypeContentHelper.Get(y);
			if(this.invert)
			{
				if(xType == null &&
					yType == null)
				{
					return 0;
				}
				else if(xType != null &&
					yType == null)
				{
					return 1;
				}
				else if(xType == null &&
					yType != null)
				{
					return -1;
				}
				else
				{
					int tmp = yType.ID.CompareTo(xType.ID);
					if(tmp == 0)
					{
						return y.GetName().CompareTo(x.GetName());
					}
					else
					{
						return tmp;
					}
				}
			}
			else
			{
				if(xType == null &&
					yType == null)
				{
					return 0;
				}
				else if(xType != null &&
					yType == null)
				{
					return -1;
				}
				else if(xType == null &&
					yType != null)
				{
					return 1;
				}
				else
				{
					int tmp = xType.ID.CompareTo(yType.ID);
					if(tmp == 0)
					{
						return x.GetName().CompareTo(y.GetName());
					}
					else
					{
						return tmp;
					}
				}
			}
		}
	}
}
