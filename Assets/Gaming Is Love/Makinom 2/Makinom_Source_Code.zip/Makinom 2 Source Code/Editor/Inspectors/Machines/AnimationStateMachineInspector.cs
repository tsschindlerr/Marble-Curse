
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.Editor;
using GamingIsLove.Makinom.Components;
using GamingIsLove.Makinom.Schematics;
using UnityEditor;
using UnityEngine;

[CustomEditor(typeof(AnimationStateMachineComponent))]
public class AnimationStateMachineInspector : BaseMachineInspector
{
	public override void OnInspectorGUI()
	{
		this.MachineSetup(target as AnimationStateMachineComponent);
	}

	private void MachineSetup(AnimationStateMachineComponent target)
	{
		Undo.RecordObject(target, "Change to 'Animation State Machine' on " + target.name);
		this.BaseInit(true);

		// tag settings
		if(this.baseEditor.BeginFoldout("Start Settings", "", "", true))
		{
			EditorAutomation.Automate(target.startSetting, this.baseEditor);

			EditorGUILayout.Separator();
		}
		this.baseEditor.EndFoldout();

		// machine execution settings
		if(!Application.isPlaying)
		{
			if(target.assetSetting.schematicAsset != null &&
				this.lastSchematicSaveTime != target.assetSetting.schematicAsset.SaveTime)
			{
				this.firstLoad = false;
			}
			if(!this.firstLoad)
			{
				this.firstLoad = true;
				target.LoadSchematic();

				if(target.assetSetting.schematicAsset != null)
				{
					this.lastSchematicSaveTime = target.assetSetting.schematicAsset.SaveTime;
				}
				else
				{
					this.lastSchematicSaveTime = "";
				}
			}
		}

		if(this.baseEditor.BeginFoldout("Machine Execution Settings", "", "", true))
		{
			this.ShowMachineSetup(target);
			EditorGUILayout.Separator();
		}
		this.baseEditor.EndFoldout();

		if(target.assetSetting.schematicAsset != null)
		{
			this.ShowMachineResources(target.resources, target.assetSetting.schematicAsset.Settings);
		}


		// condition settings
		if(this.baseEditor.BeginFoldout("Condition Settings", "", "", true))
		{
			EditorAutomation.Automate(target.conditionSetting, this.baseEditor);
			EditorGUILayout.Separator();
		}
		this.baseEditor.EndFoldout();


		// local start variables
		if(this.baseEditor.BeginFoldout("Local Start Variables", "", "", true))
		{
			EditorAutomation.Automate(target.startVariableSetting, this.baseEditor);
			EditorGUILayout.Separator();
		}
		this.baseEditor.EndFoldout();


		// change after execution
		if(this.baseEditor.BeginFoldout("Change After Execution", "", "", true))
		{
			EditorAutomation.Automate(target.changeAfterSetting, this.baseEditor);
			EditorGUILayout.Separator();
		}
		this.baseEditor.EndFoldout();

		this.EndSetup();
	}

	protected void ShowMachineSetup(AnimationStateMachineComponent target)
	{
		GamingIsLove.Makinom.MakinomSchematicAsset tmpAsset = target.assetSetting.schematicAsset;

		// buttons
		EditorGUILayout.BeginHorizontal();
		if(EditorTool.Button(new GUIContent("Create Schematic", EditorContent.Instance.PlusIcon)))
		{
			string path = EditorUtility.SaveFilePanelInProject("Save Schematic Asset", "", "asset",
				"Please enter the name of the asset file that will be created.\n" +
				"Existing files will be replaced!");
			if(path.Length != 0)
			{
				target.assetSetting.schematicAsset = MakinomAssetHelper.SaveSchematic(null, path);
				MakinomEditorWindow.ShowMakinomEditor(target.assetSetting.schematicAsset, target.RuntimeSchematic);
				EditorGUIUtility.ExitGUI();
			}
		}
		EditorGUI.BeginDisabledGroup(target.assetSetting.schematicAsset == null);
		if(EditorTool.Button(new GUIContent("Edit Schematic", EditorContent.Instance.EditIcon)))
		{
			MakinomEditorWindow.ShowMakinomEditor(target.assetSetting.schematicAsset, target.RuntimeSchematic);
			return;
		}
		EditorGUI.EndDisabledGroup();
		EditorGUILayout.EndHorizontal();

		// settings
		EditorAutomation.Automate(target.assetSetting, this.baseEditor);

		// check schematic asset file change
		if(tmpAsset != target.assetSetting.schematicAsset)
		{
			target.LoadSchematicEditor();
		}
	}
}
