﻿
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.Editor;
using GamingIsLove.Makinom.Components;
using UnityEditor;
using UnityEngine;

[CustomEditor(typeof(VariableChangerComponent))]
public class VariableChangerComponentInspector : BaseInspector
{
	public override void OnInspectorGUI()
	{
		this.ComponentSetup(target as VariableChangerComponent);
	}

	private void ComponentSetup(VariableChangerComponent target)
	{
		Undo.RecordObject(target, "Change to 'Variable Changer' on " + target.name);
		this.BaseInit(true);

		if(this.baseEditor.BeginFoldout("Variable Change Settings", "", "", true))
		{
			EditorAutomation.Automate(target.settings, this.baseEditor);
			EditorGUILayout.Separator();
		}
		this.baseEditor.EndFoldout();

		this.ShowBaseInteraction(target);

		this.EndSetup();
	}
}