
using GamingIsLove.Makinom;
using UnityEditor;
using UnityEngine;

namespace GamingIsLove.Makinom.Editor
{
	public class AnimationTemplatesTab : GenericAssetListTab<AnimationTemplateAsset, AnimationTemplate>
	{
		public AnimationTemplatesTab(MakinomEditorWindow parent) : base(parent)
		{

		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public override string Name
		{
			get { return "Animation Templates"; }
		}

		public override string HelpText
		{
			get
			{
				return "Set up animation information (e.g. playing a legacy animation or changing Mecanim parameters).\n" +
					"The defined animation can be used in schematics by using an 'Animation Template' node.\n" +
					"Animation templates allow you to set up reusable animations.";
			}
		}

		public override string HelpInfo
		{
			get { return ""; }
		}
	}
}

