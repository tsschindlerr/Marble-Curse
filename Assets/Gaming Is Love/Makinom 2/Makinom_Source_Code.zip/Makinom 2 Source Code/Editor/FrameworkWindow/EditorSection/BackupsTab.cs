
using GamingIsLove.Makinom;
using UnityEngine;
using UnityEditor;
using System.Collections.Generic;
using UnityEditor.SceneManagement;

namespace GamingIsLove.Makinom.Editor
{
	public sealed class BackupsTab : BaseEditorTab
	{
		private List<BackupInformation> backups;

		public BackupsTab(MakinomEditorWindow parent)
		{
			this.parent = parent;
		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public override string Name
		{
			get { return "Backups"; }
		}

		public override string HelpText
		{
			get { return "Show and restore available project backups."; }
		}

		public override string HelpInfo
		{
			get { return ""; }
		}

		protected override BaseSettings Settings
		{
			get { return Maki.Backups; }
		}

		protected override IBaseData DisplayedSettings
		{
			get { return Maki.Backups; }
		}


		/*
		============================================================================
		Settings display
		============================================================================
		*/
		public override void ShowSettings()
		{
			EditorAutomation.Automate(Maki.Backups, this);

			if(Maki.Backups.numberOfBackups < 0)
			{
				Maki.Backups.numberOfBackups = 0;
			}

			if(this.BeginFoldout("Backup List", "A list of all available backups and the option to restore them.", "", true))
			{
				if(EditorTool.Button("Check Backups", "Refresh the list of available backups.", "") ||
					this.Editor.checkBackups)
				{
					this.CheckBackups();
				}

				if(this.backups != null)
				{
					EditorTool.BoldLabel("Backups available: " + this.backups.Count);
					EditorGUILayout.Separator();

					EditorGUILayout.HelpBox("Restoring a backup will delete everything in the data folder " +
						"(usually 'Assets/Gaming Is Love/_Data/') before importing the contents of the backup unitypackage file.\n" + 
						"A backup of the data is created before deleting it, so you can restore it at a later time.\n\n" +
						"Restoring a backup will also reload the currently open scene, so make sure to save the scene if you want to keep any changes you've made.", 
						MessageType.Warning);
					EditorGUILayout.Separator();

					foreach(BackupInformation info in this.backups)
					{
						if(this.BeginFoldout(info.date, "Backup created on " + info.date + ".", "", true))
						{
							EditorTool.BoldLabel("Path");
							EditorTool.Label(info.path);

							EditorGUILayout.Separator();
							EditorGUILayout.BeginHorizontal();

							if(EditorTool.Button2("Restore Backup", "Loads the data of the backup.\n" +
								"You need to save the project to permanently restore the backup.", ""))
							{
								if(EditorUtility.DisplayDialog("Restore Backup",
									"Do you really want to restore this backup:\n" + info.path + "\n\n" +
									"- Unsaved data will be lost.\n" +
									"- A backup of the last save will be created.\n" +
									"- Everything in the data folder will be removed before unpacking the backup.\n" +
									"- Reloads the currently open scene after restoring the backup.\n" +
									"- Reload the Makinom editor.",
									"Restore", "Cancel"))
								{
									MakinomAssetHelper.CreateBackup();
									AssetDatabase.DeleteAsset(MakinomAssetHelper.DATA_PATH);
									MakinomAssetHelper.CreateFolder(MakinomAssetHelper.DATA_PATH);
									AssetDatabase.Refresh();
									AssetDatabase.importPackageCompleted += this.BackupRestored;
									AssetDatabase.ImportPackage(info.path, false);
								}
								this.Editor.Focus();
							}

							if(EditorTool.SmallButton2("Delete", "Delete this backup.", ""))
							{
								if(EditorUtility.DisplayDialog("Delete Backup",
									"Do you really want to delete this backup:\n" + info.path,
									"Delete", "Cancel"))
								{
									AssetDatabase.DeleteAsset(info.path);
									this.CheckBackups();
									break;
								}
								this.Editor.Focus();
							}

							GUILayout.FlexibleSpace();
							EditorGUILayout.EndHorizontal();
						}
						this.EndFoldout();
					}
				}
				EditorGUILayout.Separator();
			}
			this.EndFoldout();
		}

		private void BackupRestored(string path)
		{
			AssetDatabase.importPackageCompleted -= this.BackupRestored;
			AssetDatabase.Refresh();

			if(EditorUtility.DisplayDialog("Reloading",
				"Backup restored, now reloading current scene and the editor.", "Ok"))
			{
				EditorSceneManager.OpenScene(EditorSceneManager.GetActiveScene().path);
				this.Editor.ReloadData();
				this.CheckBackups();
			}
		}

		public void CheckBackups()
		{
			this.Editor.checkBackups = false;
			this.backups = this.GetBackupList();
		}

		private List<BackupInformation> GetBackupList()
		{
			List<BackupInformation> list = new List<BackupInformation>();
			List<string> tmp = MakinomAssetHelper.GetProjectBackups();
			for(int i = 0; i < tmp.Count; i++)
			{
				if(tmp[i] != null)
				{
					list.Add(new BackupInformation(tmp[i]));
				}
			}
			return list;
		}
	}
}

