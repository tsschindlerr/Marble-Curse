
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.Editor;
using UnityEditor;
using UnityEngine;

[CustomEditor(typeof(MakinomProjectAsset))]
public class ProjectAssetInspector : BaseInspector
{
	public override void OnInspectorGUI()
	{
		if(GUILayout.Button("Open Project"))
		{
			MakinomEditorWindow.ShowMakinomEditor((MakinomProjectAsset)target);
		}
		
		GUILayout.Label("Warning:\nThis asset contains your project data.\nDon't mess with it!");
		
		EditorGUILayout.Separator();
		GUILayout.Label("Save Time: "+((MakinomProjectAsset)target).SaveTime);
		GUILayout.Label("Version: "+((MakinomProjectAsset)target).Version);
	}
}
