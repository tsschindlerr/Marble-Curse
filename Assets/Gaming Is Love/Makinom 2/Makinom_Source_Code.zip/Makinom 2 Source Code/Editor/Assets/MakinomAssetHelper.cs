
using UnityEngine;
using UnityEditor;
using System.Collections.Generic;
using System.IO;
using GamingIsLove.Makinom.Schematics;

namespace GamingIsLove.Makinom.Editor
{
	public static class MakinomAssetHelper
	{
		/*
		============================================================================
		Project paths
		============================================================================
		*/
		public static string BACKUP_PATH = "Assets/Gaming Is Love/_Backups/";

		public static string DATA_PATH = "Assets/Gaming Is Love/_Data/";

		public static string SETTINGS_DATA_PATH = "Assets/Gaming Is Love/_Data/_Settings/";

		public static string[] DATA_SEARCH_PATH = new string[] { "Assets/Gaming Is Love/_Data" };

		public static string DOWNLOAD_PATH = "Assets/Gaming Is Love/_Downloads/";

		public static string PROJECT_PATH = "Assets/Gaming Is Love/_Data/Project.asset";

		public static string EDITOR_PATH = "Assets/Gaming Is Love/_Data/EditorData.asset";


		/*
		============================================================================
		Asset open functions
		============================================================================
		*/
		[UnityEditor.Callbacks.OnOpenAsset()]
		public static bool TryOpenSchematicAsset(int instanceID, int line)
		{
			UnityEngine.Object tmpObject = EditorUtility.InstanceIDToObject(instanceID);
			if(tmpObject is MakinomSchematicAsset)
			{
				MakinomEditorWindow.ShowMakinomEditor((MakinomSchematicAsset)tmpObject, null);
				return true;
			}
			return false;
		}

		[UnityEditor.Callbacks.OnOpenAsset()]
		public static bool TryOpenProjectAsset(int instanceID, int line)
		{
			UnityEngine.Object tmpObject = EditorUtility.InstanceIDToObject(instanceID);
			if(tmpObject is MakinomProjectAsset)
			{
				MakinomEditorWindow.ShowMakinomEditor((MakinomProjectAsset)tmpObject);
				return true;
			}
			return false;
		}


		/*
		============================================================================
		Menu create functions
		============================================================================
		*/
		[MenuItem("Assets/Create/Makinom Schematic")]
		public static void CreateSchematic()
		{
			MakinomSchematicAsset asset = ScriptableObject.CreateInstance<MakinomSchematicAsset>();
			asset.Version = Maki.VERSION;
			asset.SaveTime = System.DateTime.UtcNow.ToString();
			MakinomAssetHelper.CreateAsset(asset);
		}

		public static void CreateAsset<T>(T asset) where T : ScriptableObject
		{
			string path = AssetDatabase.GetAssetPath(Selection.activeObject);
			if(path == "")
			{
				path = "Assets";
			}
			else if(Path.GetExtension(path) != "")
			{
				path = path.Replace(Path.GetFileName(AssetDatabase.GetAssetPath(Selection.activeObject)), "");
			}

			string assetPathAndName = AssetDatabase.GenerateUniqueAssetPath(path + "/New " + typeof(T).ToString() + ".asset");

			AssetDatabase.CreateAsset(asset, assetPathAndName);
			EditorUtility.SetDirty(asset);
			AssetDatabase.SaveAssets();
			EditorUtility.FocusProjectWindow();
			Selection.activeObject = asset;
		}


		/*
		============================================================================
		Schematic Asset functions
		============================================================================
		*/
		public static MakinomSchematicAsset SaveSchematic(MakinomSchematicAsset asset, string path)
		{
			// select save path if it doesn't exist
			if(path == "")
			{
				path = EditorUtility.SaveFilePanelInProject("Save Schematic Asset", "", "asset",
					"Please enter the name of the asset file that will be created.\n" +
					"Existing files will be replaced!");
			}

			if(path != "")
			{
				if(asset == null)
				{
					asset = ScriptableObject.CreateInstance<MakinomSchematicAsset>();
				}
				else if(AssetDatabase.GetAssetPath(asset) != path)
				{
					MakinomSchematicAsset oldAsset = asset;
					asset = ScriptableObject.CreateInstance<MakinomSchematicAsset>();
					asset.SetData(oldAsset.Settings.GetData());
				}
				if(!AssetDatabase.Contains(asset))
				{
					AssetDatabase.CreateAsset(asset, path);
					EditorUtility.SetDirty(asset);
					AssetDatabase.SaveAssets();
				}
				asset.Version = Maki.VERSION;
				asset.SaveTime = System.DateTime.UtcNow.ToString();

				bool encrypted = false;
				DataFile.SaveFormatType format = DataFile.SaveFormatType.ByteArray;
				MakinomAssetHelper.GetSaveSettings(ref encrypted, ref format);
				asset.SaveData(encrypted, format);

				AssetDatabase.Refresh();
				EditorUtility.SetDirty(asset);
				AssetDatabase.SaveAssets();
				AssetDatabase.Refresh();
			}
			return asset;
		}

		public static void ChangeSavedSchematics(string folder)
		{
			if(EditorDataHandler.Instance.HasDataChanges)
			{
				bool encrypted = false;
				DataFile.SaveFormatType format = DataFile.SaveFormatType.ByteArray;
				MakinomAssetHelper.GetSaveSettings(ref encrypted, ref format);

				List<MakinomSchematicAsset> schematics = MakinomAssetHelper.GetAllAssets<MakinomSchematicAsset>(folder);
				for(int i = 0; i < schematics.Count; i++)
				{
					if(schematics[i] != null)
					{
						EditorDataHandler.Instance.UseDataChanges(schematics[i].Settings);
						schematics[i].SaveData(encrypted, format);
						EditorUtility.SetDirty(schematics[i]);
					}
				}
			}
		}

		public static void GetSchematicVariables(ref List<string> list, ref Dictionary<string, List<MakinomSchematicAsset>> keySchematic, string folder)
		{
			List<MakinomSchematicAsset> schematics = MakinomAssetHelper.GetAllAssets<MakinomSchematicAsset>(folder);
			for(int i = 0; i < schematics.Count; i++)
			{
				if(schematics[i] != null)
				{
					List<string> tmpList = new List<string>();
					DataSerializer.GetVariables(schematics[i].Settings, ref tmpList);

					for(int j = 0; j < tmpList.Count; j++)
					{
						if(!list.Contains(tmpList[j]))
						{
							list.Add(tmpList[j]);
						}
						List<MakinomSchematicAsset> assetList;
						if(!keySchematic.TryGetValue(tmpList[j], out assetList))
						{
							assetList = new List<MakinomSchematicAsset>();
							keySchematic.Add(tmpList[j], assetList);
						}
						assetList.Add(schematics[i]);
					}
				}
			}
		}

		public static void ReplaceSchematicVariable(string oldKey, string newKey,
			ref List<string> list, ref Dictionary<string, List<MakinomSchematicAsset>> keySchematic, string folder)
		{
			bool encrypted = false;
			DataFile.SaveFormatType format = DataFile.SaveFormatType.ByteArray;
			MakinomAssetHelper.GetSaveSettings(ref encrypted, ref format);

			AssetDatabase.Refresh();
			List<MakinomSchematicAsset> schematics = MakinomAssetHelper.GetAllAssets<MakinomSchematicAsset>(folder);
			for(int i = 0; i < schematics.Count; i++)
			{
				if(schematics[i] != null)
				{
					List<string> tmpList = new List<string>();
					bool changed = DataSerializer.ReplaceVariable(schematics[i].Settings, oldKey, newKey);
					DataSerializer.GetVariables(schematics[i].Settings, ref tmpList);

					for(int j = 0; j < tmpList.Count; j++)
					{
						if(!list.Contains(tmpList[j]))
						{
							list.Add(tmpList[j]);
						}
						List<MakinomSchematicAsset> assetList;
						if(!keySchematic.TryGetValue(tmpList[j], out assetList))
						{
							assetList = new List<MakinomSchematicAsset>();
							keySchematic.Add(tmpList[j], assetList);
						}
						assetList.Add(schematics[i]);
					}
					if(changed)
					{
						schematics[i].SaveData(encrypted, format);
						EditorUtility.SetDirty(schematics[i]);
					}
				}
			}
			AssetDatabase.SaveAssets();
			AssetDatabase.Refresh();
		}

		public static List<T> GetAllAssets<T>(string folder) where T : UnityEngine.Object
		{
			List<T> list = new List<T>();

			string[] guids = folder != "" ?
				AssetDatabase.FindAssets("t:" + typeof(T).Name, new string[] { "Assets/" + folder }) :
				AssetDatabase.FindAssets("t:" + typeof(T).Name);
			for(int i = 0; i < guids.Length; i++)
			{
				T asset = AssetDatabase.LoadAssetAtPath<T>(AssetDatabase.GUIDToAssetPath(guids[i]));
				if(asset != null)
				{
					list.Add(asset);
				}
			}
			return list;
		}


		/*
		============================================================================
		Project Asset functions
		============================================================================
		*/
		public static void SaveProjectAsset(Dictionary<string, DataFile> fileList, bool encrypt, bool saveAssetDatabase, string saveTime)
		{
			MakinomProjectAsset project = Maki.Data.ProjectAsset;
			if(project == null)
			{
				project = MakinomAssetHelper.LoadProjectAsset();
			}
			project.Version = Maki.VERSION;
			project.SaveTime = saveTime;

			Dictionary<string, MakinomSettingsAsset> assetList = new Dictionary<string, MakinomSettingsAsset>();

			MakinomAssetHelper.CreateFolder(MakinomAssetHelper.SETTINGS_DATA_PATH);
			foreach(KeyValuePair<string, DataFile> pair in fileList)
			{
				string path = MakinomAssetHelper.SETTINGS_DATA_PATH + pair.Key + ".asset";
				MakinomSettingsAsset asset = AssetDatabase.LoadAssetAtPath<MakinomSettingsAsset>(path);
				if(asset == null)
				{
					asset = ScriptableObject.CreateInstance<MakinomSettingsAsset>();
					AssetDatabase.CreateAsset(asset, path);
					EditorUtility.SetDirty(asset);
					AssetDatabase.SaveAssets();
					if(saveAssetDatabase)
					{
						AssetDatabase.Refresh();
					}
				}
				if(pair.Value != null)
				{
					asset.Data = pair.Value;
					EditorUtility.SetDirty(asset);
				}
				assetList.Add(pair.Key, asset);
			}
			project.ClearData();

			foreach(KeyValuePair<string, MakinomSettingsAsset> pair in assetList)
			{
				project.AddData(pair.Key, pair.Value);
			}

			EditorUtility.SetDirty(project);
			if(saveAssetDatabase)
			{
				AssetDatabase.SaveAssets();
				AssetDatabase.Refresh();
			}
			Maki.Data.ProjectAsset = project;
		}

		public static MakinomProjectAsset LoadProjectAsset()
		{
			MakinomEditorAsset editorAsset = MakinomAssetHelper.LoadEditorAsset();

			MakinomProjectAsset project = null;
			if(editorAsset.LastProject != null)
			{
				project = editorAsset.LastProject;
			}
			else
			{
				project = AssetDatabase.LoadAssetAtPath<MakinomProjectAsset>(MakinomAssetHelper.PROJECT_PATH);
			}

			if(project == null)
			{
				project = ScriptableObject.CreateInstance<MakinomProjectAsset>();
				project.Version = Maki.VERSION;
				project.SaveTime = System.DateTime.UtcNow.ToString();
				MakinomAssetHelper.CreateFolder(MakinomAssetHelper.DATA_PATH);
				AssetDatabase.CreateAsset(project, MakinomAssetHelper.PROJECT_PATH);
				EditorUtility.SetDirty(project);
				AssetDatabase.SaveAssets();
			}

			return project;
		}

		public static MakinomProjectAsset CreateProjectAsset(string path)
		{
			MakinomProjectAsset project = ScriptableObject.CreateInstance<MakinomProjectAsset>();
			project.Version = Maki.VERSION;
			project.SaveTime = System.DateTime.UtcNow.ToString();

			AssetDatabase.CreateAsset(project, path);
			EditorUtility.SetDirty(project);
			AssetDatabase.SaveAssets();

			return project;
		}

		public static void CreateBackup()
		{
			if(Maki.Data.ProjectAsset != null &&
				Maki.Backups.numberOfBackups > 0)
			{
				MakinomAssetHelper.CreateFolder(MakinomAssetHelper.BACKUP_PATH);
				AssetDatabase.ExportPackage(
					MakinomAssetHelper.DATA_PATH.EndsWith("/") ?
						MakinomAssetHelper.DATA_PATH.Substring(0, MakinomAssetHelper.DATA_PATH.Length - 1) : MakinomAssetHelper.DATA_PATH,
					Application.dataPath +
						(MakinomAssetHelper.BACKUP_PATH.StartsWith("Assets/") ? MakinomAssetHelper.BACKUP_PATH.Substring(6) : MakinomAssetHelper.BACKUP_PATH) +
						System.DateTime.UtcNow.Ticks.ToString() + ".unitypackage",
					ExportPackageOptions.Recurse);

				// clear backups exceeding the maximum backups
				List<string> backups = MakinomAssetHelper.GetProjectBackups();
				if(backups.Count > Maki.Backups.numberOfBackups)
				{
					int difference = backups.Count - Maki.Backups.numberOfBackups;
					for(int i = 0; i < difference; i++)
					{
						AssetDatabase.DeleteAsset(backups[i]);
					}
				}
			}
		}

		public static List<string> GetProjectBackups()
		{
			List<string> list = new List<string>();
			if(Directory.Exists(MakinomAssetHelper.BACKUP_PATH))
			{
				string[] files = Directory.GetFiles(MakinomAssetHelper.BACKUP_PATH);
				for(int i = 0; i < files.Length; i++)
				{
					if(files[i].EndsWith(".unitypackage"))
					{
						list.Add(files[i]);
					}
				}
			}
			return list;
		}


		/*
		============================================================================
		Editor Asset functions
		============================================================================
		*/
		public static MakinomEditorAsset LoadEditorAsset()
		{
			MakinomEditorAsset asset = (MakinomEditorAsset)AssetDatabase.
				LoadAssetAtPath<MakinomEditorAsset>(MakinomAssetHelper.EDITOR_PATH);
			if(asset == null)
			{
				asset = ScriptableObject.CreateInstance<MakinomEditorAsset>();
				MakinomAssetHelper.CreateFolder(MakinomAssetHelper.DATA_PATH);
				AssetDatabase.CreateAsset(asset, MakinomAssetHelper.EDITOR_PATH);
				EditorUtility.SetDirty(asset);
				AssetDatabase.SaveAssets();
			}
			return asset;
		}

		public static void SaveEditorAsset(MakinomEditorAsset asset)
		{
			if(asset != null)
			{
				EditorUtility.SetDirty(asset);
				AssetDatabase.SaveAssets();
				AssetDatabase.Refresh();
			}
		}

		public static void GetSaveSettings(ref bool encrypted, ref DataFile.SaveFormatType format)
		{
			if(Maki.Initialized)
			{
				encrypted = Maki.GameSettings.encryptData;
				format = Maki.GameSettings.dataSaveFormat;
			}
			else
			{
				MakinomEditorAsset editorAsset = MakinomAssetHelper.LoadEditorAsset();
				if(editorAsset != null)
				{
					encrypted = editorAsset.LastEncrypted;
					format = editorAsset.LastSaveFormat;
				}
			}
		}


		/*
		============================================================================
		Prefab functions
		============================================================================
		*/
		public static List<GameObject> GetAllPrefabs()
		{
			List<GameObject> list = new List<GameObject>();
			string[] files = Directory.GetFiles(Application.dataPath, "*.prefab", SearchOption.AllDirectories);
			for(int i = 0; i < files.Length; i++)
			{
				files[i] = files[i].Replace("\\", "/");
				if(files[i].StartsWith(Application.dataPath))
				{
					files[i] = files[i].Replace(Application.dataPath, "Assets");
				}
				GameObject prefab = (GameObject)AssetDatabase.LoadAssetAtPath<GameObject>(files[i]);
				if(prefab != null)
				{
					list.Add(prefab);
				}
			}
			return list;
		}


		/*
		============================================================================
		Folder functions
		============================================================================
		*/
		public static void CreateFolder(string folder)
		{
			if(!Directory.Exists(folder))
			{
				Directory.CreateDirectory(folder);
			}
		}
	}
}
