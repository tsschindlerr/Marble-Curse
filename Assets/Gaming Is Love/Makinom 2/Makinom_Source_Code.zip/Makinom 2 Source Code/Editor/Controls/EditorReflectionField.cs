
using UnityEngine;
using UnityEditor;
using GamingIsLove.Makinom;
using System.Reflection;
using System.Collections.Generic;
using System.Text;

namespace GamingIsLove.Makinom.Editor
{
	public class EditorReflectionField
	{
		public enum Type { Class, Function, Field, Property, Enum };

		private MakinomEditorWindow parent;


		// value
		private string originalValue = "";

		private string lastValue = "";

		private string nextValue = "";

		private bool setNextValue = false;


		// popup
		private Rect lastBounds;

		private bool firstUse = true;

		private bool isInspector = false;


		// info
		private bool updateInfos = true;

		private List<string> infos;


		// data
		private EditorReflectionField.Type reflectionType;

		private System.Type baseType;

		private System.Type fieldType;

		private string className = "";

		public EditorReflectionField()
		{

		}

		public void Clear()
		{
			this.setNextValue = false;
			this.nextValue = "";
			this.originalValue = "";
			this.lastValue = "";
		}

		public void Edit(GUIContent content, ref string value, string helpInfo,
			AttributeHelper attributes, BaseEditor baseEditor,
			string className, EditorReflectionField.Type reflectionType, System.Type fieldType)
		{
			if(this.setNextValue &&
				Event.current.type == EventType.Repaint)
			{
				this.setNextValue = false;
				value = this.nextValue;
				this.nextValue = "";
				GUI.FocusControl(null);
			}
			if(this.lastValue != value)
			{
				this.updateInfos = true;
				this.infos = null;
			}

			if(this.parent == null &&
				baseEditor != null &&
				!baseEditor.isInspector)
			{
				this.parent = baseEditor is BaseEditorTab ?
					((BaseEditorTab)baseEditor).Editor :
					MakinomEditorWindow.Instance;
			}

			this.reflectionType = reflectionType;
			this.baseType = attributes.reflection.baseType;
			this.fieldType = fieldType;
			this.className = className;

			// layout
			GUIContent title = content;
			GUILayoutOption layout = EditorTool.WIDTH;
			if(baseEditor != null && baseEditor.isInspector)
			{
				if(attributes != null &&
					attributes.width != null &&
					attributes.width.hideName)
				{
					layout = GUILayout.MaxWidth(Screen.width - EditorGUIUtility.labelWidth - 130);
				}
				else
				{
					layout = attributes.width.GetWidth();
				}
				if(baseEditor.inspectorHideNextName)
				{
					title = new GUIContent("", title.tooltip);
					baseEditor.inspectorHideNextName = false;
				}
				this.isInspector = true;
			}
			else if(attributes != null &&
				attributes.width != null)
			{
				if(attributes.width.hideName)
				{
					title = new GUIContent("", title.tooltip);
				}
				layout = attributes.width.GetWidth();
			}

			// field
			EditorGUILayout.BeginHorizontal();
			EditorTool.BeginSetting(content.text, false);

			this.lastValue = value;
			value = EditorGUILayout.TextField(title, value, layout);

			if(Maki.EditorSettings.autoReflectionPopup)
			{
				// cancel value
				if(this.firstUse &&
					this.lastValue != value)
				{
					this.firstUse = false;
					this.originalValue = this.lastValue;
				}

				if(GUI.GetNameOfFocusedControl() == content.text)
				{
					if(Event.current.type == EventType.Repaint)
					{
						this.lastBounds = GUILayoutUtility.GetLastRect();
						this.lastBounds.x += EditorGUIUtility.labelWidth + 2;
						this.lastBounds.width -= EditorGUIUtility.labelWidth - 2;
						this.lastBounds.height = 0;
					}
					else if(Event.current.type == EventType.KeyUp &&
						Event.current.keyCode != KeyCode.Return &&
						Event.current.keyCode != KeyCode.KeypadEnter)
					{
						if(this.firstUse)
						{
							this.firstUse = false;
							this.originalValue = this.lastValue;
						}
						int textCursor = -1;
						int textSelection = -1;
						TextEditor editor = EditorReflection.Instance.GetTextEditor();
						if(editor != null)
						{
							textCursor = editor.cursorIndex;
							textSelection = editor.selectIndex;
						}

						PopupWindow.Show(this.lastBounds,
							new PopupListWindow(value, this.lastBounds.width,
								EditorGUIUtility.GUIToScreenPoint(new Vector2(this.lastBounds.x, this.lastBounds.y)),
								textCursor, textSelection,
								this.ValueSelected, this.PopupCanceled, this.PopupClosed, this.UpdatePopupList, baseEditor));
						Event.current.Use();
					}
				}
			}

			EditorTool.EndSetting(content.text, content.tooltip, helpInfo, false);

			// popup
			if(EditorTool.Button(EditorContent.Instance.EditIcon, EditorTool.WIDTH_30))
			{
				List<string> found = new List<string>();
				this.UpdatePopupList(value, baseEditor, ref found);

				if(found != null && found.Count > 0)
				{
					GenericMenu popup = new GenericMenu();
					for(int i = 0; i < found.Count; i++)
					{
						popup.AddItem(new GUIContent(found[i]), false, this.ContextSelected, found[i]);
					}
					popup.ShowAsContext();
				}
			}

			EditorGUILayout.EndHorizontal();


			// parameter info
			if(EditorReflectionField.Type.Function == reflectionType)
			{
				if(value != this.lastValue || this.updateInfos)
				{
					this.updateInfos = false;
					this.infos = EditorReflection.Instance.GetFunctionParameters(
						className, value, this.baseType);
				}

				if(this.infos != null)
				{
					for(int i = 0; i < this.infos.Count; i++)
					{
						EditorTool.Label(this.infos[i]);
					}
				}
			}
		}

		private void ContextSelected(System.Object userData)
		{
			if(userData is string)
			{
				this.setNextValue = true;
				this.nextValue = (string)userData;
			}
		}

		private void ValueSelected(string value)
		{
			this.setNextValue = true;
			this.nextValue = value;
			this.updateInfos = true;
		}

		private void PopupCanceled()
		{
			this.setNextValue = true;
			this.nextValue = this.originalValue;
		}

		private void PopupClosed()
		{
			this.firstUse = true;
			if(!this.isInspector &&
				this.parent != null)
			{
				this.parent.Focus();
			}
		}

		private void UpdatePopupList(string value, BaseEditor baseEditor, ref List<string> list)
		{
			list.Clear();
			List<string> found = null;

			if(EditorReflectionField.Type.Class == this.reflectionType)
			{
				found = EditorReflection.Instance.GetClassList(value, this.baseType);
			}
			else if(EditorReflectionField.Type.Function == this.reflectionType)
			{
				found = EditorReflection.Instance.GetClassFunctions(value, this.className, this.baseType);
			}
			else if(EditorReflectionField.Type.Field == this.reflectionType)
			{
				found = EditorReflection.Instance.GetClassFields(value, this.className, this.baseType, this.fieldType);
			}
			else if(EditorReflectionField.Type.Property == this.reflectionType)
			{
				found = EditorReflection.Instance.GetClassProperties(value, this.className, this.baseType, this.fieldType);
			}
			else if(EditorReflectionField.Type.Enum == this.reflectionType)
			{
				found = EditorReflection.Instance.GetEnumList(value);
			}

			if(found != null)
			{
				list.AddRange(found);
			}
		}
	}
}
