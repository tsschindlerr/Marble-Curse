
using UnityEngine;
using UnityEditor;
using System.Collections.Generic;
using System.Threading;

namespace GamingIsLove.Makinom.Editor
{
	public class Grid
	{
		private Texture2D backgroundTexture;

		// position
		private Rect bounds;

		private Rect viewBounds;


		// lines
		private Color lineColor;

		private Color fullLineColor;

		private Color backgroundColor;

		private int gridSize;

		private int spacing;

		private int separations = 4;


		// vertical
		private int verticalCount;

		private List<GridLine> verticalLines;


		// horizontal
		private int horizontalCount;

		private List<GridLine> horizontalLines;

		public Grid(int gridSize, int separations, Color lineColor, Color fullLineColor, Color backgroundColor)
		{
			this.gridSize = gridSize;
			this.separations = separations;

			this.lineColor = lineColor;
			this.fullLineColor = fullLineColor;
			this.backgroundColor = backgroundColor;

			this.bounds = new Rect(0, 0, 1, 1);
			this.viewBounds = new Rect(0, 0, 1, 1);

			this.spacing = this.gridSize / this.separations;

			this.verticalLines = new List<GridLine>();
			this.horizontalLines = new List<GridLine>();
		}

		public Texture2D BackgroundTexture
		{
			get
			{
				if(this.backgroundTexture == null)
				{
					this.backgroundTexture = new Texture2D(1, 1);
					this.backgroundTexture.SetPixel(0, 0, backgroundColor);
					this.backgroundTexture.Apply();
				}
				return this.backgroundTexture;
			}
		}

		public void SetBounds(Rect bounds, Rect viewBounds)
		{
			this.viewBounds = viewBounds;
			this.viewBounds.x = 0;
			this.viewBounds.y = 0;

			if(bounds.x > 0)
			{
				float tmp = Mathf.Ceil(bounds.x / this.gridSize) * this.gridSize;
				bounds.x -= tmp;
				bounds.width += tmp;
			}
			if(bounds.y > 0)
			{
				float tmp = Mathf.Ceil(bounds.y / this.gridSize) * this.gridSize;
				bounds.y -= tmp;
				bounds.height += tmp;
			}

			if(this.bounds != bounds)
			{
				this.bounds = bounds;
				this.UpdateLines();
			}
		}

		public void ShowGrid(bool onlySeparations)
		{
			if(Event.current.type != EventType.Repaint)
			{
				return;
			}
			GUI.DrawTexture(this.viewBounds, this.BackgroundTexture, ScaleMode.StretchToFill);

			if(GLTool.Material != null)
			{
				GLTool.Material.SetPass(0);
			}

			GL.Begin(GL.LINES);

			if(onlySeparations)
			{
				GL.Color(this.fullLineColor);
				for(int i = 0; i < this.verticalLines.Count; i += this.separations)
				{
					if(this.verticalLines[i].start.x >= this.viewBounds.x &&
						this.verticalLines[i].start.x <= this.viewBounds.x + this.viewBounds.width)
					{
						GL.Vertex(this.GetInViewBounds(this.verticalLines[i].start));
						GL.Vertex(this.GetInViewBounds(this.verticalLines[i].end));
					}
				}
				for(int i = 0; i < this.horizontalLines.Count; i += this.separations)
				{
					if(this.horizontalLines[i].start.y >= this.viewBounds.y &&
						this.horizontalLines[i].start.y <= this.viewBounds.y + this.viewBounds.height)
					{
						GL.Vertex(this.GetInViewBounds(this.horizontalLines[i].start));
						GL.Vertex(this.GetInViewBounds(this.horizontalLines[i].end));
					}
				}
			}
			else
			{
				for(int i = 0; i < this.verticalLines.Count; i++)
				{
					if(this.verticalLines[i].start.x >= this.viewBounds.x &&
						this.verticalLines[i].start.x <= this.viewBounds.x + this.viewBounds.width)
					{
						if(i % this.separations == 0)
						{
							GL.Color(this.fullLineColor);
						}
						else
						{
							GL.Color(this.lineColor);
						}
						GL.Vertex(this.GetInViewBounds(this.verticalLines[i].start));
						GL.Vertex(this.GetInViewBounds(this.verticalLines[i].end));
					}
				}
				for(int i = 0; i < this.horizontalLines.Count; i++)
				{
					if(this.horizontalLines[i].start.y >= this.viewBounds.y &&
						this.horizontalLines[i].start.y <= this.viewBounds.y + this.viewBounds.height)
					{
						if(i % this.separations == 0)
						{
							GL.Color(this.fullLineColor);
						}
						else
						{
							GL.Color(this.lineColor);
						}
						GL.Vertex(this.GetInViewBounds(this.horizontalLines[i].start));
						GL.Vertex(this.GetInViewBounds(this.horizontalLines[i].end));
					}
				}
			}

			GL.End();
		}

		private Vector2 GetInViewBounds(Vector2 point)
		{
			if(this.bounds != this.viewBounds)
			{
				if(point.x < this.viewBounds.x)
				{
					point.x = this.viewBounds.x;
				}
				else if(point.x > this.viewBounds.x + this.viewBounds.width)
				{
					point.x = this.viewBounds.x + this.viewBounds.width;
				}
				if(point.y < this.viewBounds.y)
				{
					point.y = this.viewBounds.y;
				}
				else if(point.y > this.viewBounds.y + this.viewBounds.height)
				{
					point.y = this.viewBounds.y + this.viewBounds.height;
				}
			}
			return point;
		}


		/*
		============================================================================
		Line functions
		============================================================================
		*/
		private void UpdateLines()
		{
			this.verticalLines = new List<GridLine>();
			this.horizontalLines = new List<GridLine>();

			this.verticalCount = (int)(this.bounds.width / this.spacing + 1);
			this.horizontalCount = (int)(this.bounds.height / this.spacing + 1);

			this.CreateLines();
		}

		private void CreateLines()
		{
			if(this.verticalLines != null && this.horizontalLines != null)
			{
				for(int i = 0; i < this.verticalCount; i++)
				{
					this.verticalLines.Add(this.CreateVerticalLine(i));
				}

				for(int i = 0; i < this.horizontalCount; i++)
				{
					this.horizontalLines.Add(this.CreateHorizontalLine(i));
				}
			}
		}

		private GridLine CreateVerticalLine(int index)
		{
			Vector2 start = new Vector2(index * this.spacing + this.bounds.x, this.bounds.y);
			Vector2 end = new Vector2(start.x, this.bounds.height + this.bounds.y);

			return new GridLine(start, end);
		}

		private GridLine CreateHorizontalLine(int index)
		{
			Vector2 start = new Vector2(this.bounds.x, index * this.spacing + this.bounds.y);
			Vector2 end = new Vector2(this.bounds.width + this.bounds.x, start.y);

			return new GridLine(start, end);
		}

		private class GridLine
		{
			public Vector2 start;

			public Vector2 end;

			public GridLine(Vector2 start, Vector2 end)
			{
				this.start = start;
				this.end = end;
			}
		}
	}
}
