
using GamingIsLove.ORKFramework;
using UnityEngine;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework.Components
{
	[AddComponentMenu("ORK Framework/Camera Control/Smooth Follow Camera")]
	public class SmoothFollow : BaseCameraControl, ISerializationCallbackReceiver
	{
		[System.NonSerialized]
		public FollowCameraSettings settings = new FollowCameraSettings();

		[SerializeField]
		[HideInInspector]
		protected ComponentDataFile serialize_setting;

		public override bool UseUnscaledTime
		{
			get { return this.settings.useUnscaledTime; }
		}

		protected virtual void LateUpdate()
		{
			GameObject targetObject = this.settings.childObject.GetChild(this.CameraTarget);
			if(targetObject != null)
			{
				float wantedRotationAngle = targetObject.transform.eulerAngles.y;
				float wantedHeight = targetObject.transform.position.y + this.settings.height;

				float currentRotationAngle = this.transform.eulerAngles.y;
				float currentHeight = this.transform.position.y;

				if(this.settings.rotationDamping > 0)
				{
					currentRotationAngle = Mathf.LerpAngle(
						currentRotationAngle, wantedRotationAngle,
						this.settings.rotationDamping * this.DeltaTime);
				}
				else
				{
					currentRotationAngle = wantedRotationAngle;
				}

				if(this.settings.heightDamping > 0)
				{
					currentHeight = Mathf.Lerp(currentHeight, wantedHeight, this.settings.heightDamping * this.DeltaTime);
				}
				else
				{
					currentHeight = wantedHeight;
				}

				Quaternion currentRotation = Quaternion.Euler(0, currentRotationAngle, 0);

				Vector3 position = targetObject.transform.position;
				position -= currentRotation * Vector3.forward * this.settings.distance;
				position.y = currentHeight;

				this.UpdatePosition(position,
					VectorHelper.LookAt(position, targetObject.transform.position));
			}
		}


		/*
		============================================================================
		Serialization functions
		============================================================================
		*/
		public virtual void OnBeforeSerialize()
		{
			this.serialize_setting = this.settings.GetData().GetComponentDataFile("settings", false);
		}

		public virtual void OnAfterDeserialize()
		{
			if(this.serialize_setting != null)
			{
				this.settings.SetData(this.serialize_setting.ToDataObject());
				this.serialize_setting = null;
			}
		}
	}
}
