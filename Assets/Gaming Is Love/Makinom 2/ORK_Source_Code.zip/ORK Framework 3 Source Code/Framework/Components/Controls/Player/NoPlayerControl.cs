﻿
using UnityEngine;
using System.Collections;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework.Components
{
	[AddComponentMenu("ORK Framework/Player Control/No Player Control")]
	public class NoPlayerControl : MonoBehaviour
	{

	}
}
