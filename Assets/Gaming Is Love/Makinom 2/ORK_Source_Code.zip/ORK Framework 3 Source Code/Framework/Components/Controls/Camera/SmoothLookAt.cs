
using GamingIsLove.ORKFramework;
using UnityEngine;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework.Components
{
	[AddComponentMenu("ORK Framework/Camera Control/Smooth Look At Camera")]
	public class SmoothLookAt : BaseCameraControl, ISerializationCallbackReceiver
	{
		[System.NonSerialized]
		public LookCameraSettings settings = new LookCameraSettings();

		[SerializeField]
		[HideInInspector]
		protected ComponentDataFile serialize_setting;

		public override bool UseUnscaledTime
		{
			get { return this.settings.useUnscaledTime; }
		}

		void Start()
		{
			Rigidbody rigidbody = this.GetComponent<Rigidbody>();
			if(rigidbody != null)
			{
				rigidbody.freezeRotation = true;
			}
		}

		void LateUpdate()
		{
			GameObject targetObject = this.settings.childObject.GetChild(this.CameraTarget);
			if(targetObject != null)
			{
				Quaternion rotation = VectorHelper.LookAt(this.transform.position,
					targetObject.transform.position);

				if(this.settings.smooth &&
					this.settings.damping > 0)
				{
					rotation = Quaternion.Slerp(
						this.transform.rotation, rotation,
						this.DeltaTime * this.settings.damping);
				}

				this.UpdatePosition(this.transform.position, rotation);
			}
		}


		/*
		============================================================================
		Serialization functions
		============================================================================
		*/
		public virtual void OnBeforeSerialize()
		{
			this.serialize_setting = this.settings.GetData().GetComponentDataFile("settings", false);
		}

		public virtual void OnAfterDeserialize()
		{
			if(this.serialize_setting != null)
			{
				this.settings.SetData(this.serialize_setting.ToDataObject());
				this.serialize_setting = null;
			}
		}
	}
}
