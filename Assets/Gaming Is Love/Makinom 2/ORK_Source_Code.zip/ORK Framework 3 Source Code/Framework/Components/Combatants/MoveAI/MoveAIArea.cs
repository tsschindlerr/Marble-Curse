﻿
using UnityEngine;
using System.Collections.Generic;
using GamingIsLove.Makinom;
using GamingIsLove.ORKFramework;

namespace GamingIsLove.ORKFramework.Components
{
	[AddComponentMenu("ORK Framework/Move AI/Move AI Area")]
	public class MoveAIArea : BaseColliderZone, ISerializationCallbackReceiver
	{
		[System.NonSerialized]
		public Settings settings = new Settings();

		[SerializeField]
		[HideInInspector]
		protected ComponentDataFile serialize_setting;

		protected virtual void OnEnable()
		{
			this.gameObject.layer = 2;
			if(this.Collider == null &&
				this.Collider2D == null)
			{
				UnityWrapper.Destroy(this.gameObject);
			}
			else
			{
				ORK.Game.Scene.AddMoveAIArea(this);
			}
		}

		protected virtual void OnDisable()
		{
			ORK.Game.Scene.RemoveMoveAIArea(this);
		}


		/*
		============================================================================
		Gizmo functions
		============================================================================
		*/
		protected virtual void OnDrawGizmos()
		{
			Gizmos.DrawIcon(transform.position, "/GamingIsLove/ORKFramework/Components/MoveAIArea Icon.png");
		}


		/*
		============================================================================
		Serialization functions
		============================================================================
		*/
		public virtual void OnBeforeSerialize()
		{
			this.serialize_setting = this.settings.GetData().GetComponentDataFile("settings", false);
		}

		public virtual void OnAfterDeserialize()
		{
			if(this.serialize_setting != null)
			{
				this.settings.SetData(this.serialize_setting.ToDataObject());
				this.serialize_setting = null;
			}
		}


		/*
		============================================================================
		Settings class
		============================================================================
		*/
		public class Settings : BaseData
		{
			[EditorHelp("Allow Move AI", "This zone allows using the move AI.")]
			public bool allowMoveAI = false;

			[EditorHelp("Use In Field", "This zone is used in the field (i.e. when not in battle).")]
			public bool usedInField = true;

			[EditorHelp("Use In Battle", "This zone is used while in battles.")]
			public bool usedInBattle = true;

			public Settings()
			{

			}
		}
	}
}
