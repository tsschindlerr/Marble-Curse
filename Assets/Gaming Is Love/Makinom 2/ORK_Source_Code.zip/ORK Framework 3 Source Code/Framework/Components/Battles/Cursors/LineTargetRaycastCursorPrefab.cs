﻿
using UnityEngine;
using GamingIsLove.Makinom;
using System.Collections.Generic;

namespace GamingIsLove.ORKFramework.Components
{
	[AddComponentMenu("ORK Framework/Battle/Target Raycast Cursor: Line")]
	public class LineTargetRaycastCursorPrefab : MonoBehaviour, ITargetRaycastCursorPrefab
	{
		public LineRenderer lineRenderer;

		public Vector3 userOffset = Vector3.zero;

		public Vector3 targetOffset = Vector3.zero;

		public bool adjustInlinePositions = true;


		// in-game
		protected Vector3[] position;

		protected Vector3[] originalPosition;

		protected Combatant user;

		protected BaseAction action;

		protected virtual void Reset()
		{
			this.lineRenderer = this.GetComponentInChildren<LineRenderer>();
		}

		public virtual void StartSelection(Combatant user, BaseAction action)
		{
			this.user = user;
			this.action = action;

			if(this.lineRenderer != null)
			{
				this.position = new Vector3[this.lineRenderer.positionCount];
				this.originalPosition = new Vector3[this.lineRenderer.positionCount];
				this.lineRenderer.GetPositions(this.originalPosition);
			}

			this.UpdateLine();
		}

		protected virtual void LateUpdate()
		{
			this.UpdateLine();
		}

		public virtual void UpdateLine()
		{
			if(this.lineRenderer != null &&
				this.lineRenderer.positionCount > 1 &&
				this.user != null &&
				this.user.GameObject != null &&
				this.action != null)
			{
				if(this.adjustInlinePositions)
				{
					if(this.lineRenderer.useWorldSpace)
					{
						this.position[0] = this.user.GameObject.transform.position + this.userOffset;
						this.position[position.Length - 1] = this.action.rayPoint + this.targetOffset;
					}
					else
					{
						this.position[0] = this.lineRenderer.transform.InverseTransformPoint(this.user.GameObject.transform.position + this.userOffset);
						this.position[position.Length - 1] = this.lineRenderer.transform.InverseTransformPoint(this.action.rayPoint + this.targetOffset);
					}

					Vector3 start = this.position[0];
					Vector3 end = this.position[this.position.Length - 1];
					start.y = 0;
					end.y = 0;

					float distance = Vector3.Distance(start, end);
					Vector3 originalStart = this.originalPosition[0];
					originalStart.y = 0;
					for(int i = 1; i < this.lineRenderer.positionCount - 1; i++)
					{
						Vector3 tmpPos = this.originalPosition[i];
						tmpPos.y = 0;
						tmpPos = Vector3.MoveTowards(start, end, Vector3.Distance(originalStart, tmpPos) * distance);
						tmpPos.y = this.originalPosition[i].y;
						this.position[i] = tmpPos;
					}

					this.lineRenderer.SetPositions(this.position);
				}
				else
				{
					if(this.lineRenderer.useWorldSpace)
					{
						this.lineRenderer.SetPosition(0,
							this.user.GameObject.transform.position + this.userOffset);
						this.lineRenderer.SetPosition(this.lineRenderer.positionCount - 1,
							this.action.rayPoint + this.targetOffset);
					}
					else
					{
						this.lineRenderer.SetPosition(0,
							this.lineRenderer.transform.InverseTransformPoint(
								this.user.GameObject.transform.position + this.userOffset));
						this.lineRenderer.SetPosition(this.lineRenderer.positionCount - 1,
							this.lineRenderer.transform.InverseTransformPoint(
								this.action.rayPoint + this.targetOffset));
					}
				}
			}
		}

		public virtual void StopSelection()
		{
			this.user = null;
			this.action = null;

			if(this.lineRenderer != null)
			{
				if(this.originalPosition != null)
				{
					this.lineRenderer.SetPositions(this.originalPosition);
				}
				this.position = null;
				this.originalPosition = null;
			}
		}
	}
}
