﻿
using UnityEngine;
using GamingIsLove.Makinom;
using System.Collections.Generic;

namespace GamingIsLove.ORKFramework
{
	public class Vector3VariableSorter : IComparer<IVariableSource>
	{
		private string variableKey = "";

		private bool invert = false;

		public Vector3VariableSorter(string variableKey, bool invert)
		{
			this.variableKey = variableKey;
			this.invert = invert;
		}

		public int Compare(IVariableSource x, IVariableSource y)
		{
			if(this.invert)
			{
				if((x == null || !x.HasVariables) &&
					(y == null || !y.HasVariables))
				{
					return 0;
				}
				else if(x != null &&
					(y == null || !y.HasVariables))
				{
					return -1;
				}
				else if((x == null || !x.HasVariables) &&
					y != null)
				{
					return 1;
				}
				else
				{
					Vector3 vX = x.Variables.GetVector3(this.variableKey);
					Vector3 vY = y.Variables.GetVector3(this.variableKey);
					int result = vY.x.CompareTo(vX.x);
					if(result == 0)
					{
						result = vY.y.CompareTo(vX.y);
						if(result == 0)
						{
							result = vY.z.CompareTo(vX.z);
							if(result == 0 &&
								x is IContent &&
								y is IContent)
							{
								return ((IContent)y).GetName().CompareTo(((IContent)x).GetName());
							}
						}
					}
					return result;
				}
			}
			else
			{
				if((x == null || !x.HasVariables) &&
					(y == null || !y.HasVariables))
				{
					return 0;
				}
				else if(x != null &&
					(y == null || !y.HasVariables))
				{
					return -1;
				}
				else if((x == null || !x.HasVariables) &&
					y != null)
				{
					return 1;
				}
				else
				{
					Vector3 vX = x.Variables.GetVector3(this.variableKey);
					Vector3 vY = y.Variables.GetVector3(this.variableKey);
					int result = vX.x.CompareTo(vY.x);
					if(result == 0)
					{
						result = vX.y.CompareTo(vY.y);
						if(result == 0)
						{
							result = vX.z.CompareTo(vY.z);
							if(result == 0 &&
								x is IContent &&
								y is IContent)
							{
								return ((IContent)x).GetName().CompareTo(((IContent)y).GetName());
							}
						}
					}
					return result;
				}
			}
		}
	}
}
