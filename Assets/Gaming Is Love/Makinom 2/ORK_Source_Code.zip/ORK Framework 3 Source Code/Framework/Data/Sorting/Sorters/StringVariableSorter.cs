﻿
using UnityEngine;
using GamingIsLove.Makinom;
using System.Collections.Generic;

namespace GamingIsLove.ORKFramework
{
	public class StringVariableSorter : IComparer<IVariableSource>
	{
		private string variableKey = "";

		private bool invert = false;

		public StringVariableSorter(string variableKey, bool invert)
		{
			this.variableKey = variableKey;
			this.invert = invert;
		}

		public int Compare(IVariableSource x, IVariableSource y)
		{
			if(this.invert)
			{
				if((x == null || !x.HasVariables) &&
					(y == null || !y.HasVariables))
				{
					return 0;
				}
				else if(x != null &&
					(y == null || !y.HasVariables))
				{
					return -1;
				}
				else if((x == null || !x.HasVariables) &&
					y != null)
				{
					return 1;
				}
				else
				{
					int result = y.Variables.GetString(this.variableKey).CompareTo(
						x.Variables.GetString(this.variableKey));
					if(result == 0 &&
						x is IContent &&
						y is IContent)
					{
						return ((IContent)y).GetName().CompareTo(((IContent)x).GetName());
					}
					return result;
				}
			}
			else
			{
				if((x == null || !x.HasVariables) &&
					(y == null || !y.HasVariables))
				{
					return 0;
				}
				else if(x != null &&
					(y == null || !y.HasVariables))
				{
					return -1;
				}
				else if((x == null || !x.HasVariables) &&
					y != null)
				{
					return 1;
				}
				else
				{
					int result = x.Variables.GetString(this.variableKey).CompareTo(
						y.Variables.GetString(this.variableKey));
					if(result == 0 &&
						x is IContent &&
						y is IContent)
					{
						return ((IContent)x).GetName().CompareTo(((IContent)y).GetName());
					}
					return result;
				}
			}
		}
	}
}
