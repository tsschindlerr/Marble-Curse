﻿
using UnityEngine;
using GamingIsLove.Makinom;
using System.Collections.Generic;

namespace GamingIsLove.ORKFramework
{
	[EditorSettingInfo("Defence Modifier Value", "Sort the combatants by a defence modifier's value.", "")]
	public class DefenceModifierValueCombatantSortOption<T> : BaseCombatantSortOption<T> where T : IObjectSelection, new()
	{
		public DefenceModifierAttributeSelection selection = new DefenceModifierAttributeSelection();

		[EditorHelp("Used Value", "Select which value will be used:\n" +
			"- Current Value: The current value of the modifier attribute.\n" +
			"- Base Value: The base value of the modifier attribute (without bonuses).\n" +
			"- Min Value: The minimum value of the modifier attribute.\n" +
			"- Max Value: The maximum value of the modifier attribute.\n" +
			"- Start Value: The start value of the modifier attribute (i.e. the modifier attribute's initial value).\n" +
			"- Preview Value: The preview value, displaying changes when an equipment would be equipped.", "")]
		public ModifierGetValue getValue = ModifierGetValue.CurrentValue;

		[EditorHelp("Invert Order", "Invert the sort order, i.e. sorting from highest to lowest value.")]
		public bool invertOrder = false;

		public DefenceModifierValueCombatantSortOption()
		{

		}

		public override string ToString()
		{
			return "Defence Modifier(" + this.selection.ToString() + ")";
		}

		public override void Sort(List<Combatant> list, IDataCall call)
		{
			list.Sort(new DefenceModifierValueSorter(this.selection, this.getValue, this.invertOrder));
		}
	}
}
