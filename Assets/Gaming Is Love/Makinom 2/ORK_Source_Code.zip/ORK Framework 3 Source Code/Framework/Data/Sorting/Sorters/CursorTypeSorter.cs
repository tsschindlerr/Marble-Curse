﻿
using UnityEngine;
using System.Collections.Generic;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework
{
	public class CursorTypeSorter : IComparer<CursorType>
	{
		public CursorTypeSorter()
		{

		}

		public int Compare(CursorType x, CursorType y)
		{
			return y.CompareTo(x);
		}
	}
}
