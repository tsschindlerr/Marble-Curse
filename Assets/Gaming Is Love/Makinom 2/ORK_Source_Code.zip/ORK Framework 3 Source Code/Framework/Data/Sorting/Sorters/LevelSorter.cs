﻿
using UnityEngine;
using System.Collections.Generic;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework
{
	public class LevelSorter : IComparer<ILevel>, IComparer<IInventoryShortcut>
	{
		private bool invert = false;

		public LevelSorter(bool invert)
		{
			this.invert = invert;
		}

		public int Compare(ILevel x, ILevel y)
		{
			if(this.invert)
			{
				return y.Level.CompareTo(x.Level);
			}
			else
			{
				return x.Level.CompareTo(y.Level);
			}
		}

		public int Compare(IInventoryShortcut x, IInventoryShortcut y)
		{
			ILevel levelX = x is ShopWrapperShortcut ? ((ShopWrapperShortcut)x).Shortcut as ILevel : x as ILevel;
			ILevel levelY = y is ShopWrapperShortcut ? ((ShopWrapperShortcut)y).Shortcut as ILevel : y as ILevel;
			if(this.invert)
			{
				if(levelX == null &&
					levelY == null)
				{
					return y.GetName().CompareTo(x.GetName());
				}
				else if(levelX != null &&
					levelY == null)
				{
					return -1;
				}
				else if(levelX == null &&
					levelY != null)
				{
					return 1;
				}
				else
				{
					int result = levelY.Level.CompareTo(levelX.Level);
					if(result == 0)
					{
						return y.GetName().CompareTo(x.GetName());
					}
					return result;
				}
			}
			else
			{
				if(levelX == null &&
					levelY == null)
				{
					return x.GetName().CompareTo(y.GetName());
				}
				else if(levelX != null &&
					levelY == null)
				{
					return -1;
				}
				else if(levelX == null &&
					levelY != null)
				{
					return 1;
				}
				else
				{
					int result = levelX.Level.CompareTo(levelY.Level);
					if(result == 0)
					{
						return x.GetName().CompareTo(y.GetName());
					}
					return result;
				}
			}
		}
	}
}
