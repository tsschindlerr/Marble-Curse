﻿
using UnityEngine;
using GamingIsLove.Makinom;
using System.Collections.Generic;

namespace GamingIsLove.ORKFramework
{
	public class DefenceModifierValueSorter : IComparer<Combatant>
	{
		private DefenceModifierAttributeSelection selection;

		private ModifierGetValue getValue = ModifierGetValue.CurrentValue;

		private bool inverse = false;

		public DefenceModifierValueSorter(DefenceModifierAttributeSelection selection, ModifierGetValue getValue, bool inverse)
		{
			this.selection = selection;
			this.getValue = getValue;
			this.inverse = inverse;
		}

		public int Compare(Combatant x, Combatant y)
		{
			if(inverse)
			{
				return this.selection.GetValue(y, this.getValue).CompareTo(
					this.selection.GetValue(x, this.getValue));
			}
			else
			{
				return this.selection.GetValue(x, this.getValue).CompareTo(
					this.selection.GetValue(y, this.getValue));
			}
		}
	}
}
