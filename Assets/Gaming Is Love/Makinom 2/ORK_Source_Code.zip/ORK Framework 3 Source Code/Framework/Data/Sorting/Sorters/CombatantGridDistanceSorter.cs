﻿
using UnityEngine;
using System.Collections.Generic;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework
{
	public class CombatantGridDistanceSorter : IComparer<Combatant>
	{
		private Combatant user;

		private bool blockDiagonalDistance1 = false;

		private bool ignoreSizeCells = false;

		private bool inverse = false;

		public CombatantGridDistanceSorter(Combatant user,
			bool blockDiagonalDistance1, bool ignoreSizeCells, bool inverse)
		{
			this.user = user;
			this.blockDiagonalDistance1 = blockDiagonalDistance1;
			this.inverse = inverse;
		}

		public int Compare(Combatant x, Combatant y)
		{
			if(inverse)
			{
				if(x.Grid.Cell == null &&
					y.Grid.Cell == null)
				{
					return 0;
				}
				else if(x.Grid.Cell != null &&
					y.Grid.Cell == null)
				{
					return 1;
				}
				else if(x.Grid.Cell == null &&
					y.Grid.Cell != null)
				{
					return -1;
				}
				else if(this.ignoreSizeCells)
				{
					return user.Grid.Cell.CubeCoord.Distance(y.Grid.Cell.CubeCoord, this.blockDiagonalDistance1).CompareTo(
						user.Grid.Cell.CubeCoord.Distance(x.Grid.Cell.CubeCoord, this.blockDiagonalDistance1));
				}
				else
				{
					return user.Grid.GetLowestDistance(y, this.blockDiagonalDistance1).CompareTo(
						user.Grid.GetLowestDistance(x, this.blockDiagonalDistance1));
				}
			}
			else
			{
				if(x.Grid.Cell == null &&
					y.Grid.Cell == null)
				{
					return 0;
				}
				else if(x.Grid.Cell != null &&
					y.Grid.Cell == null)
				{
					return -1;
				}
				else if(x.Grid.Cell == null &&
					y.Grid.Cell != null)
				{
					return 1;
				}
				else if(this.ignoreSizeCells)
				{
					return user.Grid.Cell.CubeCoord.Distance(x.Grid.Cell.CubeCoord, this.blockDiagonalDistance1).CompareTo(
						user.Grid.Cell.CubeCoord.Distance(y.Grid.Cell.CubeCoord, this.blockDiagonalDistance1));
				}
				else
				{
					return user.Grid.GetLowestDistance(x, this.blockDiagonalDistance1).CompareTo(
						user.Grid.GetLowestDistance(y, this.blockDiagonalDistance1));
				}
			}
		}
	}
}
