
using UnityEngine;
using GamingIsLove.Makinom;
using System.Collections.Generic;

namespace GamingIsLove.ORKFramework
{
	public class StatusEffectsSettings : GenericAssetListSettings<StatusEffectAsset, StatusEffectSetting>
	{
		public StatusEffectsSettings(MakinomProjectAsset project)
		{
			this.LoadProject(project);
			this.CreateGUIDLookup();
		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public override string Filename
		{
			get { return "Status Effects"; }
		}


		/*
		============================================================================
		Auto apply/remove functions
		============================================================================
		*/
		public virtual void CheckAuto(Combatant combatant)
		{
			if(ORK.Access.Combatant.HasStatusAuthority)
			{
				for(int i = 0; i < this.assets.Count; i++)
				{
					this.assets[i].Settings.CheckAuto(combatant);
				}
			}
		}

		public virtual void RegisterStatusChanges(Combatant combatant)
		{
			if(ORK.Access.Combatant.HasStatusAuthority)
			{
				for(int i = 0; i < this.assets.Count; i++)
				{
					if(this.assets[i].Settings.autoApply)
					{
						this.assets[i].Settings.applyConditions.RegisterStatusChanges(combatant, this.assets[i].Settings);
					}
					if(this.assets[i].Settings.autoRemove)
					{
						this.assets[i].Settings.removeConditions.RegisterStatusChanges(combatant, this.assets[i].Settings);
					}
				}
			}
		}

		public virtual void UnregisterStatusChanges(Combatant combatant)
		{
			if(ORK.Access.Combatant.HasStatusAuthority)
			{
				for(int i = 0; i < this.assets.Count; i++)
				{
					if(this.assets[i].Settings.autoApply)
					{
						this.assets[i].Settings.applyConditions.UnregisterStatusChanges(combatant, this.assets[i].Settings);
					}
					if(this.assets[i].Settings.autoRemove)
					{
						this.assets[i].Settings.removeConditions.UnregisterStatusChanges(combatant, this.assets[i].Settings);
					}
				}
			}
		}

		public virtual List<StatusEffectSetting> GetEffectsByType(StatusEffectTypeAsset type)
		{
			List<StatusEffectSetting> list = new List<StatusEffectSetting>();
			this.GetEffectsByType(type, ref list);
			return list;
		}

		public virtual void GetEffectsByType(StatusEffectTypeAsset type, ref List<StatusEffectSetting> list)
		{
			for(int i = 0; i < this.assets.Count; i++)
			{
				if(this.assets[i].Settings.type.Is(type) &&
					!list.Contains(this.assets[i].Settings))
				{
					list.Add(this.assets[i].Settings);
				}
			}
		}
	}
}
