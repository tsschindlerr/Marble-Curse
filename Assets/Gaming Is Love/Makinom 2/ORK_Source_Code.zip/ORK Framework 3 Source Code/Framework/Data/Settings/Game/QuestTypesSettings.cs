
using UnityEngine;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework
{
	public class QuestTypesSettings : GenericAssetListSettings<QuestTypeAsset, QuestType>
	{
		public QuestTypesSettings(MakinomProjectAsset project)
		{
			this.LoadProject(project);
			this.CreateGUIDLookup();
		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public override string Filename
		{
			get { return "Quest Types"; }
		}
	}
}

