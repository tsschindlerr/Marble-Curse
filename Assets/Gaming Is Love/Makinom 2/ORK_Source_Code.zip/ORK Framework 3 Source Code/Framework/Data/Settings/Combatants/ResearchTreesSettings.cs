﻿
using UnityEngine;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework
{
	public class ResearchTreesSettings : GenericAssetListSettings<ResearchTreeAsset, ResearchTreeSetting>
	{
		public ResearchTreesSettings(MakinomProjectAsset project)
		{
			this.LoadProject(project);
			this.CreateGUIDLookup();
		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public override string Filename
		{
			get { return "Research Trees"; }
		}
	}
}
