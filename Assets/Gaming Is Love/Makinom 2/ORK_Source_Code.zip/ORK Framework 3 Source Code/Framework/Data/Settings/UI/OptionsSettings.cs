﻿
using UnityEngine;
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.IO;
using GamingIsLove.ORKFramework.UI;
using System.Collections.Generic;

namespace GamingIsLove.ORKFramework
{
	public class OptionsSettings : GenericAssetListSettings<OptionCategoryAsset, OptionCategorySetting>, ISaveData
	{
		// file settings
		[EditorHelp("File Name", "Define the name of the file or key of the variable.\n" +
			"This includes the file's extension, e.g. 'file.data'.", "")]
		[EditorFoldout("Options Data File", "Define where options data that isn't part of the save game will be stored.")]
		[EditorWidth(true)]
		public string fileName = "options.settings";

		public TextFileSettings fileSettings = new TextFileSettings();

		[EditorHelp("Encrypt Data", "The XML-formatted text will be encrypted (using the same encryption as save games).", "")]
		[EditorSeparator]
		[EditorEndFoldout]
		public bool encryptData = false;


		// input rebinding
		[EditorFoldout("Input Rebinding", "Define the settings for input rebinding.\n" +
			"Input rebinding allows the player to change the input used for input keys.\n" +
			"This requires to recognize which input was used by the player, the available sources are set up in the input search setup.")]
		[EditorEndFoldout]
		public InputRebinding inputRebinding = new InputRebinding();


		// default options menu
		[EditorFoldout("Options Menu", "Define the default options menu.")]
		[EditorEndFoldout]
		public OptionsMenu optionsMenu = new OptionsMenu();

		public OptionsSettings(MakinomProjectAsset project)
		{
			this.LoadProject(project);
			this.CreateGUIDLookup();
		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public override string Filename
		{
			get { return "Options"; }
		}

		public override bool HasGeneralSettings
		{
			get { return true; }
		}


		/*
		============================================================================
		Options functions
		============================================================================
		*/
		public virtual void SetInitialValues(OptionsMenu menu)
		{
			for(int i = 0; i < this.assets.Count; i++)
			{
				if(this.assets[i] != null)
				{
					this.assets[i].Settings.SetInitialValues(menu);
				}
			}
		}

		public virtual void AcceptChanges(OptionsMenu menu)
		{
			for(int i = 0; i < this.assets.Count; i++)
			{
				if(this.assets[i] != null)
				{
					this.assets[i].Settings.AcceptChanges(menu);
				}
			}

			this.SaveFile();
		}

		public virtual void ResetChanges(OptionsMenu menu)
		{
			for(int i = 0; i < this.assets.Count; i++)
			{
				if(this.assets[i] != null)
				{
					this.assets[i].Settings.ResetValues(menu);
				}
			}
		}

		public virtual void InputRebind(int inputID, InputKey inputKey, BaseInputIDKeySetting binding, BaseInputIDKeySetting initialBinding)
		{
			if(InputRebindSameType.Switch == this.inputRebinding.rebindSameType)
			{
				for(int i = 0; i < this.assets.Count; i++)
				{
					if(this.assets[i] != null)
					{
						for(int j = 0; j < this.assets[i].Settings.inputOption.Length; j++)
						{
							InputRebindOptionType rebindOption = this.assets[i].Settings.inputOption[j].settings as InputRebindOptionType;
							if(rebindOption != null)
							{
								rebindOption.CheckRebindOther(inputID, inputKey, binding, BaseInputIDKeySetting.Load(initialBinding.SaveGame()));
							}
						}
					}
				}
			}
			else if(InputRebindSameType.NoneInput == this.inputRebinding.rebindSameType)
			{
				for(int i = 0; i < this.assets.Count; i++)
				{
					if(this.assets[i] != null)
					{
						for(int j = 0; j < this.assets[i].Settings.inputOption.Length; j++)
						{
							InputRebindOptionType rebindOption = this.assets[i].Settings.inputOption[j].settings as InputRebindOptionType;
							if(rebindOption != null)
							{
								rebindOption.CheckRebindOther(inputID, inputKey, binding, new NoneInputIDKeySetting());
							}
						}
					}
				}
			}
		}

		public virtual void InitCurrentBindings(OptionsMenu menu)
		{
			for(int i = 0; i < this.assets.Count; i++)
			{
				if(this.assets[i] != null)
				{
					for(int j = 0; j < this.assets[i].Settings.inputOption.Length; j++)
					{
						InputRebindOptionType rebindOption = this.assets[i].Settings.inputOption[j].settings as InputRebindOptionType;
						if(rebindOption != null)
						{
							rebindOption.InitCurrentBinding(menu);
						}
					}
				}
			}
		}


		/*
		============================================================================
		Save file functions
		============================================================================
		*/
		public virtual void SaveFile()
		{
			DataObject data = new DataObject();
			bool any = false;
			for(int i = 0; i < this.assets.Count; i++)
			{
				if(this.assets[i] != null &&
					this.assets[i].Settings.saveInFile)
				{
					any = true;
					this.assets[i].Settings.SaveOptions(data);
				}
			}

			if(any)
			{
				string xmlData = data.ToXML("options");
				this.fileSettings.fileSettings.SaveFile(this.fileName,
					this.encryptData ? Maki.SecurityHandler.SaveGame(xmlData) : xmlData);
			}
		}

		public virtual void LoadFile()
		{
			string xmlData = this.fileSettings.fileSettings.LoadFile(this.fileName);
			if(!string.IsNullOrEmpty(xmlData))
			{
				DataObject data = new XMLParser(this.encryptData ? Maki.SecurityHandler.LoadGame(xmlData) : xmlData, null).Parse();

				for(int i = 0; i < this.assets.Count; i++)
				{
					if(this.assets[i] != null &&
						this.assets[i].Settings.saveInFile)
					{
						this.assets[i].Settings.LoadOptions(data);
					}
				}
			}
		}


		/*
		============================================================================
		Save game functions
		============================================================================
		*/
		public DataObject SaveGame()
		{
			DataObject data = new DataObject();
			for(int i = 0; i < this.assets.Count; i++)
			{
				if(this.assets[i] != null &&
					!this.assets[i].Settings.saveInFile)
				{
					this.assets[i].Settings.SaveOptions(data);
				}
			}
			return data;
		}

		public void LoadGame(DataObject data)
		{
			if(data != null)
			{
				for(int i = 0; i < this.assets.Count; i++)
				{
					if(this.assets[i] != null &&
						!this.assets[i].Settings.saveInFile)
					{
						this.assets[i].Settings.LoadOptions(data);
					}
				}
			}
		}
	}
}
