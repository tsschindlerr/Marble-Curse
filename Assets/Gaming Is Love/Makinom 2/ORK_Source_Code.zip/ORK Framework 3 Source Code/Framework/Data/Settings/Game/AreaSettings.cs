﻿
using UnityEngine;
using GamingIsLove.Makinom;
using System.Collections.Generic;

namespace GamingIsLove.ORKFramework
{
	public class AreaSettings : BaseSettings
	{
		// initial area
		[EditorHelp("Set Start Area", "Starting a new game will set the game's current area.")]
		[EditorFoldout("Area Settings", "Define if area notifications will be displayed.", "")]
		public bool setStartArea = false;

		[EditorHelp("Initial Area", "Select the area that will be used as start area.")]
		[EditorCondition("setStartArea", true)]
		public AssetSelection<AreaAsset> startArea = new AssetSelection<AreaAsset>();

		[EditorHelp("Show Notification", "Show the area notification when setting the start area.")]
		[EditorEndFoldout]
		[EditorEndCondition]
		public bool startShowNotification = false;


		// notifications
		[EditorFoldout("Area Notifications", "Show notifications when entering an area.", "")]
		[EditorEndFoldout]
		public AreaNotificationSettings notifications = new AreaNotificationSettings();

		public AreaSettings(MakinomProjectAsset project)
		{
			this.LoadProject(project);
		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public override string Filename
		{
			get { return "Area Settings"; }
		}
	}
}
