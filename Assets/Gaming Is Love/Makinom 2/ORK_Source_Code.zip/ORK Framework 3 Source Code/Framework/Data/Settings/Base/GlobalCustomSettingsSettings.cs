﻿
using UnityEngine;
using System.Collections.Generic;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework
{
	public class GlobalCustomSettingsSettings : GenericAssetListSettings<GlobalCustomSettingsAsset, GlobalCustomSettings>
	{
		public GlobalCustomSettingsSettings(MakinomProjectAsset project)
		{
			this.LoadProject(project);
			this.CreateGUIDLookup();
		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public override string Filename
		{
			get { return "Global Custom Settings"; }
		}
	}
}
