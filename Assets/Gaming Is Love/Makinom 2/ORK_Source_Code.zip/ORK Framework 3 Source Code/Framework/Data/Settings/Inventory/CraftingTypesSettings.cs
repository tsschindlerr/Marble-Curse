
using UnityEngine;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework
{
	public class CraftingTypesSettings : GenericAssetListSettings<CraftingTypeAsset, CraftingType>
	{
		public CraftingTypesSettings(MakinomProjectAsset project)
		{
			this.LoadProject(project);
			this.CreateGUIDLookup();
		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public override string Filename
		{
			get { return "Crafting Types"; }
		}
	}
}
