
using UnityEngine;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework
{
	public class AbilityTypesSettings : GenericAssetListSettings<AbilityTypeAsset, AbilityType>
	{
		public AbilityTypesSettings(MakinomProjectAsset project)
		{
			this.LoadProject(project);
			this.CreateGUIDLookup();
		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public override string Filename
		{
			get { return "Ability Types"; }
		}
	}
}

