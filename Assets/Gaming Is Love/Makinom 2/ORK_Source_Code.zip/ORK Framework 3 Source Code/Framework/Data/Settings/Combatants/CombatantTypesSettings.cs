﻿
using UnityEngine;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework
{
	public class CombatantTypesSettings : GenericAssetListSettings<CombatantTypeAsset, CombatantType>
	{
		public CombatantTypesSettings(MakinomProjectAsset project)
		{
			this.LoadProject(project);
			this.CreateGUIDLookup();
		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public override string Filename
		{
			get { return "Combatant Types"; }
		}
	}
}
