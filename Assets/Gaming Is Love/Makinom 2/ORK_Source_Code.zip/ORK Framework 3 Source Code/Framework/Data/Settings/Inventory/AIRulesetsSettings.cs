﻿
using UnityEngine;
using GamingIsLove.ORKFramework.AI;
using System.Collections.Generic;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework
{
	public class AIRulesetsSettings : GenericAssetListSettings<AIRulesetAsset, AIRuleset>
	{
		// empty content
		[EditorFoldout("Empty Content", "The content information used for empty AI ruleset slots.\n" +
			"This will be used instead of an equipped AI ruleset's content.")]
		[EditorEndFoldout]
		public LanguageContentInformation emptyContent = new LanguageContentInformation("Empty");


		// slot content
		[EditorHelp("Slot Index Display", "Offset added to the index of the slot when displayed in the slot content ('<slotindex>').\n" +
			"The first slot has the index 0, e.g. if you want to start your slot index numbers at 1, set this setting to 1.", "")]
		[EditorFoldout("Default Slot Content", "The default content information used for AI ruleset slots.")]
		public int slotIndexDisplay = 0;

		[EditorEndFoldout]
		[EditorLabel("<slotindex> = slot index")]
		public LanguageContentInformation defaultSlotContent = new LanguageContentInformation("Slot <slotindex>");

		[EditorArray("Add Slot Content", "Adds slot content information used by AI ruleset slots of the matching index.", "",
			"Remove", "Removes this slot content.", "",
			isCopy=true, isMove=true,
			foldout=true, foldoutText=new string[] {
				"Slot Content", "Define the content information for this slot index.", ""
			})]
		[EditorLabel("<slotindex> = slot index")]
		public LanguageContentInformation[] slotContent = new LanguageContentInformation[0];

		public AIRulesetsSettings(MakinomProjectAsset project)
		{
			this.LoadProject(project);
			this.CreateGUIDLookup();
		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public override string Filename
		{
			get { return "AI Rulesets"; }
		}

		public override bool HasGeneralSettings
		{
			get { return true; }
		}


		/*
		============================================================================
		Slot content functions
		============================================================================
		*/
		public virtual LanguageContentInformation GetSlotContent(int index)
		{
			if(index >= 0 &&
				index < this.slotContent.Length)
			{
				return this.slotContent[index];
			}
			return this.defaultSlotContent;
		}

		public virtual string GetFormattedSlotIndex(int index)
		{
			return ORK.TextDisplaySettings.numberFormatting.FormatInt(index + this.slotIndexDisplay);
		}
	}
}
