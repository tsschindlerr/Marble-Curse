
using UnityEngine;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework
{
	public class AttackModifiersSettings : GenericAssetListSettings<AttackModifierAsset, AttackModifierSetting>
	{
		public AttackModifiersSettings(MakinomProjectAsset project)
		{
			this.LoadProject(project);
			this.CreateGUIDLookup();
		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public override string Filename
		{
			get { return "Attack Modifiers"; }
		}
	}
}

