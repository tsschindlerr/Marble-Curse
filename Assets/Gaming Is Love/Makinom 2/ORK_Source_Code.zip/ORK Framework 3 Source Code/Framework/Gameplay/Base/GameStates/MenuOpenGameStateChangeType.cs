﻿
using UnityEngine;
using GamingIsLove.Makinom;
using System.Collections.Generic;

namespace GamingIsLove.ORKFramework
{
	[EditorSettingInfo("Menu Open", "When a menu is opened.")]
	public class MenuOpenGameStateChangeType : BaseGameStateChangeType
	{
		public MenuOpenGameStateChangeType()
		{

		}

		public override void Register(Notify notify)
		{
			ORK.Menu.MenuOpened += notify;
		}
	}
}
