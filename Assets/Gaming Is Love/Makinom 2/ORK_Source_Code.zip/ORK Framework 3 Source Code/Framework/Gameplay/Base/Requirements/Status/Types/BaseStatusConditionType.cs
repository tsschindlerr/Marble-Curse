﻿
using UnityEngine;
using System.Collections.Generic;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework.Conditions
{
	public abstract class BaseStatusConditionType : BaseTypeData
	{
		/*
		============================================================================
		Check functions
		============================================================================
		*/
		public abstract bool Check(Combatant combatant);

		public virtual bool CheckPreview(Combatant combatant)
		{
			return Check(combatant);
		}

		public virtual bool CheckBestiary(Combatant combatant)
		{
			return Check(combatant);
		}


		/*
		============================================================================
		Status change register functions
		============================================================================
		*/
		public abstract void Register(Combatant combatant, IStatusChanged notify);

		public abstract void Unregister(Combatant combatant, IStatusChanged notify);

		public abstract void Register(Combatant combatant, Notify notify);

		public abstract void Unregister(Combatant combatant, Notify notify);
	}
}
