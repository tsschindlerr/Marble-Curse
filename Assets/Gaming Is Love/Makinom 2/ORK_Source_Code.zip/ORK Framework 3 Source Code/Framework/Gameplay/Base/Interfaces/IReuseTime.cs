﻿
using UnityEngine;
using System.Collections.Generic;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework
{
	public interface IReuseTime
	{
		ReuseTime GetReuseTimeSetting(Combatant user);

		bool IsReuseBlocked(Combatant user);

		string GetReuseTimeText(Combatant user, int decimals);

		string GetReuseTimeFormatted(float seconds);

		float GetReuseTime(Combatant user);

		float GetMaxReuseTime(Combatant user);
	}
}
