﻿
using UnityEngine;
using System.Collections.Generic;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework
{
	public class CursorInput : BaseData
	{
		[EditorFoldout("Vertical Axis", "The input key used to move the cursor vertically.", "")]
		[EditorEndFoldout]
		public AxisControl verticalInputAxis = new AxisControl();

		[EditorFoldout("Horizontal Axis", "The input key used to move the cursor horizontally.", "")]
		[EditorEndFoldout]
		public AxisControl horizontalInputAxis = new AxisControl();

		[EditorHelp("Axis Minimum", "Define the minimum value an axis must have to trigger a cursor change.", "")]
		[EditorLimit(0.0f, 1.0f)]
		[EditorSeparator]
		public float axisMinimum = 0.3f;

		[EditorHelp("Use Camera Direction", "The axis keys will change the cursor based on the camera view (main camera).", "")]
		public bool useCameraDirection = false;

		[EditorHelp("Camera Direction Offset", "Define the angle in degrees that will be added to the camera direction.\n" +
			"E.g. use 45 to shift the cursor change 45 degrees to the camera view.", "")]
		[EditorCondition("useCameraDirection", true)]
		[EditorEndCondition]
		public float cameraDirectionOffset = 0;

		public CursorInput()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);
			this.verticalInputAxis.UpgradeOldAxis(data, "verticalAxis");
			this.horizontalInputAxis.UpgradeOldAxis(data, "horizontalAxis");
		}

		public Vector3 GetInput(Combatant user, HorizontalPlaneType horizontalPlane)
		{
			float h = this.horizontalInputAxis.GetAxis(user.InputID, false);
			float v = this.verticalInputAxis.GetAxis(user.InputID, false);

			if(h <= -this.axisMinimum || h >= this.axisMinimum ||
				v <= -this.axisMinimum || v >= this.axisMinimum)
			{
				if(this.useCameraDirection &&
					Maki.Game.Camera != null)
				{
					return InputHelper.GetDirectionJoystick(h, v, Maki.Game.Camera.transform,
						horizontalPlane, this.cameraDirectionOffset);
				}
				else
				{
					if(HorizontalPlaneType.XZ == horizontalPlane)
					{
						return new Vector3(h, 0, v);
					}
					else if(HorizontalPlaneType.XY == horizontalPlane)
					{
						return new Vector3(h, v, 0);
					}
				}
			}

			return Vector3.zero;
		}
	}
}
