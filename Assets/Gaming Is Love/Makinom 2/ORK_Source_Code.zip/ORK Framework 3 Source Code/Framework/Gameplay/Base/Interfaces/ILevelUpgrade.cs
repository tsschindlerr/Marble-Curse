﻿
using UnityEngine;
using GamingIsLove.Makinom;
using System.Collections.Generic;

namespace GamingIsLove.ORKFramework
{
	public interface ILevelUpgrade
	{
		bool HasLevelUpgrade();

		bool CanUpgradeLevel(Combatant combatant);

		bool UpgradeLevel(Combatant combatant, bool checkCosts, bool consumeCosts);

		void GetHUDCost(Combatant combatant, List<HUDBaseCostWrapper> list);
	}
}
