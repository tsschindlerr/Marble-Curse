﻿
using UnityEngine;
using System.Collections.Generic;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework
{
	public class AutoAnimationSetting : BaseData
	{
		[EditorHelp("Use Auto Animation", "ORK will automatically handle movement animations " +
			"(idle, walk, run, sprint, fall, land) based on the combatant's movement.\n" +
			"If disabled, you'll have to manage the movement animations with your own scripts.\n" +
			"The auto animation can also be enabled/disabled using schematics.", "")]
		public bool enabled = false;

		[EditorHelp("Initial State", "If enabled, the auto animation starts enabled.\n" +
			"If disabled, the auto animation is disabled when creating the combatant.", "")]
		[EditorCondition("enabled", true)]
		public bool initialState = true;

		[EditorHelp("Minimum Fall Time (s)", "The minimum fall time in seconds to play the land animation.", "")]
		[EditorLimit(0, false)]
		public float minFallTime = 0.3f;


		// run speed
		[EditorHelp("Minimum Run Speed", "The minimum speed to play the run animation.", "")]
		[EditorSeparator]
		[EditorLimit(0, false)]
		public float minRunSpeed = 3;

		[EditorHelp("Run Speed Threshold", "The threshold is used for a smoother change between walk/run animations.\n" +
			"The run animation will be played when the combatant's speed is above 'Minimum Run Speed + threshold', " +
			"the walk animation will be played again when the speed is below 'Minimum Run Speed - threshold'.", "")]
		[EditorLimit(0, false)]
		public float runSpeedThreshold = 0;


		// sprint speed
		[EditorHelp("Minimum Sprint Speed", "The minimum speed to play the sprint animation.", "")]
		[EditorSeparator]
		[EditorLimit(0, false)]
		public float minSprintSpeed = 6;

		[EditorHelp("Sprint Speed Threshold", "The threshold is used for a smoother change between run/sprint animations.\n" +
			"The sprint animation will be played when the combatant's speed is above 'Minimum Sprint Speed + threshold', " +
			"the run animation will be played again when the speed is below 'Minimum Sprint Speed - threshold'.", "")]
		[EditorLimit(0.0f, false)]
		public float sprintSpeedThreshold = 0;


		// speed change delay
		[EditorHelp("Use Speed Change Delay", "Delay animation changes when the speed change exceeds a defined value.\n" +
			"E.g. use this when a short stop (e.g. between two movement nodes) causes an unwanted animation change.", "")]
		[EditorSeparator]
		public bool useSpeedChangeDelay = false;

		[EditorHelp("Minimum Speed Change", "The minimum speed change that must happen to trigger the animation delay.", "")]
		[EditorLimit(0, false)]
		[EditorCondition("useSpeedChangeDelay", true)]
		public float minSpeedChange = 1;

		[EditorHelp("Delay (s)", "The time in seconds the animation change will be delayed.", "")]
		[EditorLimit(0, false)]
		[EditorEndCondition]
		public float speedChangeDelay = 0.1f;


		// forward animations
		[EditorHelp("Use Forward Animation", "Use different walk, run or sprint animation types when moving forward.\n" +
			"In 'XY' horizontal plane mode, the forward/backward movement uses the Y-axis.", "")]
		[EditorSeparator]
		[EditorTitleLabel("Forward Move Animation")]
		public bool useForwardAnimations = false;

		[EditorIndent]
		[EditorCondition("useForwardAnimations", true)]
		[EditorEndCondition]
		public MoveAnimations forwardAnimations = new MoveAnimations();


		// backward animations
		[EditorHelp("Use Backward Animation", "Use different walk, run or sprint animation types when moving backward.\n" +
			"In 'XY' horizontal plane mode, the forward/backward movement uses the Y-axis.", "")]
		[EditorSeparator]
		[EditorTitleLabel("Backward Move Animation")]
		public bool useBackwardAnimations = false;

		[EditorIndent]
		[EditorCondition("useBackwardAnimations", true)]
		[EditorEndCondition]
		public MoveAnimations backwardAnimations = new MoveAnimations();


		// left animations
		[EditorHelp("Use Left Animation", "Use different walk, run or sprint animation types when moving left.", "")]
		[EditorSeparator]
		[EditorTitleLabel("Left Move Animation")]
		public bool useLeftAnimations = false;

		[EditorIndent]
		[EditorCondition("useLeftAnimations", true)]
		public MoveAnimations leftAnimations = new MoveAnimations();

		[EditorHelp("Left Min Value", "The minimum value the movement direction must have to use left movement animations.\n" +
			"The direction value must be equal or below the defined value.\n" +
			"The movement direction is checked using a normalized Vector3 value, left-side movement is usually a negative value.\n" +
			"E.g. -1 would be full left, -0.5 would be forward/backward-left.", "")]
		[EditorEndCondition]
		[EditorLimit(0, true)]
		public float leftMinValue = -0.5f;


		// right animations
		[EditorHelp("Use Right Animation", "Use different walk, run or sprint animation types when moving right.", "")]
		[EditorSeparator]
		[EditorTitleLabel("Right Move Animation")]
		public bool useRightAnimations = false;

		[EditorIndent]
		[EditorCondition("useRightAnimations", true)]
		public MoveAnimations rightAnimations = new MoveAnimations();

		[EditorHelp("Right Min Value", "The minimum value the movement direction must have to use right movement animations.\n" +
			"The direction value must be equal or above the defined value.\n" +
			"The movement direction is checked using a normalized Vector3 value, right-side movement is usually a positive value.\n" +
			"E.g. 1 would be full left, 0.5 would be forward/backward-left.", "")]
		[EditorEndCondition(2)]
		[EditorLimit(0, false)]
		public float rightMinValue = 0.5f;


		public AutoAnimationSetting()
		{

		}

		public bool IsDirectional
		{
			get
			{
				return this.useForwardAnimations ||
					this.useBackwardAnimations ||
					this.useLeftAnimations ||
					this.useRightAnimations;
			}
		}
	}
}
