﻿
using UnityEngine;
using GamingIsLove.Makinom;
using System.Collections.Generic;

namespace GamingIsLove.ORKFramework
{
	[EditorSettingInfo("Quest Variable", "Check quest variable conditions.")]
	public class QuestVariableGeneralCondition<T> : BaseGeneralCondition<T> where T : IObjectSelection, new()
	{
		[EditorHelp("Quest", "Select the quest that will be checked.\n" +
			"The quest has to be added to the player's quest list.", "")]
		public AssetSelection<QuestAsset> quest = new AssetSelection<QuestAsset>();

		[EditorLabel("Use 'Local' variable origin to check variables of the quest instance.")]
		public VariableCondition<T> variableCondition = new VariableCondition<T>();

		public QuestVariableGeneralCondition()
		{

		}

		public override string ToString()
		{
			return "Quest Variable";
		}

		public override bool Check(IDataCall call)
		{
			if(this.quest.StoredAsset != null)
			{
				Quest questInstance = ORK.Game.Quests.GetQuest(this.quest.StoredAsset.Settings);
				if(questInstance != null)
				{
					return this.variableCondition.CheckVariables(new DataCall(ORK.Game.ActiveGroup.Leader,
						questInstance.HasVariables ? questInstance.Variables : null,
						questInstance.GetSelectedData()));
				}
			}
			return false;
		}

		public override void Register(IDataCall call, Notify notify, ref List<VariableHandler> unregisterHandlers)
		{
			if(this.quest.StoredAsset != null &&
				this.variableCondition.Has)
			{
				ORK.Game.Quests.Changed += notify;
			}
		}

		public override void Unregister(IDataCall call, Notify notify)
		{
			if(this.quest.StoredAsset != null &&
				this.variableCondition.Has)
			{
				ORK.Game.Quests.Changed -= notify;
			}
		}
	}
}
