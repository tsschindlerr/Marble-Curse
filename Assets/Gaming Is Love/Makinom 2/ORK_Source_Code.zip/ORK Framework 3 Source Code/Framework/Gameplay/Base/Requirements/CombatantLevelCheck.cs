﻿
using UnityEngine;
using GamingIsLove.Makinom;
using System.Collections.Generic;

namespace GamingIsLove.ORKFramework
{
	public enum CombatantLevelCheckType { None, Base, Class }

	public class CombatantLevelCheck : BaseData
	{
		[EditorHelp("Level Check", "Select if the combatant's level is checked:\n" +
			"- None: No level check.\n" +
			"- Base: Checks the combatant's base level.\n" +
			"- Class: Checks the combatant's class level.")]
		public CombatantLevelCheckType type = CombatantLevelCheckType.None;

		[EditorCondition("type", CombatantLevelCheckType.None)]
		[EditorElseCondition]
		[EditorEndCondition]
		[EditorAutoInit]
		public ValueCheck<GameObjectSelection> valueCheck;

		public CombatantLevelCheck()
		{

		}

		public virtual bool Check(Combatant combatant)
		{
			if(CombatantLevelCheckType.Base == this.type)
			{
				return this.valueCheck.Check(combatant.Status.Level, combatant.Call);
			}
			else if(CombatantLevelCheckType.Class == this.type)
			{
				return this.valueCheck.Check(combatant.Class.Level, combatant.Call);
			}
			else
			{
				return true;
			}
		}
	}
}
