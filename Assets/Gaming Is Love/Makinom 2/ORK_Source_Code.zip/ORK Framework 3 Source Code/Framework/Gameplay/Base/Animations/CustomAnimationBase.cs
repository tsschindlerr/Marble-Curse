﻿
using UnityEngine;
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.Reflection;
using System.Collections.Generic;

namespace GamingIsLove.ORKFramework.Animations
{
	public class CustomAnimationBase : BaseData
	{
		// play
		[EditorHelp("Returns Duration (float)", "The play function returns a float value representing the animation's duration.\n" +
			"If disabled, a separate duration function can be used.")]
		[EditorFoldout("Play Function", "Define the function that will be called when the animation is played.", "")]
		public bool playReturnsDuration = false;

		[EditorEndFoldout]
		public CallFunction<GameObjectSelection> playMethod = new CallFunction<GameObjectSelection>();


		// stop
		[EditorFoldout("Stop Function", "Define the function that will be called when the animation is stopped.", "")]
		[EditorEndFoldout]
		public CallFunction<GameObjectSelection> stopMethod = new CallFunction<GameObjectSelection>();


		// duration
		[EditorFoldout("Duration Function", "Define the function that will be called to get the animation's duration when the animation is played.\n" +
			"Requires a function that returns a float value.", "")]
		[EditorEndFoldout]
		[EditorCondition("playReturnsDuration", false)]
		[EditorEndCondition]
		public CallFunction<GameObjectSelection> durationMethod = new CallFunction<GameObjectSelection>();

		public CustomAnimationBase()
		{

		}


		/*
		============================================================================
		Animation functions
		============================================================================
		*/
		public virtual float Play(Combatant combatant, Component behaviour)
		{
			if(this.playReturnsDuration)
			{
				object tmpValue = this.playMethod.GetReturnValue(behaviour, combatant.Call, false);
				if(tmpValue is float)
				{
					return (float)tmpValue;
				}
			}
			else
			{
				this.playMethod.Call(behaviour, combatant.Call, false);
				// duration
				object tmpValue = this.durationMethod.GetReturnValue(behaviour, combatant.Call, false);
				if(tmpValue is float)
				{
					return (float)tmpValue;
				}
			}
			return 0;
		}

		public virtual void Stop(Combatant combatant, Component behaviour)
		{
			this.stopMethod.Call(behaviour, combatant.Call, false);
		}
	}
}
