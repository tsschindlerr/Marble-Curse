﻿
using UnityEngine;
using GamingIsLove.Makinom;
using System.Collections.Generic;

namespace GamingIsLove.ORKFramework
{
	[EditorSettingInfo("Item Collection End", "When an item collection ends (via 'Item Collector' component).")]
	public class ItemCollectionEndGameStateChangeType : BaseGameStateChangeType
	{
		public ItemCollectionEndGameStateChangeType()
		{

		}

		public override void Register(Notify notify)
		{
			ORK.Control.ItemCollectionEnd += notify;
		}
	}
}
