﻿
using UnityEngine;
using GamingIsLove.ORKFramework.Components;
using System.Collections.Generic;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework
{
	public class TopDownBorderCameraSettings : BaseData
	{
		[EditorHelp("Child Object", "Use a child object of the player to position the camera.", "")]
		public ChildObjectSettings childObject = new ChildObjectSettings();

		[EditorHelp("Use Unscaled Time", "Use unscaled delta time.\n" +
			"I.e. the camera control is not affected when changing the timescale.", "")]
		public bool useUnscaledTime = false;

		[EditorHelp("Initial Damping", "Damping (position/height) will be used when first " +
			"adjusting the camera position to the player.\n" +
			"If disabled, the camera position will be set directly the first update.", "")]
		[EditorSeparator]
		public bool initialDamping = true;

		[EditorHelp("Border Camera Edge", "Stop when the camera's edge reaches the camera border instead of the camera position.")]
		public bool borderCameraEdge = false;

		[EditorHelp("Position Damping", "Used for smoother position changes.\n" +
			"Higher values mean quicker changes, set to 0 to disable.", "")]
		[EditorLimit(0.0f, false)]
		public float positionDamping = 0;

		[EditorHelp("Position Padding", "Padding added to the border.\n" +
			"Left + X, top - Y, right - Z, bottom + W.\n" +
			"If the player moves outside the border left or right, the camera will stop following on the X-axis.\n" +
			"If the player moves outside the border to or bottom, the camera will stop following on the Z-axis.", "")]
		public Vector4 positionPadding = new Vector4(0, 0, 0, 0);

		[EditorHelp("Distance", "The distance of the camera to the player.", "")]
		public float distance = 15.0f;

		[EditorHelp("Height", "The height above the player.", "")]
		public float height = 15.0f;

		[EditorHelp("Height Damping", "Used for smoother height changes.\n" +
			"Higher values mean quicker changes, set to 0 to disable.", "")]
		[EditorLimit(0.0f, false)]
		public float heightDamping = 2.0f;

		[EditorHelp("Distance Damping", "Used for smoother distance changes.\n" +
			"Higher values mean quicker changes, set to 0 to disable.", "")]
		[EditorLimit(0.0f, false)]
		public float distanceDamping = 2.0f;

		[EditorHelp("Rotation Damping", "Used for smoother rotation changes.\n" +
			"Higher values mean quicker changes, set to 0 to disable.", "")]
		[EditorLimit(0.0f, false)]
		public float rotationDamping = 2.0f;

		[EditorHelp("Rotation", "The rotation of the camera.\n" +
			"This defines the looking direction of the camera, e.g.:" +
			"- 0 looks north\n" +
			"- 90 looks east\n" +
			"- 180 looks south\n" +
			"- 270 (or -90) will look west", "")]
		public float rotation = 0;

		public HorizontalPlaneOverride horizontalPlane = new HorizontalPlaneOverride();


		// rotation input
		[EditorHelp("Use Rotation In", "Select when camera rotation can be used:\n" +
			"- Field: Useable in the field (i.e. not in battles).\n" +
			"- Battle: Useable in battles (i.e. not in the field).\n" +
			"- Both: Useable in battles and in the field.\n" +
			"- None: Not used.", "")]
		[EditorFoldout("Rotation Settings", "The camera can optionally be rotated.", "")]
		public UseableIn useRotationIn = UseableIn.None;

		[EditorHelp("Remember Rotation", "The rotation will be remembered when changing between scenes.\n" +
			"The camera's rotation will be transfered over to the new scene.", "")]
		[EditorCondition("useRotationIn", UseableIn.None)]
		[EditorElseCondition]
		public bool rememberRotation = false;

		[EditorHelp("In Battle", "Remember the rotation in battle.\n" +
			"If disabled, the rotation will not be remembered/restored when loading into or out of a battle scene.", "")]
		[EditorIndent]
		[EditorCondition("rememberRotation", true)]
		[EditorEndCondition]
		public bool rememberRotationBattle = true;

		[EditorHelp("Reset On Target Change", "The rotation is reset when changing the camera control target.", "")]
		public bool cameraTargetChangeResetRotation = false;

		[EditorHelp("Block On Target Change", "Rotating is blocked while changing the camera control target.", "")]
		public bool cameraTargetChangeBlockRotation = false;

		[EditorHelp("Rotation Input Change", "Define the rotation change (in degree) each time the rotate left/right keys are used.\n" +
			"The rotate right key will negate the defined value (e.g. -90 instead of 90).", "")]
		public float rotationInputChange = 90;

		[EditorHelp("Use Delta Time", "The rotation input change is multiplied by the delta time.\n" +
			"Enable this setting when using continuous input, e.g. from keys that are held down.", "")]
		public bool rotateDeltaTime = false;

		public AxisControl rotationAxis = new AxisControl();

		[EditorHelp("Reset Rotation Key", "The input key used to reset the rotation to the initial value.", "")]
		public AssetSelection<InputKeyAsset> rotationResetInputKey = new AssetSelection<InputKeyAsset>();

		[EditorHelp("Mouse/Touch Factor", "The actual touch/mouse move is multiplied with this number " +
			"to determine the rotation change.\n" +
			"Set to negative numbers to invert rotation.", "")]
		public float rotationFactor = 1;

		[EditorFoldout("Mouse/Touch Control", "Input settings for mouse and touch control.", "")]
		[EditorEndFoldout(2)]
		[EditorEndCondition]
		public MouseTouchControl rotationMouseTouch = new MouseTouchControl(MouseTouchType.None, 1, 2, MouseTouchMode.Move);


		// panning
		[EditorHelp("Use Panning In", "Select when camera panning can be used:\n" +
			"- Field: Useable in the field (i.e. not in battles).\n" +
			"- Battle: Useable in battles (i.e. not in the field).\n" +
			"- Both: Useable in battles and in the field.\n" +
			"- None: Not used.", "")]
		[EditorFoldout("Panning Settings", "The camera can optionally pan from the player.", "")]
		public UseableIn usePanningIn = UseableIn.None;

		[EditorHelp("Remember Panning", "The camera panning will be remembered when changing between scenes.\n" +
			"The camera's panning will be transfered over to the new scene.", "")]
		[EditorCondition("usePanningIn", UseableIn.None)]
		[EditorElseCondition]
		public bool rememberPanning = false;

		[EditorHelp("In Battle", "Remember the panning in battle.\n" +
			"If disabled, the panning will not be remembered/restored when loading into or out of a battle scene.", "")]
		[EditorIndent]
		[EditorCondition("rememberPanning", true)]
		[EditorEndCondition]
		public bool rememberPanningBattle = true;

		[EditorHelp("Reset On Target Change", "The panning is reset when changing the camera control target.", "")]
		public bool cameraTargetChangeResetPanning = false;

		[EditorHelp("Block On Target Change", "Panning is blocked while changing the camera control target.", "")]
		public bool cameraTargetChangeBlockPanning = false;

		[EditorHelp("Ignore Player Move", "While panning, changes to the player's position will be ignored.\n" +
			"I.e. panning will use the position the pan started at as it's basis instead of the player's position.\n" +
			"If disabled, panning will follow the player's movement.", "")]
		public bool panningIgnorePlayerMove = false;

		[EditorSeparator]
		[EditorTitleLabel("Panning Speed")]
		public SpeedControl panningSpeed = new SpeedControl(10);

		[EditorFoldout("Horizontal Panning Axis", "Define the input keys used for horizontal panning.")]
		[EditorEndFoldout]
		public AxisControl horizontalPanningAxis = new AxisControl();

		[EditorFoldout("Vertical Panning Axis", "Define the input keys used for vertical panning.")]
		[EditorEndFoldout]
		public AxisControl verticalPanningAxis = new AxisControl();

		[EditorHelp("Center Key", "The input key used to center the camera back on the player.", "")]
		public AssetSelection<InputKeyAsset> centerPanningKey = new AssetSelection<InputKeyAsset>();

		[EditorHelp("Use Transition", "Use the camera target transition when centering back on the player via the center key.", "")]
		[EditorIndent]
		public bool centerPanningKeyTransition = false;

		[EditorHelp("Limit Panning", "Limit the panning to a defined distance to the player.", "")]
		[EditorSeparator]
		public bool limitPanning = true;

		[EditorHelp("Distance Limit Field", "The distance to the player in world units the panning is limited to in the field.", "")]
		[EditorCondition("limitPanning", true)]
		public float panningDistanceLimitField = 20;

		[EditorHelp("Distance Limit Battle", "The distance to the player in world units the panning is limited to in battles.", "")]
		[EditorEndCondition]
		public float panningDistanceLimitBattle = 20;

		// screen edge panning
		[EditorHelp("Use Edge Panning In", "Select when panning by moving the mouse cursor to the edge of the screen can be used:\n" +
			"- Field: Useable in the field (i.e. not in battles).\n" +
			"- Battle: Useable in battles (i.e. not in the field).\n" +
			"- Both: Useable in battles and in the field.\n" +
			"- None: Not used.", "")]
		[EditorFoldout("Screen Edge Panning", "Optionally pan by moving the mouse cursor to the edge of the screen.", "")]
		public UseableIn useScreenEdgePanningIn = UseableIn.None;

		[EditorHelp("UI Blocks Panning", "Screen edge panning is blocked when the cursor is over a UI (e.g. a HUD).", "")]
		[EditorCondition("useScreenEdgePanningIn", UseableIn.None)]
		[EditorElseCondition]
		public bool screenEdgePanningUIBlock = false;

		[EditorSeparator]
		[EditorTitleLabel("Edge Panning Speed")]
		public SpeedControl screenEdgePanningSpeed = new SpeedControl(10);

		[EditorHelp("Screen Edge Distance", "Distance to the edges of the screen to start panning.\n" +
			"Left = X, top = Y, right = Z, bottom = W.", "")]
		[EditorSeparator]
		public Vector4 screenEdgeDistance = new Vector4(100, 100, 100, 100);

		[EditorHelp("Distance In", "The distance is either defined in a fixed 'Value' or 'Percent' of the screen size.n" +
			"When using 'Percent', the screen width will be used for left/right panning, the screen height for top/bottom panning.", "")]
		[EditorEndFoldout]
		[EditorEndCondition]
		public ValueSetter screenEdgeValueSetter = ValueSetter.Value;

		// drag panning
		[EditorHelp("Use Drag Panning In", "Select when panning by click-dragging the mouse cursor can be used:\n" +
			"- Field: Useable in the field (i.e. not in battles).\n" +
			"- Battle: Useable in battles (i.e. not in the field).\n" +
			"- Both: Useable in battles and in the field.\n" +
			"- None: Not used.", "")]
		[EditorFoldout("Cursor Drag Panning", "Optionally pan by dragging the mouse cursor.", "")]
		public UseableIn useDragPanningIn = UseableIn.None;

		[EditorHelp("UI Blocks Panning", "Drag panning is blocked when the cursor is over a UI (e.g. a HUD).", "")]
		[EditorCondition("useDragPanningIn", UseableIn.None)]
		[EditorElseCondition]
		public bool dragPanningUIBlock = false;

		[EditorHelp("Invert X", "Invert dragging on the X-axis.", "")]
		public bool dragPanningInvertX = false;

		[EditorHelp("Invert Y", "Invert dragging on the Y-axis.", "")]
		public bool dragPanningInvertY = false;

		[EditorHelp("Block Mouse Input", "Using drag panning will block mouse input for other controls/interactions while dragging.\n" +
			"Enable this option when drag panning should prevent e.g. 'Mouse' player controls or click interactions from being used.\n" +
			"Use the 'End' mouse/touch mode in the mouse player controls and the 'Move' mouse/touch mode in the drag panning.", "")]
		public bool dragPanningBlockMouseInput = false;

		[EditorHelp("No Block Timeout (s)", "Timeout in seconds before blocking mouse input.\n" +
			"This is used to prevent fast clicks blocking other controls, since they can potentially include a short mouse move.", "")]
		[EditorIndent]
		[EditorLimit(0.0f, false)]
		[EditorCondition("dragPanningBlockMouseInput", true)]
		[EditorEndCondition]
		public float dragPanningNoBlockMITimeout = 0.1f;

		[EditorSeparator]
		[EditorTitleLabel("Drag Panning Speed")]
		public SpeedControl dragPanningSpeed = new SpeedControl(1);

		[EditorHelp("Release Smoothing (s)", "Time in seconds the panning will continue when releasing while dragging.\n" +
			"The panning change will be smoothed toward 0 in that time.", "")]
		[EditorLimit(0.0f, false)]
		public float dragPanningReleaseSmoothing = 0.3f;

		[EditorFoldout("Mouse/Touch Control", "Input settings for mouse and touch control.", "")]
		[EditorEndFoldout(3)]
		[EditorEndCondition(2)]
		public MouseTouchControl dragPanningMouseTouch = new MouseTouchControl(MouseTouchType.Mouse, 1, 2, MouseTouchMode.Move);



		// zooming
		[EditorHelp("Use Zooming In", "Select when camera zooming can be used:\n" +
			"- Field: Useable in the field (i.e. not in battles).\n" +
			"- Battle: Useable in battles (i.e. not in the field).\n" +
			"- Both: Useable in battles and in the field.\n" +
			"- None: Not used.", "")]
		[EditorFoldout("Zoom Settings", "The camera can optionally be zoomed in/out.", "")]
		public UseableIn useZoomingIn = UseableIn.None;

		[EditorHelp("Remember Zoom", "The camera zoom will be remembered when changing between scenes.\n" +
			"The camera's zoom will be transfered over to the new scene.", "")]
		[EditorCondition("useZoomingIn", UseableIn.None)]
		[EditorElseCondition]
		public bool rememberZoom = false;

		[EditorHelp("In Battle", "Remember the zoom in battle.\n" +
			"If disabled, the zoom will not be remembered/restored when loading into or out of a battle scene.", "")]
		[EditorIndent]
		[EditorCondition("rememberZoom", true)]
		[EditorEndCondition]
		public bool rememberZoomBattle = true;

		[EditorHelp("Reset On Target Change", "The zoom is reset when changing the camera control target.", "")]
		public bool cameraTargetChangeResetZoom = false;

		[EditorHelp("Block On Target Change", "Zoom is blocked while changing the camera control target.", "")]
		public bool cameraTargetChangeBlockZoom = false;

		[EditorHelp("UI Blocks Zooming", "Zooming is blocked when the cursor is over a UI (e.g. a HUD).", "")]
		public bool zoomUIBlock = false;

		[EditorHelp("Height Input Change", "Define the height change (in world units) per zoom input.\n" +
			"Use negative values to inverse the height changes.", "")]
		public float zoomHeightInputChange = 3;

		[EditorHelp("Distance Input Change", "Define the distance change (in world units) per zoom input.\n" +
			"Use negative values to inverse the distance changes.", "")]
		public float zoomDistanceInputChange = 3;

		[EditorHelp("Use Delta Time", "The zoom input change is multiplied by the delta time.\n" +
			"Enable this setting when using continuous input, e.g. from keys that are held down.", "")]
		public bool zoomDeltaTime = false;

		[EditorSeparator]
		public AxisControl zoomAxis = new AxisControl();

		[EditorSeparator]
		public MouseScrollWheelControl zoomScrollWheel = new MouseScrollWheelControl();

		[EditorSeparator]
		[EditorHelp("Reset Zoom Key", "The input key used to reset the zoom to the initial value.", "")]
		public AssetSelection<InputKeyAsset> zoomResetInputKey = new AssetSelection<InputKeyAsset>();

		// height
		// field
		[EditorHelp("Min Height Field", "The minimum height that can be reached through zooming in the field.", "")]
		[EditorFoldout("Height Settings", "Define the min/max height allowed in the field or in battle.\n" +
			"Optionally use separate input keys to only change the height.", "")]
		public float zoomMinHeightField = 5;

		[EditorHelp("Max Height Field", "The maximum height that can be reached through zooming in the field.", "")]
		public float zoomMaxHeightField = 15;

		// battle
		[EditorHelp("Min Height Battle", "The minimum height that can be reached through zooming in battle.", "")]
		[EditorSeparator]
		public float zoomMinHeightBattle = 5;

		[EditorHelp("Max Height Battle", "The maximum height that can be reached through zooming in battle.", "")]
		public float zoomMaxHeightBattle = 15;

		// own input
		[EditorHelp("Use Height Input", "Use separate input keys to only change the height.", "")]
		[EditorSeparator]
		public bool useHeightInput = false;

		[EditorHelp("Height Input Change", "Define the height change (in world units) per height input.\n" +
			"Use negative values to inverse the height changes.", "")]
		[EditorCondition("useHeightInput", true)]
		public float heightInputChange = 3;

		[EditorHelp("Use Delta Time", "The height input change is multiplied by the delta time.\n" +
			"Enable this setting when using continuous input, e.g. from keys that are held down.", "")]
		public bool heightDeltaTime = false;

		public AxisControl heightAxis = new AxisControl();

		[EditorHelp("Reset Height Key", "The input key used to reset the height to the initial value.", "")]
		[EditorEndFoldout]
		[EditorEndCondition]
		public AssetSelection<InputKeyAsset> heightResetInputKey = new AssetSelection<InputKeyAsset>();

		// distance
		// field
		[EditorHelp("Min Distance Field", "The minimum distance that can be reached through zooming in the field.", "")]
		[EditorFoldout("Distance Settings", "Define the min/max distance allowed in the field or in battle.\n" +
			"Optionally use separate input keys to only change the distance.", "")]
		public float zoomMinDistanceField = 5;

		[EditorHelp("Max Distance Field", "The maximum distance that can be reached through zooming in the field.", "")]
		public float zoomMaxDistanceField = 15;

		// battle
		[EditorHelp("Min Distance Battle", "The minimum distance that can be reached through zooming in battle.", "")]
		[EditorSeparator]
		public float zoomMinDistanceBattle = 5;

		[EditorHelp("Max Distance Battle", "The maximum distance that can be reached through zooming in battle.", "")]
		public float zoomMaxDistanceBattle = 15;

		// own input
		[EditorHelp("Use Distance Input", "Use separate input keys to only change the distance.", "")]
		[EditorSeparator]
		public bool useDistanceInput = false;

		[EditorHelp("Distance Input Change", "Define the distance change (in world units) per distance input.\n" +
			"Use negative values to inverse the distance changes.", "")]
		[EditorCondition("useDistanceInput", true)]
		public float distanceInputChange = 3;

		[EditorHelp("Use Delta Time", "The distance input change is multiplied by the delta time.\n" +
			"Enable this setting when using continuous input, e.g. from keys that are held down.", "")]
		public bool distanceDeltaTime = false;

		public AxisControl distanceAxis = new AxisControl();

		[EditorHelp("Reset Distance Key", "The input key used to reset the distance to the initial value.", "")]
		[EditorEndFoldout(2)]
		[EditorEndCondition(2)]
		public AssetSelection<InputKeyAsset> distanceResetInputKey = new AssetSelection<InputKeyAsset>();


		// in-game
		private bool hasStoredValues = false;

		private float storedRotation = 0;

		private float storedInputRotation = 0;

		private float storedLastTargetRotation = 0;

		private Vector3 storedInputPanning = Vector3.zero;

		private Vector2 storedInputZoom = Vector2.zero;

		private float storedLastTargetDistance = 0;

		public TopDownBorderCameraSettings()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);
			this.childObject.Upgrade(data, "onChild");
			this.horizontalPanningAxis.UpgradeOldAxis(data, "horizontalPanningKey");
			this.verticalPanningAxis.UpgradeOldAxis(data, "verticalPanningKey");
		}

		public void Setup(GameObject camera)
		{
			if(camera != null)
			{
				TopDownBorderCamera comp = camera.GetComponent<TopDownBorderCamera>();
				if(comp == null)
				{
					comp = camera.AddComponent<TopDownBorderCamera>();
					comp.settings.SetData(this.GetData());
				}

				if(comp != null)
				{
					Maki.Control.AddCameraControl(comp);
				}
			}
		}


		/*
		============================================================================
		Store functions
		============================================================================
		*/
		public void StoreRotation(float rotation, float inputRotation, float lastTargetRotation)
		{
			this.hasStoredValues = true;
			this.storedRotation = rotation;
			this.storedInputRotation = inputRotation;
			this.storedLastTargetRotation = lastTargetRotation;
		}

		public void GetStoredRotation(ref float rotation, ref float inputRotation, ref float lastTargetRotation)
		{
			if(this.hasStoredValues)
			{
				rotation = this.storedRotation;
				inputRotation = this.storedInputRotation;
				lastTargetRotation = this.storedLastTargetRotation;
			}
		}

		public void StorePanning(Vector3 inputPanning)
		{
			this.hasStoredValues = true;
			this.storedInputPanning = inputPanning;
		}

		public void GetStoredPanning(ref Vector3 inputPanning)
		{
			if(this.hasStoredValues)
			{
				inputPanning = this.storedInputPanning;
			}
		}

		public void StoreZoom(Vector2 inputZoom, float lastTargetDistance)
		{
			this.hasStoredValues = true;
			this.storedInputZoom = inputZoom;
			this.storedLastTargetDistance = lastTargetDistance;
		}

		public void GetStoredZoom(ref Vector2 inputZoom, ref float lastTargetDistance)
		{
			if(this.hasStoredValues)
			{
				inputZoom = this.storedInputZoom;
				lastTargetDistance = this.storedLastTargetDistance;
			}
		}
	}
}
