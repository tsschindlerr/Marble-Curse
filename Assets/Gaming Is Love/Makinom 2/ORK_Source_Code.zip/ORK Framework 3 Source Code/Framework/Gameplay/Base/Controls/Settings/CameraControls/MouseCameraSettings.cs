﻿
using UnityEngine;
using GamingIsLove.ORKFramework.Components;
using System.Collections.Generic;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework
{
	public class MouseCameraSettings : BaseData
	{
		[EditorHelp("Child Object", "Use a child object of the player to position the camera.", "")]
		public ChildObjectSettings childObject = new ChildObjectSettings();

		[EditorHelp("Use Unscaled Time", "Use unscaled delta time.\n" +
			"I.e. the camera control is not affected when changing the timescale.", "")]
		public bool useUnscaledTime = false;

		[EditorHelp("Distance", "The distance of the camera to the player.", "")]
		[EditorSeparator]
		public float distance = 10.0f;

		// height
		[EditorHelp("Height", "The height above the player.", "")]
		public float height = 15.0f;

		[EditorHelp("Minimum Height", "The minimum height above the player.", "")]
		public float minHeight = 5.0f;

		[EditorHelp("Maximum Height", "The maximum height above the player.", "")]
		public float maxHeight = 30.0f;

		[EditorHelp("Height Damping", "Used for smoother height changes.\n" +
			"Higher values mean quicker changes, set to 0 to disable.", "")]
		[EditorLimit(0.0f, false)]
		public float heightDamping = 2.0f;


		// input
		[EditorHelp("Use Input", "Changing the camera requires click/touch input.\n" +
			"If disabled, changes the camera without click/touch.")]
		[EditorSeparator]
		public bool useInput = true;

		[EditorFoldout("Mouse/Touch Control", "Input settings for mouse and touch control.", "")]
		[EditorEndFoldout]
		[EditorCondition("useInput", true)]
		[EditorEndCondition]
		public MouseTouchControl mouseTouch = new MouseTouchControl(MouseTouchType.Both, 1, 2, MouseTouchMode.Move);


		// rotation
		[EditorHelp("Allow Rotation", "The rotation of the camera can be changed by mouse/touch controls.\n" +
			"The rotation can be changed by a horizontal mouse/touch drag.", "")]
		[EditorFoldout("Rotation Settings", "The camera can optionally be rotated.", "")]
		public bool allowRotation = true;

		[EditorHelp("Remember Rotation", "The rotation will be remembered when changing between scenes.\n" +
			"The camera's rotation will be transfered over to the new scene.", "")]
		[EditorCondition("allowRotation", true)]
		[EditorEndCondition]
		public bool rememberRotation = false;

		[EditorHelp("In Battle", "Remember the rotation in battle.\n" +
			"If disabled, the rotation will not be remembered/restored when loading into or out of a battle scene.", "")]
		[EditorIndent]
		[EditorCondition("rememberRotation", true)]
		[EditorEndCondition]
		public bool rememberRotationBattle = true;

		[EditorHelp("Start Rotation", "The start rotation of the camera.\n" +
			"E.g. 90 will show the player from the south (world axis).", "")]
		public float rotation = 0;

		[EditorHelp("Rotation Damping", "Used for smoother rotation changes.\n" +
			"Higher values mean quicker changes, set to 0 to disable.", "")]
		[EditorLimit(0.0f, false)]
		public float rotationDamping = 3.0f;

		[EditorHelp("Reset On Target Change", "The rotation is reset when changing the camera control target.", "")]
		[EditorCondition("allowRotation", true)]
		public bool cameraTargetChangeResetRotation = false;

		[EditorHelp("Block On Target Change", "Rotation is blocked while changing the camera control target.", "")]
		public bool cameraTargetChangeBlockRotation = false;

		[EditorHelp("Rotation Factor", "The actual touch/mouse move is multiplied with this number " +
			"to determine the rotation change.\n" +
			"Set to negative numbers to invert rotation.", "")]
		[EditorEndFoldout]
		[EditorEndCondition]
		public float rotationFactor = 1;


		// zoom
		[EditorHelp("Allow Zoom", "The camera zoom (height) can be changed by mouse/touch controls.\n" +
			"The height can be changed by a vertical mouse/touch drag.", "")]
		[EditorFoldout("Zoom Settings", "The camera can optionally be zoomed in/out.", "")]
		public bool allowZoom = true;

		[EditorHelp("Remember Zoom", "The camera zoom will be remembered when changing between scenes.\n" +
			"The camera's zoom will be transfered over to the new scene.", "")]
		[EditorCondition("allowZoom", true)]
		public bool rememberZoom = false;

		[EditorHelp("In Battle", "Remember the zoom in battle.\n" +
			"If disabled, the zoom will not be remembered/restored when loading into or out of a battle scene.", "")]
		[EditorIndent]
		[EditorCondition("rememberZoom", true)]
		[EditorEndCondition]
		public bool rememberZoomBattle = true;

		[EditorHelp("Reset On Target Change", "The zoom is reset when changing the camera control target.", "")]
		public bool cameraTargetChangeResetZoom = false;

		[EditorHelp("Block On Target Change", "Zooming is blocked while changing the camera control target.", "")]
		public bool cameraTargetChangeBlockZoom = false;

		[EditorHelp("Zoom Factor", "The actual touch/mouse move is multiplied with this number " +
			"to determine the zoom change.\n" +
			"Set to negative numbers to invert zoom.", "")]
		public float zoomFactor = 1;

		[EditorSeparator]
		public AxisControl zoomAxis = new AxisControl();

		[EditorSeparator]
		public MouseScrollWheelControl zoomScrollWheel = new MouseScrollWheelControl();

		[EditorSeparator]
		[EditorHelp("Zoom Key Change", "The amount the zoom changes on key press.", "")]
		public float zoomKeyChange = 3;

		[EditorHelp("Limit Change", "Changing the camera rotation/zoom is limited to one axis at a time.\n" +
			"The axis (horizontal for rotation, vertical for zoom) that received the larger change will be used.", "")]
		[EditorEndFoldout]
		[EditorCondition("allowRotation", true)]
		[EditorEndCondition(2)]
		public bool limitChange = true;


		// in-game
		private bool hasStoredValues = false;

		private float storedRotation = 0;

		private float storedLastTargetRotation = 0;

		private float storedHeight = 0;

		private float storedLastTargetHeight = 0;

		public MouseCameraSettings()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);
			this.childObject.Upgrade(data, "onChild");
		}

		public void Setup(GameObject camera)
		{
			if(camera != null)
			{
				MouseCamera comp = camera.GetComponent<MouseCamera>();
				if(comp == null)
				{
					comp = camera.AddComponent<MouseCamera>();
					comp.settings.SetData(this.GetData());
				}
				if(comp != null)
				{
					Maki.Control.AddCameraControl(comp);
				}
			}
		}


		/*
		============================================================================
		Store functions
		============================================================================
		*/
		public void StoreRotation(float rotation, float lastTargetRotation)
		{
			this.hasStoredValues = true;
			this.storedRotation = rotation;
			this.storedLastTargetRotation = lastTargetRotation;
		}

		public void GetStoredRotation(ref float rotation, ref float lastTargetRotation)
		{
			if(this.hasStoredValues)
			{
				rotation = this.storedRotation;
				lastTargetRotation = this.storedLastTargetRotation;
			}
		}

		public void StoreZoom(float height, float lastTargetHeight)
		{
			this.hasStoredValues = true;
			this.storedHeight = height;
			this.storedLastTargetHeight = lastTargetHeight;
		}

		public void GetStoredZoom(ref float height, ref float lastTargetHeight)
		{
			if(this.hasStoredValues)
			{
				height = this.storedHeight;
				lastTargetHeight = this.storedLastTargetHeight;
			}
		}
	}
}
