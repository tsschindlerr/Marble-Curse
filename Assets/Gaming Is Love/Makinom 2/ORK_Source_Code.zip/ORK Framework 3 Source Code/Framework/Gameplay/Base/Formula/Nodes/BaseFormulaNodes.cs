
using UnityEngine;
using GamingIsLove.ORKFramework;
using System.Collections.Generic;

namespace GamingIsLove.Makinom.Formulas.Nodes
{
	[EditorHelp("Check Difficulty", "Checks the game's difficulty.\n" +
		"If the check is valid, 'Success' will be executed, otherwise 'Failed'.", "")]
	[NodeInfo("Base", "Check")]
	public class CheckDifficultyNode : BaseFormulaCheckNode
	{
		public DifficultyCheck difficultyCheck = new DifficultyCheck();

		public CheckDifficultyNode()
		{

		}

		public override int Calculate(FormulaCall call)
		{
			if(this.difficultyCheck.Check())
			{
				return this.next;
			}
			else
			{
				return this.nextFail;
			}
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.difficultyCheck.ToString();
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.baseNodeColor; }
		}
	}

	[EditorHelp("Check Battle Turn", "Checks the current battle turn (independent of combatants).\n" +
		"If the check is valid, 'Success' will be executed next, otherwise 'Failed'.\n" +
		"Please note that battle turns are only used in 'Turn Based', 'Active Time' and 'Phase' battles.\n" +
		"In 'Active Time' battles, a battle turn lasts until each combatant (that's able to) has performed 1 action.", "")]
	[NodeInfo("Base", "Combatant", "Check")]
	public class CheckBattleTurnNode : BaseFormulaCheckNode
	{
		[EditorLabel("The current battle turn will be changed by the defined math function.\n" +
			"E.g. use 'Modulo (%)' to check for every defined turns (is equal 0), e.g. every 2nd turn via a divisor of 2.")]
		public MathFunction mathFunction = new MathFunction();

		[EditorHelp("Check Type", "Checks if the value is equal, not equal, less or greater than a defined value.\n" +
			"Range inclusive checks if the value is between two defined values, including the values.\n" +
			"Range exclusive checks if the value is between two defined values, excluding the values.\n" +
			"Approximately checks if the value is similar to the defined value.", "")]
		[EditorSeparator]
		public ValueCheck<FormulaObjectSelection> check = new ValueCheck<FormulaObjectSelection>();

		public CheckBattleTurnNode()
		{

		}

		public override int Calculate(FormulaCall call)
		{
			if(this.check.Check(this.mathFunction.Use(ORK.Battle.Turn), call))
			{
				return this.next;
			}
			else
			{
				return this.nextFail;
			}
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.mathFunction.ToString() + " " + this.check.ToString();
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.valueNodeColor; }
		}
	}
}
