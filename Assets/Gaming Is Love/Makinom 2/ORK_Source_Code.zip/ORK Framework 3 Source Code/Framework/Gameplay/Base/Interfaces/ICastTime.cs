﻿
using UnityEngine;
using System.Collections.Generic;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework
{
	public interface ICastTime
	{
		CastTime GetCastTimeSetting(Combatant user);

		void ShowCastingConsoleText(Combatant user, List<Combatant> target,
			Dictionary<Combatant, StatusChangeInformation> statusChangesTarget);

		void ShowCancelCastingConsoleText(Combatant user, List<Combatant> target,
			Dictionary<Combatant, StatusChangeInformation> statusChangesTarget);
	}
}
