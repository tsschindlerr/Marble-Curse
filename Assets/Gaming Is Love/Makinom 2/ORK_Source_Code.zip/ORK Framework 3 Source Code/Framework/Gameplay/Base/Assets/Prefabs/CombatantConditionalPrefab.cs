
using UnityEngine;
using GamingIsLove.ORKFramework.Components;
using System.Collections.Generic;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework
{
	public class CombatantConditionalPrefab : BaseData, IFoldoutInfo
	{
		// prefab
		public CombatantPrefab prefab = new CombatantPrefab();

		[EditorHelp("Use Spawned Scale", "Use the scale of the currently spawned prefab when changing prefabs.", "")]
		[EditorSeparator]
		public bool useSpawnedScale = true;


		// status conditions
		[EditorFoldout("Status Conditions", "Define the status conditions that have to be valid to use this prefab.", "")]
		[EditorEndFoldout]
		public StatusConditionSettings statusConditions = new StatusConditionSettings();


		// variable conditions
		[EditorFoldout("Variable Conditions", "Define the variable conditions that have to be valid to use this prefab.", "")]
		[EditorEndFoldout]
		[EditorLabel("The combatant's object variables/selected data are available as 'Local' origin.")]
		public VariableCondition<GameObjectSelection> condition = new VariableCondition<GameObjectSelection>();

		public CombatantConditionalPrefab()
		{

		}

		public virtual string GetFoldoutInfo()
		{
			return this.prefab.prefab.ToString();
		}


		/*
		============================================================================
		Check functions
		============================================================================
		*/
		public virtual bool Check(Combatant combatant)
		{
			return this.prefab.prefab.settings.Get() != null &&
				combatant != null &&
				this.statusConditions.Check(combatant) &&
				this.CheckVariables(combatant);
		}

		public virtual bool CheckVariables(Combatant combatant)
		{
			return !this.condition.Has ||
				this.condition.CheckVariables(combatant.Call);
		}


		/*
		============================================================================
		Status change register functions
		============================================================================
		*/
		public virtual void RegisterStatusChanges(Combatant combatant, IStatusChanged notify)
		{
			this.statusConditions.RegisterStatusChanges(combatant, notify);
		}

		public virtual void UnregisterStatusChanges(Combatant combatant, IStatusChanged notify)
		{
			this.statusConditions.UnregisterStatusChanges(combatant, notify);
		}
	}
}
