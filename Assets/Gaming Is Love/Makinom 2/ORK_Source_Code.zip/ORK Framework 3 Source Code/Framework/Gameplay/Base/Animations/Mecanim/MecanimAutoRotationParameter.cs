
using UnityEngine;
using GamingIsLove.ORKFramework;
using System.Collections.Generic;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework.Animations
{
	public class MecanimAutoRotationParameter : BaseData
	{
		[EditorHelp("Rotation Type", "Select which rotation type will be used:\n" +
			"- Full Degree: Sets a float parameter to the actual rotation in degree (0-360).\n" +
			"- Direction 4: Sets an int parameter to a 4-directional " +
			"number representation of the rotation " +
			"(0-3, 0 = east, 1 = north, 2 = west, 3 = south).\n" +
			"- Direction 8: Sets an int parameter to an 8-directional " +
			"number representation of the rotation " +
			"(0-7, 0 = east, 1 = north-east, 2 = north, 3 = north-west, 4 = west, etc.).", "")]
		public MecanimRotationType type = MecanimRotationType.FullDegree;

		[EditorHelp("Set Float Parameter", "Set a float parameter instead of an int parameter")]
		[EditorIndent]
		[EditorCondition("type", MecanimRotationType.Direction4)]
		[EditorCondition("type", MecanimRotationType.Direction8)]
		[EditorEndCondition]
		public bool setFloat = false;

		[EditorHelp("Parameter Name", "The name of the int/float parameter " +
			"used to set the rotation of the combatant.", "")]
		[EditorWidth(true)]
		public string parameterName = "";

		[EditorCondition("type", MecanimRotationType.FullDegree)]
		[EditorCondition("setFloat", true)]
		[EditorEndCondition]
		public MecanimFloatParameterDamping damp = new MecanimFloatParameterDamping();

		[EditorHelp("In Camera Direction", "The rotation is based on the direction of the camera.")]
		public bool inCameraDirection = false;

		[EditorHelp("Rotation Offset", "Offset added to the rotation value.\n" +
			"Added before changing to 4/8 directional number.")]
		public float rotationOffset = 0;

		[EditorHelp("Negate Rotation", "Use -rotation, i.e. the negated value of the rotation.")]
		public bool negateRotation = false;

		public MecanimAutoRotationParameter()
		{

		}

		public void SetParameter(Animator animator, float rotation)
		{
			rotation += this.rotationOffset;
			if(this.negateRotation)
			{
				rotation = -rotation;
			}
			if(MecanimRotationType.FullDegree == this.type)
			{
				ValueHelper.SecureRotation(ref rotation);
				this.damp.Set(animator, this.parameterName, rotation);
			}
			else if(MecanimRotationType.Direction4 == this.type)
			{
				if(this.setFloat)
				{
					this.damp.Set(animator, this.parameterName, ValueHelper.Get4Directional(rotation));
				}
				else
				{
					animator.SetInteger(this.parameterName, ValueHelper.Get4Directional(rotation));
				}
			}
			else if(MecanimRotationType.Direction8 == this.type)
			{
				if(this.setFloat)
				{
					this.damp.Set(animator, this.parameterName, ValueHelper.Get8Directional(rotation));
				}
				else
				{
					animator.SetInteger(this.parameterName, ValueHelper.Get8Directional(rotation));
				}
			}
		}
	}
}
