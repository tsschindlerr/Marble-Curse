﻿
using UnityEngine;
using System.Collections.Generic;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework.Conditions
{
	[EditorSettingInfo("Ability Type", "The combatant must or mustn't have an ability of a selected ability type.")]
	public class AbilityTypeStatusConditionType : BaseStatusConditionType
	{
		[EditorHelp("Ability Type", "Select the ability type that will be used.", "")]
		public AssetSelection<AbilityTypeAsset> abilityType = new AssetSelection<AbilityTypeAsset>();

		[EditorHelp("Use Sub-Types", "The sub-types of the defined ability type will also be checked.", "")]
		[EditorIndent]
		public bool useSubTypes = false;

		[EditorHelp("Is Valid", "The combatant must have an ability of the defined type.\n" +
			"If disabled, the combatant mustn't have the ability type.", "")]
		public bool isValid = true;


		// filters
		[EditorHelp("Check Attacks", "The combatant's base attacks will be checked.", "")]
		[EditorSeparator]
		public bool checkAttacks = false;

		[EditorHelp("Check Counter", "The combatant's counter attack will be checked.", "")]
		public bool checkCounter = false;

		[EditorHelp("Check Class Ability", "The combatant's class ability will be checked.", "")]
		public bool checkClass = false;

		[EditorHelp("Check Active Abilities", "The combatant's active abilities will be checked.", "")]
		public bool checkActive = true;

		[EditorHelp("Check Passive Abilities", "The combatant's passive abilities will be checked.", "")]
		public bool checkPassive = true;

		[EditorHelp("Check Temporary Abilities", "Select if temporary abilities will be checked:\n" +
			"- Yes: Temporary abilities will be checked.\n" +
			"- No: Temporary abilities will not be checked.\n" +
			"- Only: Only temporary abilities will be checked.", "")]
		public IncludeCheckType checkTemporary = IncludeCheckType.Yes;

		[EditorHelp("Ignore Availability", "Ignore ability availability settings and use all abilities added to the combatant.")]
		public bool ignoreAvailability = false;

		public AbilityTypeStatusConditionType()
		{

		}

		public override string ToString()
		{
			return (this.isValid ? "is " : "not ") + this.abilityType.ToString();
		}


		/*
		============================================================================
		Check functions
		============================================================================
		*/
		public override bool Check(Combatant combatant)
		{
			return this.abilityType.StoredAsset != null &&
				this.isValid == combatant.Abilities.HasType(this.useSubTypes, this.abilityType.StoredAsset.Settings,
					this.checkAttacks, this.checkCounter, this.checkClass, this.checkActive, this.checkPassive, this.checkTemporary, this.ignoreAvailability, false);
		}


		/*
		============================================================================
		Status change register functions
		============================================================================
		*/
		public override void Register(Combatant combatant, IStatusChanged notify)
		{
			combatant.Events.AbilitiesChanged += notify.NotifyStatusChanged;
		}

		public override void Unregister(Combatant combatant, IStatusChanged notify)
		{
			combatant.Events.AbilitiesChanged -= notify.NotifyStatusChanged;
		}

		public override void Register(Combatant combatant, Notify notify)
		{
			combatant.Events.AbilitiesChangedSimple += notify;
		}

		public override void Unregister(Combatant combatant, Notify notify)
		{
			combatant.Events.AbilitiesChangedSimple -= notify;
		}
	}
}
