﻿
using UnityEngine;
using GamingIsLove.Makinom;
using System.Collections.Generic;

namespace GamingIsLove.ORKFramework
{
	[EditorSettingInfo("Shop Close", "When a shop is closed.")]
	public class ShopCloseGameStateChangeType : BaseGameStateChangeType
	{
		public ShopCloseGameStateChangeType()
		{

		}

		public override void Register(Notify notify)
		{
			ORK.Menu.ShopClosed += notify;
		}
	}
}
