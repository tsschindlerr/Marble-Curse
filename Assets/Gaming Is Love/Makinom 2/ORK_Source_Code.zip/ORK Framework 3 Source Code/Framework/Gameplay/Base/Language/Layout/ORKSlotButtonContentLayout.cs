﻿
using UnityEngine;
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.UI;
using GamingIsLove.ORKFramework.UI;
using System.Collections.Generic;

namespace GamingIsLove.ORKFramework
{
	public class ORKSlotButtonContentLayout : ButtonContentLayout<ORKSlotContentLayout>
	{
		public ORKSlotButtonContentLayout()
		{

		}

		public ORKSlotButtonContentLayout(string contentID, ORKSlotContentLayoutType type)
		{
			this.additionalContent = new ContentID<ORKSlotContentLayout>[]
			{
				new ContentID<ORKSlotContentLayout>(contentID, new ORKSlotContentLayout(type))
			};
		}

		public ORKSlotButtonContentLayout(string[] contentID, ORKSlotContentLayoutType[] type)
		{
			this.additionalContent = new ContentID<ORKSlotContentLayout>[contentID.Length];
			for(int i = 0; i < this.additionalContent.Length; i++)
			{
				this.additionalContent[i] = new ContentID<ORKSlotContentLayout>(contentID[i],
					new ORKSlotContentLayout(i < type.Length ? type[i] : ORKSlotContentLayoutType.TextAndIcon));
			}
		}

		public ORKSlotButtonContentLayout(string contentID, string contentText)
		{
			this.additionalContent = new ContentID<ORKSlotContentLayout>[]
			{
				new ContentID<ORKSlotContentLayout>(contentID, new ORKSlotContentLayout(contentText))
			};
		}

		public ORKSlotButtonContentLayout(string[] contentID, string[] contentText)
		{
			this.additionalContent = new ContentID<ORKSlotContentLayout>[contentID.Length];
			for(int i = 0; i < this.additionalContent.Length; i++)
			{
				this.additionalContent[i] = new ContentID<ORKSlotContentLayout>(contentID[i],
					new ORKSlotContentLayout(i < contentText.Length ? contentText[i] : ""));
			}
		}


		/*
		============================================================================
		Contains functions
		============================================================================
		*/
		public virtual bool Contains(string text)
		{
			if(this.mainContentLayout.Contains(text))
			{
				return true;
			}
			for(int i = 0; i < this.additionalContent.Length; i++)
			{
				if(this.additionalContent[i].content.Contains(text))
				{
					return true;
				}
			}
			return false;
		}

		public virtual bool ContainsReuseTime()
		{
			return this.Contains("<reuse");
		}


		/*
		============================================================================
		Content functions
		============================================================================
		*/
		public virtual UIButtonInputContent GetContent(IContent slotContent, IContent content)
		{
			UIButtonInputContent buttonInputContent = new UIButtonInputContent(
				this.mainContentLayout.GetContent(slotContent, content),
				content.GetDescription());
			this.customInput.Use((UIInputContent)buttonInputContent);

			for(int i = 0; i < this.additionalContent.Length; i++)
			{
				buttonInputContent.AddAdditionalContent(
					this.additionalContent[i].contentID,
					this.additionalContent[i].content.GetContent(slotContent, content));
			}
			return buttonInputContent;
		}

		public virtual UIButtonInputContent GetContent(IContent slotContent, IShortcut content, Combatant combatant)
		{
			return this.GetContent(slotContent, content, combatant, content.GetDrag(combatant));
		}

		public virtual UIButtonInputContent GetContent(IContent slotContent, IShortcut content, Combatant combatant, DragShortcutWrapper wrapper)
		{
			IContent typeContent = TypeContentHelper.Get(content);
			UIButtonInputContent buttonInputContent = new UIButtonInputContent(
				this.mainContentLayout.GetContent(slotContent, content, typeContent, combatant, wrapper),
				content.GetDescription());
			this.customInput.Use((UIInputContent)buttonInputContent);

			for(int i = 0; i < this.additionalContent.Length; i++)
			{
				buttonInputContent.AddAdditionalContent(
					this.additionalContent[i].contentID,
					this.additionalContent[i].content.GetContent(slotContent, content, typeContent, combatant, wrapper));
			}
			return buttonInputContent;
		}
	}
}
