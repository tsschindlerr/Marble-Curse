﻿
using UnityEngine;
using System.Collections.Generic;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework
{
	[System.Serializable]
	public class SpeedControl : BaseData
	{
		[EditorHelp("Speed", "The speed used that will be used.", "")]
		public float speed = 5;

		[EditorHelp("Use Speed Key", "Use a different speed while holding down an input key.", "")]
		public bool useInputKey = false;

		[EditorHelp("Speed Key", "The input key used to change the speed.\n" +
			"The different speed will be used while the input key receives input (e.g. using 'Hold' input handling).", "")]
		[EditorIndent]
		[EditorCondition("useInputKey", true)]
		public AssetSelection<InputKeyAsset> inputKey = new AssetSelection<InputKeyAsset>();

		[EditorHelp("Input Panning Speed", "The speed used for while holding down the speed key.", "")]
		[EditorIndent]
		[EditorEndCondition]
		public float inputSpeed = 10;

		public SpeedControl()
		{

		}

		public SpeedControl(float speed)
		{
			this.speed = speed;
			this.inputSpeed = speed * 2;
		}

		public float GetSpeed()
		{
			if(this.useInputKey && InputKey.GetButton(this.inputKey.StoredAsset))
			{
				return this.inputSpeed;
			}
			else
			{
				return this.speed;
			}
		}
	}
}
