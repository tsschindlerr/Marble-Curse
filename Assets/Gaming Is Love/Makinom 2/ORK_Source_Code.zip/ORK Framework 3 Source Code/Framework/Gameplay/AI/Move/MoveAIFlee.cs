﻿
using UnityEngine;
using GamingIsLove.ORKFramework;
using GamingIsLove.ORKFramework.Components;
using System.Collections.Generic;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework.AI
{
	public class MoveAIFlee : BaseData
	{
		[EditorHelp("Use Flee", "The flee settings are enabled.\n" +
			"The combatant will flee (run into the opposite direction) from a target if certain level conditions are met.", "")]
		public bool enabled = false;

		[EditorHelp("Flee Time (s)", "The time in seconds the combatant will flee from the target.\n" +
			"The combatant will ignore detections and will simply run into the opposite direction.\n" +
			"Set to 0 to ignore flee time and still use detections.", "")]
		[EditorLimit(0.0f, false)]
		[EditorCondition("enabled", true)]
		public float fleeTime = 2;

		[EditorHelp("Prevent Cornered", "The combatant will try to prevent being cornered.\n" +
			"I.e. if the combatant can't move, it'll try to move into different directions, e.g. fleeing toward the enemy.", "")]
		public bool preventCornered = false;

		[EditorHelp("Stopped Look At Target", "Look at the target while the combatant is stopped.", "")]
		public bool stoppedLookAtTarget = false;


		// detection schematic
		[EditorHelp("Detection Schematic", "Select a schematic asset that will be started when the combatant detects a target and starts fleeing from it.\n" +
			"The combatant will be used as 'Machine Object', the detected target as 'Starting Object'.", "")]
		[EditorSeparator]
		public AssetSource<MakinomSchematicAsset> detectionSchematic = new AssetSource<MakinomSchematicAsset>();

		[EditorHelp("Wait", "Wait for the detection schematic to finish before starting to flee from the target.", "")]
		[EditorCondition("detectionSchematic.HasAsset", true)]
		[EditorEndCondition]
		[EditorIndent]
		public bool detectionWaitForSchematic = false;


		// flee range
		[EditorHelp("Use Flee Range", "The combatant will only flee within a range of its start position " +
			"(i.e. the position it has been spawned at).\n" +
			"When leaving the flee range, the combatant will return to its start position.\n" +
			"If disabled, there is no limit to the flee range.", "")]
		[EditorFoldout("Flee Range", "Optionally only flee within a defined range of the combatant's start position.", "")]
		public bool useRange = false;

		[EditorEndFoldout]
		[EditorCondition("useRange", true)]
		[EditorEndCondition]
		[EditorAutoInit]
		public RangeValue range;


		// stop range
		[EditorHelp("Use Stop Range", "The combatant will stop when being outside a defined range to the target it flees from.\n" +
			"If disabled, the combatant will keep fleeing from the target until the flee time is up.", "")]
		[EditorFoldout("Stop Range", "Optionally stop when being outside a defined range to the target.", "")]
		public bool useStopRange = false;

		[EditorEndFoldout]
		[EditorCondition("useStopRange", true)]
		[EditorEndCondition]
		[EditorAutoInit]
		public RangeValue stopRange;


		// conditions
		[EditorHelp("Conditions Needed", "Select if all or just one condition must be valid to flee from the target.", "")]
		[EditorFoldout("Flee Conditions", "Optionally only flee when defined conditions are valid.", "")]
		public Needed needed = Needed.One;

		[EditorEndFoldout]
		[EditorEndCondition]
		[EditorArray("Add Flee Condition", "Adds a flee condition.\n" +
			"You can use multiple conditions to determine if the combatant flees from the target.", "",
			"Remove", "Removes this flee condition.", "", isMove=true, isCopy=true,
			foldout=true, foldoutText=new string[] {
				"Flee Condition", "Flee conditions determine if the combatant flees from the target.", ""
			})]
		public MoveCondition[] condition = new MoveCondition[0];

		public MoveAIFlee()
		{

		}


		/*
		============================================================================
		Flee functions
		============================================================================
		*/
		public bool IsFlee(Combatant combatant, Combatant target)
		{
			if(this.enabled)
			{
				return MoveCondition.Check(combatant, target, this.condition, this.needed);
			}
			return false;
		}

		public bool IsInRange(Vector3 startPosition, Combatant combatant)
		{
			return !this.useRange ||
				this.range == null ||
				this.range.InRange(startPosition, combatant.GameObject);
		}

		public bool IsOutOfRange(Vector3 startPosition, Combatant combatant)
		{
			return this.useRange &&
				this.range != null &&
				this.range.OutOfRange(startPosition, combatant.GameObject);
		}

		public void Use(MoveAIComponent moveAI)
		{
			if(this.fleeTime > 0)
			{
				moveAI.fleeTimeout -= ORK.Game.DeltaMovementTime;

				// out of flee range, back to start position
				if(this.IsOutOfRange(moveAI.startPosition, moveAI.Combatant))
				{
					moveAI.fleeTimeout = -1;
					moveAI.ClearTarget(false);

					moveAI.SetMode(MoveAIMode.Waypoint);
					moveAI.SetMovePosition(moveAI.startPosition);
				}
				// time's up, stop
				else if(moveAI.fleeTimeout <= 0 ||
					(this.useStopRange &&
						this.stopRange.OutOfRange(moveAI.Combatant.GameObject, moveAI.TargetCombatant.GameObject)))
				{
					moveAI.fleeTimeout = -1;
					moveAI.ClearTarget(false);
				}
				else
				{
					if(this.preventCornered)
					{
						moveAI.CheckStuck();
					}
					if(this.useStopRange &&
						this.stopRange.InRange(moveAI.Combatant.GameObject, moveAI.TargetCombatant.GameObject))
					{
						moveAI.UpdateTargetPosition(true);
					}
				}
			}
		}
	}
}
