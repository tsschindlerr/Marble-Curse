﻿
using UnityEngine;
using GamingIsLove.Makinom;
using System.Collections.Generic;

namespace GamingIsLove.ORKFramework.AI
{
	[EditorSettingInfo("Quest Type", "Check quest type status conditions.")]
	public class QuestTypeMoveConditionType : BaseMoveConditionType
	{
		[EditorHelp("Needed", "Either all or just one of the quest type conditions needs to be valid.", "")]
		public Needed needed = Needed.All;

		[EditorArray("Add Quest Type Condition", "Adds a new quest type status condition.", "",
			"Remove", "Removes the quest type status condition.", "",
			isMove = true, isCopy = true, removeCheckField = "questType",
			foldout = true, foldoutText = new string[] {
				"Quest Type Status Condition", "Define the quest type status condition that must be valid.", ""
		})]
		public CheckQuestTypeStatus[] questTypeStatus = new CheckQuestTypeStatus[0];

		public QuestTypeMoveConditionType()
		{

		}

		public override string ToString()
		{
			return "Quest Type";
		}

		public override bool IsValid(Combatant combatant, Combatant target)
		{
			if(this.questTypeStatus.Length > 0)
			{
				for(int i = 0; i < this.questTypeStatus.Length; i++)
				{
					if(this.questTypeStatus[i].Check())
					{
						if(Needed.One == this.needed)
						{
							return true;
						}
					}
					else if(Needed.All == this.needed)
					{
						return false;
					}
				}
				if(Needed.All == this.needed)
				{
					return true;
				}
				else
				{
					return false;
				}
			}
			else
			{
				return true;
			}
		}
	}
}
