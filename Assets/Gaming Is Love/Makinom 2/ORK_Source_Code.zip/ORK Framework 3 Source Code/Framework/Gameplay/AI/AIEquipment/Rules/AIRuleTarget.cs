﻿
using UnityEngine;
using GamingIsLove.ORKFramework;
using System.Collections.Generic;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework.AI
{
	public class AIRuleTarget : BaseData
	{
		[EditorHelp("Bind To Ruleset", "Only affect the targets of actions of this AI ruleset.\n" +
			"I.e. if an 'Action' or 'Battle AI' rule finds a usable action, it'll use this target rule.\n" +
			"If disabled, the targets of all AI actions will be affected by this rule.", "")]
		public bool bindToRuleset = false;

		[EditorHelp("Target Type", "Select which group will be the target:\n" +
			"- Self: The user is the target.\n" +
			"- Ally: The target is in an allied group of the user.\n" +
			"- Enemy: The target is in an enemy group.\n" +
			"- All: All combatant's are possible targets.\n" +
			"- Member Target: The target of a group member.\n" +
			"- Targeting Member: Enemies targeting a group member.", "")]
		public AIRuleTargetType targetType = AIRuleTargetType.Enemy;


		// ally target/targeting
		[EditorFoldout("Member", "Select the group member that will be used.\n" +
			"When using 'Member Target', the selected member's current/last target will be used.\n" +
			"When using 'Targeting Member', enemies targeting the selected member will be used.", "")]
		[EditorEndFoldout]
		[EditorCondition("targetType", AIRuleTargetType.MemberTarget)]
		[EditorCondition("targetType", AIRuleTargetType.TargetingMember)]
		[EditorEndCondition]
		[EditorAutoInit]
		public GroupMemberSelection memberSelection;


		// target requirements
		[EditorHelp("Is Use Requirement", "This rule is also a use requirement for 'Action' and 'Battle AI' rules of this ruleset.\n" +
			"I.e. the ruleset will only use actions if targets with the defined requirements are found.", "")]
		[EditorFoldout("Target Conditions", "Select targets based on valid conditions, e.g. combatant status or variable conditions.\n" +
			"The combatant using the AI ruleset is used for the checks.", "")]
		[EditorCondition("targetConditions.Has", true)]
		[EditorEndCondition]
		public bool isUseRequirement = false;

		[EditorSeparator]
		[EditorEndFoldout]
		public CombatantGeneralConditionSettings targetConditions = new CombatantGeneralConditionSettings();

		public AIRuleTarget()
		{

		}

		public bool CheckRequirements(Combatant user, List<Combatant> allies, List<Combatant> enemies)
		{
			if(AIRuleTargetType.Self == this.targetType)
			{
				return this.targetConditions.Check(user);
			}
			else if(AIRuleTargetType.Ally == this.targetType)
			{
				for(int i = 0; i < allies.Count; i++)
				{
					if(this.targetConditions.Check(allies[i]))
					{
						return true;
					}
				}
			}
			else if(AIRuleTargetType.Enemy == this.targetType)
			{
				for(int i = 0; i < enemies.Count; i++)
				{
					if(this.targetConditions.Check(enemies[i]))
					{
						return true;
					}
				}
			}
			else if(AIRuleTargetType.All == this.targetType)
			{
				for(int i = 0; i < allies.Count; i++)
				{
					if(this.targetConditions.Check(allies[i]))
					{
						return true;
					}
				}
				for(int i = 0; i < enemies.Count; i++)
				{
					if(this.targetConditions.Check(enemies[i]))
					{
						return true;
					}
				}
			}
			else if(AIRuleTargetType.MemberTarget == this.targetType)
			{
				Combatant member = this.memberSelection.GetBattleGroupMember(user);

				if(member != null)
				{
					for(int i = 0; i < member.Battle.LastTargets.Count; i++)
					{
						if(member.Battle.LastTargets[i] != null &&
							this.targetConditions.Check(member.Battle.LastTargets[i]))
						{
							return true;
						}
					}
				}
			}
			else if(AIRuleTargetType.TargetingMember == this.targetType)
			{
				Combatant member = this.memberSelection.GetBattleGroupMember(user);

				if(member != null)
				{
					for(int i = 0; i < enemies.Count; i++)
					{
						if(enemies[i].Battle.LastTargets.Contains(member) &&
							this.targetConditions.Check(enemies[i]))
						{
							return true;
						}
					}
				}
			}
			return false;
		}

		public bool SetActionTargets(BaseAction action, Combatant user, List<Combatant> allies, List<Combatant> enemies)
		{
			TargetSelectionSettings targetSettings = TargetSelectionSettings.Get(action);

			if(targetSettings != null)
			{
				List<Combatant> targets = new List<Combatant>();
				if(AIRuleTargetType.Self == this.targetType)
				{
					if(this.targetConditions.Check(user) &&
						targetSettings.CanTarget(user, user))
					{
						targets.Add(user);
					}
				}
				else if(AIRuleTargetType.Ally == this.targetType)
				{
					for(int i = 0; i < allies.Count; i++)
					{
						if(this.targetConditions.Check(allies[i]) &&
							targetSettings.CanTarget(user, allies[i]))
						{
							targets.Add(allies[i]);
						}
					}
				}
				else if(AIRuleTargetType.Enemy == this.targetType)
				{
					for(int i = 0; i < enemies.Count; i++)
					{
						if(this.targetConditions.Check(enemies[i]) &&
							targetSettings.CanTarget(user, enemies[i]))
						{
							targets.Add(enemies[i]);
						}
					}
				}
				else if(AIRuleTargetType.All == this.targetType)
				{
					for(int i = 0; i < allies.Count; i++)
					{
						if(this.targetConditions.Check(allies[i]) &&
							targetSettings.CanTarget(user, allies[i]))
						{
							targets.Add(allies[i]);
						}
					}
					for(int i = 0; i < enemies.Count; i++)
					{
						if(this.targetConditions.Check(enemies[i]) &&
							targetSettings.CanTarget(user, enemies[i]))
						{
							targets.Add(enemies[i]);
						}
					}
				}
				else if(AIRuleTargetType.MemberTarget == this.targetType)
				{
					Combatant member = this.memberSelection.GetBattleGroupMember(user);

					if(member != null)
					{
						for(int i = 0; i < member.Battle.LastTargets.Count; i++)
						{
							if(member.Battle.LastTargets[i] != null &&
								this.targetConditions.Check(member.Battle.LastTargets[i]) &&
								targetSettings.CanTarget(user, member.Battle.LastTargets[i]))
							{
								targets.Add(member.Battle.LastTargets[i]);
							}
						}
					}
				}
				else if(AIRuleTargetType.TargetingMember == this.targetType)
				{
					Combatant member = this.memberSelection.GetBattleGroupMember(user);

					if(member != null)
					{
						for(int i = 0; i < enemies.Count; i++)
						{
							if(enemies[i].Battle.LastTargets.Contains(member) &&
								this.targetConditions.Check(enemies[i]) &&
								targetSettings.CanTarget(user, enemies[i]))
							{
								targets.Add(enemies[i]);
							}
						}
					}
				}

				if(targets.Count > 0)
				{
					return targetSettings.SetTargets(action as TargetRangeAction, user, targets);
				}
			}
			return false;
		}
	}
}
