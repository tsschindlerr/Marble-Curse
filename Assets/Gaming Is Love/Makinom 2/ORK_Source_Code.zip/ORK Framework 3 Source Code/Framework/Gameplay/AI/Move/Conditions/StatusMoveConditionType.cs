﻿
using UnityEngine;
using GamingIsLove.Makinom;
using System.Collections.Generic;

namespace GamingIsLove.ORKFramework.AI
{
	[EditorSettingInfo("Status", "Advanced status conditions.")]
	public class StatusMoveConditionType : BaseMoveConditionType
	{
		[EditorHelp("Check Self", "Check the user of the move AI instead of the detected target.", "")]
		public bool statusCheckSelf = false;

		[EditorSeparator]
		public StatusCondition statusConditions = new StatusCondition();

		public StatusMoveConditionType()
		{

		}

		public override string ToString()
		{
			return this.statusConditions.ToString();
		}

		public override bool IsValid(Combatant combatant, Combatant target)
		{
			return this.statusConditions.Check(this.statusCheckSelf ? combatant : target);
		}
	}
}
