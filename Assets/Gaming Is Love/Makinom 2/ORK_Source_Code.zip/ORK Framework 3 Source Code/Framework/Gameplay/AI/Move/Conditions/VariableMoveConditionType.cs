﻿
using UnityEngine;
using GamingIsLove.Makinom;
using System.Collections.Generic;

namespace GamingIsLove.ORKFramework.AI
{
	[EditorSettingInfo("Variable", "Check variable conditions.")]
	public class VariableMoveConditionType : BaseMoveConditionType
	{
		[EditorLabel("The user and target are available as 'User' and 'Target' via 'Object' variable origin.")]
		public VariableCondition<GameObjectSelection> variableCondition = new VariableCondition<GameObjectSelection>();

		public VariableMoveConditionType()
		{

		}

		public override string ToString()
		{
			return "Variable";
		}

		public override bool IsValid(Combatant combatant, Combatant target)
		{
			return this.variableCondition.CheckVariables(new DataCall(combatant, target));
		}
	}
}
