﻿
using UnityEngine;
using GamingIsLove.Makinom;
using System.Collections.Generic;

namespace GamingIsLove.ORKFramework.AI
{
	[EditorSettingInfo("Quest Variable", "Check quest variable conditions.")]
	public class QuestVariableMoveConditionType : BaseMoveConditionType
	{
		[EditorHelp("Quest", "Select the quest that will be checked.\n" +
			"The quest has to be added to the player's quest list.", "")]
		public AssetSelection<QuestAsset> quest = new AssetSelection<QuestAsset>();

		[EditorLabel("Use 'Local' variable origin to check variables of the quest instance.")]
		public VariableCondition<GameObjectSelection> variableCondition = new VariableCondition<GameObjectSelection>();

		public QuestVariableMoveConditionType()
		{

		}

		public override string ToString()
		{
			return "Quest Variable";
		}

		public override bool IsValid(Combatant combatant, Combatant target)
		{
			if(this.quest.StoredAsset != null)
			{
				Quest questInstance = ORK.Game.Quests.GetQuest(this.quest.StoredAsset.Settings);
				if(questInstance != null)
				{
					return this.variableCondition.CheckVariables(new DataCall(ORK.Game.ActiveGroup.Leader,
						questInstance.HasVariables ? questInstance.Variables : null,
						questInstance.GetSelectedData()));
				}
			}
			return false;
		}
	}
}
