﻿
using UnityEngine;
using GamingIsLove.ORKFramework;
using System.Collections.Generic;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework.AI
{
	public class AIRule : BaseData, IFoldoutInfo
	{
		[EditorHelp("Rule Type", "Select the type of this rule:\n" +
			"- Action: Perform an action (used before AI behaviour).\n" +
			"- Battle AI: Use battle AIs to find an action (used before AI behaviour).\n" +
			"- Block Ability: Blocks defined abilities or ability types from being used.\n" +
			"- Block Attack: Blocks the base attack from being used.\n" +
			"- Block Counter Attack: Blocks the counter attack from being used (as an AI action, not countering).\n" +
			"- Block Item: Blocks defined items or item types from being used.\n" +
			"- Target: Changes the target of used actions.\n" +
			"- Move AI: Changes the used move AI or use mode.", "")]
		public AIRuleType type = AIRuleType.Action;


		// action
		[EditorSeparator]
		[EditorCondition("type", AIRuleType.Action)]
		[EditorEndCondition]
		[EditorAutoInit]
		public AIRuleAction action;

		// battle AI
		[EditorSeparator]
		[EditorCondition("type", AIRuleType.BattleAI)]
		[EditorEndCondition]
		[EditorAutoInit]
		public AIRuleBattleAI battleAI;

		// block ability
		[EditorSeparator]
		[EditorCondition("type", AIRuleType.BlockAbility)]
		[EditorEndCondition]
		[EditorAutoInit]
		public AIRuleBlockAbility blockAbility;

		// block item
		[EditorSeparator]
		[EditorCondition("type", AIRuleType.BlockItem)]
		[EditorEndCondition]
		[EditorAutoInit]
		public AIRuleBlockItem blockItem;

		// target
		[EditorSeparator]
		[EditorCondition("type", AIRuleType.Target)]
		[EditorEndCondition]
		[EditorAutoInit]
		public AIRuleTarget target;

		// target
		[EditorSeparator]
		[EditorCondition("type", AIRuleType.MoveAI)]
		[EditorEndCondition]
		[EditorAutoInit]
		public AIRuleMoveAI moveAI;

		public AIRule()
		{

		}

		public virtual string GetFoldoutInfo()
		{
			if(AIRuleType.Action == this.type)
			{
				return "Action: " + this.action.actionSettings.ToString();
			}
			else if(AIRuleType.BattleAI == this.type)
			{
				return "Battle AI";
			}
			else if(AIRuleType.BlockAbility == this.type)
			{
				return "Block Ability";
			}
			else if(AIRuleType.BlockAttack == this.type)
			{
				return "Block Attack";
			}
			else if(AIRuleType.BlockCounterAttack == this.type)
			{
				return "Block Counter Attack";
			}
			else if(AIRuleType.BlockItem == this.type)
			{
				return "Block Item";
			}
			else if(AIRuleType.Target == this.type)
			{
				return "Target";
			}
			else if(AIRuleType.MoveAI == this.type)
			{
				return "Move AI";
			}
			return this.type.ToString();
		}
	}
}
