
using GamingIsLove.ORKFramework;
using UnityEngine;
using UnityEditor;
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.Editor;

namespace GamingIsLove.ORKFramework.Editor
{
	public sealed class BattleTextsTab : ORKBaseEditorTab
	{
		public BattleTextsTab(MakinomEditorWindow parent)
		{
			this.parent = parent;

			this.DefaultSetup();
		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public override string Name
		{
			get { return "Battle Texts"; }
		}

		public override string HelpText
		{
			get { return "Set up different battle informations and default flying texts."; }
		}

		public override string HelpInfo
		{
			get { return "https://orkframework.com/guide/documentation/battles/battle-texts/"; }
		}

		protected override BaseSettings Settings
		{
			get { return ORK.BattleTexts; }
		}

		protected override IBaseData DisplayedSettings
		{
			get { return ORK.BattleTexts; }
		}
	}
}

