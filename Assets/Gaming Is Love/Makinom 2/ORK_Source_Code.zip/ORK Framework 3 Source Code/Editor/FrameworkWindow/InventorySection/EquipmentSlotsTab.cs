
using UnityEditor;
using UnityEngine;
using GamingIsLove.ORKFramework;
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.Editor;

namespace GamingIsLove.ORKFramework.Editor
{
	public sealed class EquipmentSlotsTab : ORKGenericAssetListTab<EquipmentSlotAsset, EquipmentSlotSetting>
	{
		public EquipmentSlotsTab(MakinomEditorWindow parent) : base(parent)
		{
			ORK.EquipmentSlots.SetAssets(this.assetList.Assets);
		}

		public override void Reloaded()
		{
			base.Reloaded();
			ORK.EquipmentSlots.SetAssets(this.assetList.Assets);
		}

		public override void DefaultSetup()
		{
			if(this.assetList.Assets.Count == 0)
			{
				this.assetList.Add(EquipmentSlotsTab.CreateAsset("Weapon"));
				this.assetList.Add(EquipmentSlotsTab.CreateAsset("Shield"));
				this.assetList.Add(EquipmentSlotsTab.CreateAsset("Armor"));
				this.assetList.Add(EquipmentSlotsTab.CreateAsset("Helmet"));
				this.assetList.Add(EquipmentSlotsTab.CreateAsset("Shoes"));
				this.assetList.Add(EquipmentSlotsTab.CreateAsset("Accessory"));
			}
		}

		private static EquipmentSlotAsset CreateAsset(string name)
		{
			EquipmentSlotAsset asset = ScriptableObject.CreateInstance<EquipmentSlotAsset>();
			asset.Settings = new EquipmentSlotSetting(name);
			return asset;
		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public override string Name
		{
			get { return "Equipment Slots"; }
		}

		public override string HelpText
		{
			get
			{
				return "Equipment slots are used to equip equipment.";
			}
		}

		public override string HelpInfo
		{
			get { return "https://orkframework.com/guide/documentation/inventory/equipment/"; }
		}
	}
}

