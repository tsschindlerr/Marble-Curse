﻿
using UnityEditor;
using UnityEngine;
using GamingIsLove.ORKFramework.AI;
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.Editor;

namespace GamingIsLove.ORKFramework.Editor
{
	public sealed class AIBehavioursTab : ORKGenericAssetListTab<AIBehaviourAsset, AIBehaviour>
	{
		public AIBehavioursTab(MakinomEditorWindow parent) : base(parent)
		{
			ORK.AIBehaviours.SetAssets(this.assetList.Assets);
		}

		public override void Reloaded()
		{
			base.Reloaded();
			ORK.AIBehaviours.SetAssets(this.assetList.Assets);
		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public override string Name
		{
			get { return "AI Behaviours"; }
		}

		public override string HelpText
		{
			get
			{
				return "AI behaviours are used to create equippable battle AIs.";
			}
		}

		public override string HelpInfo
		{
			get { return "https://orkframework.com/guide/documentation/inventory/ai-behaviours-rulesets/"; }
		}

		public override string GeneralSettingsHelpText
		{
			get
			{
				return "Set up general settings that are used by all AI behaviours.\n" +
					"E.g. content information used for AI behaviour slots.";
			}
		}

		protected override BaseSettings Settings
		{
			get { return ORK.AIBehaviours; }
		}

		protected override IBaseData DisplayedSettings
		{
			get
			{
				if(this.index == -1)
				{
					return ORK.AIBehaviours;
				}
				return base.DisplayedSettings;
			}
		}


		/*
		============================================================================
		Filter functions
		============================================================================
		*/
		protected override FilteredList Filter
		{
			get
			{
				if(this.filter == null)
				{
					this.filter = new FilteredList(this,
						new FilteredListAssetSelection<AITypeAsset, AIType>(
							new string[] { "AI Type", "Filter the AI behaviour list by AI type.", "" }),
						new FilteredListAssetSelection<ItemTypeAsset, ItemType>(
							new string[] { "Item Type", "Filter the AI behaviour list by item type.", "" }));
				}
				return this.filter;
			}
		}

		protected override bool CheckFilterCondition(int index)
		{
			if(this.Filter.assetFilterSelection[0].UseFilter)
			{
				AIType type = this.Filter.assetFilterSelection[0].Selection as AIType;
				if(this.assetList.Assets[index].Settings.IsType(type, false))
				{
					if(this.Filter.assetFilterSelection[1].UseFilter)
					{
						ItemType type2 = this.Filter.assetFilterSelection[1].Selection as ItemType;
						return this.assetList.Assets[index].Settings.IsItemType(type2, false);
					}
					return true;
				}
				return false;
			}
			else if(this.Filter.assetFilterSelection[1].UseFilter)
			{
				ItemType type = this.Filter.assetFilterSelection[1].Selection as ItemType;
				return this.assetList.Assets[index].Settings.IsItemType(type, false);
			}
			return true;
		}
	}
}
