
using GamingIsLove.ORKFramework;
using UnityEditor;
using UnityEngine;
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.Editor;

namespace GamingIsLove.ORKFramework.Editor
{
	public sealed class ItemsTab : ORKGenericAssetListTab<ItemAsset, Item>
	{
		public ItemsTab(MakinomEditorWindow parent) : base(parent)
		{
			ORK.Items.SetAssets(this.assetList.Assets);
		}

		public override void Reloaded()
		{
			base.Reloaded();
			ORK.Items.SetAssets(this.assetList.Assets);
		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public override string Name
		{
			get { return "Items"; }
		}

		public override string HelpText
		{
			get
			{
				return "Items are used in battles, the field, in quests, etc.";
			}
		}

		public override string HelpInfo
		{
			get { return "https://orkframework.com/guide/documentation/inventory/items/"; }
		}


		/*
		============================================================================
		Filter functions
		============================================================================
		*/
		protected override FilteredList Filter
		{
			get
			{
				if(this.filter == null)
				{
					this.filter = new FilteredList(this,
						new FilteredListAssetSelection<ItemTypeAsset, ItemType>(
							new string[] { "Item Type", "Filter the item list by item type.", "" }));
				}
				return this.filter;
			}
		}

		protected override bool CheckFilterCondition(int index)
		{
			if(this.Filter.assetFilterSelection[0].UseFilter)
			{
				ItemType type = this.Filter.assetFilterSelection[0].Selection as ItemType;
				return this.assetList.Assets[index].Settings.IsType(type, false);
			}
			return true;
		}
	}
}
