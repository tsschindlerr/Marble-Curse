
using GamingIsLove.ORKFramework;
using UnityEditor;
using UnityEngine;
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.Editor;

namespace GamingIsLove.ORKFramework.Editor
{
	public sealed class FactionBenefitsTab : ORKGenericAssetListTab<FactionBenefitAsset, FactionBenefit>
	{
		public FactionBenefitsTab(MakinomEditorWindow parent) : base(parent)
		{

		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public override string Name
		{
			get { return "Faction Benefits"; }
		}

		public override string HelpText
		{
			get
			{
				return "Faction benefits can be used to impact how factions interact with each other based on their sympathy for each other.";
			}
		}

		public override string HelpInfo
		{
			get { return "https://orkframework.com/guide/documentation/features/factions/"; }
		}
	}
}

