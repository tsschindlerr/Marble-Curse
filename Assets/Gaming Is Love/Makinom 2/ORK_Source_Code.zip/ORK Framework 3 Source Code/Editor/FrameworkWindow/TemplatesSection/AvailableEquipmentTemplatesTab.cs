﻿
using UnityEditor;
using UnityEngine;
using GamingIsLove.ORKFramework;
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.Editor;
using System.Collections.Generic;

namespace GamingIsLove.ORKFramework.Editor
{
	public class AvailableEquipmentTemplatesTab : ORKGenericAssetListTab<AvailableEquipmentTemplateAsset, AvailableEquipmentTemplate>
	{
		public AvailableEquipmentTemplatesTab(MakinomEditorWindow parent) : base(parent)
		{

		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public override string Name
		{
			get { return "Available Equipment Templates"; }
		}

		public override string HelpText
		{
			get
			{
				return "Available equipment templates can be used by combatants and classes " +
					"to define which equipment slots and equipment will be available to the combatant.";
			}
		}

		public override string HelpInfo
		{
			get { return "https://orkframework.com/guide/documentation/inventory/equipment/"; }
		}
	}
}

