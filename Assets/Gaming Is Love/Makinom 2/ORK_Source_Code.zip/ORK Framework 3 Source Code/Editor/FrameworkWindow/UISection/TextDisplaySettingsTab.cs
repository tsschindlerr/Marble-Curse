﻿
using GamingIsLove.ORKFramework;
using UnityEngine;
using UnityEditor;
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.Editor;

namespace GamingIsLove.ORKFramework.Editor
{
	public sealed class TextDisplaySettingsTab : ORKBaseEditorTab
	{
		public TextDisplaySettingsTab(MakinomEditorWindow parent)
		{
			this.parent = parent;

			this.DefaultSetup();
		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public override string Name
		{
			get { return "Text Display Settings"; }
		}

		public override string HelpText
		{
			get { return "Set up default text representation for use costs, status bonuses and other things."; }
		}

		public override string HelpInfo
		{
			get { return "https://orkframework.com/guide/documentation/ui-system/text-display-settings/"; }
		}

		protected override BaseSettings Settings
		{
			get { return ORK.TextDisplaySettings; }
		}

		protected override IBaseData DisplayedSettings
		{
			get { return ORK.TextDisplaySettings; }
		}


		/*
		============================================================================
		Automation functions
		============================================================================
		*/
		public override void AutomationCallback(string info)
		{
			if(info == "button:ResetTextFormats")
			{
				if(EditorTool.Button("Reset Formats", "Reset all number formats to their default values.", ""))
				{
					ORK.TextDisplaySettings.numberFormatting.Reset();
				}
				EditorGUILayout.Separator();
			}
			else
			{
				base.AutomationCallback(info);
			}
		}
	}
}
