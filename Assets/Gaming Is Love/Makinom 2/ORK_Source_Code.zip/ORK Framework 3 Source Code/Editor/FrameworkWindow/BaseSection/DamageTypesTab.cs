
using UnityEditor;
using UnityEngine;
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.Editor;
using GamingIsLove.ORKFramework.Animations;

namespace GamingIsLove.ORKFramework.Editor
{
	public class DamageTypesTab : ORKGenericAssetListTab<DamageTypeAsset, DamageType>
	{
		public DamageTypesTab(MakinomEditorWindow parent) : base(parent)
		{

		}

		public override void DefaultSetup()
		{
			base.DefaultSetup();
			if(Maki.Data.ProjectAsset.IsEmpty && 
				this.assetList.Assets.Count > 0)
			{
				GenericAssetList<AnimationTypeAsset> animationTypes = EditorDataHandler.Instance.GetAssets<AnimationTypeAsset>();
				this.assetList.Assets[0].Settings.damageAnimationType.Source.EditorAsset = animationTypes.GetAssetAt(7) as AnimationTypeAsset;
				this.assetList.Assets[0].Settings.criticalDamageAnimationType.Source.EditorAsset = animationTypes.GetAssetAt(7) as AnimationTypeAsset;
				this.assetList.Assets[0].Settings.evadeAnimationType.Source.EditorAsset = animationTypes.GetAssetAt(8) as AnimationTypeAsset;
			}
		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public override string Name
		{
			get { return "Damage Types"; }
		}

		public override string HelpText
		{
			get
			{
				return "Damage types are used to define the damage, evade and block animations that are used by targets of abilities and items.";
			}
		}

		public override string HelpInfo
		{
			get { return "https://orkframework.com/guide/documentation/features/damage-types/"; }
		}
	}
}

