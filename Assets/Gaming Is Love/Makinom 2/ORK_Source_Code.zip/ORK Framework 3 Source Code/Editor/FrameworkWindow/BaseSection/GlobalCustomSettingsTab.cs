﻿
using UnityEditor;
using UnityEngine;
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.Editor;

namespace GamingIsLove.ORKFramework.Editor
{
	public class GlobalCustomSettingsTab : ORKGenericAssetListTab<GlobalCustomSettingsAsset, GlobalCustomSettings>
	{
		public GlobalCustomSettingsTab(MakinomEditorWindow parent) : base(parent)
		{
			ORK.GlobalCustomSettings.SetAssets(this.assetList.Assets);
		}

		public override void Reloaded()
		{
			base.Reloaded();
			ORK.GlobalCustomSettings.SetAssets(this.assetList.Assets);
		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public override string Name
		{
			get { return "Global Custom Settings"; }
		}

		public override string HelpText
		{
			get
			{
				return "Global custom settings are an easy way to add custom systems to the project by extending from the 'BaseGlobalCustomSettingsType' class.\n" +
					"Their data can be saved/loaded with save games and functionality called via schematics ('Use Global Custom Settings' node).\n" +
					"See the built-in 'DebugGlobalCustomSettingsType' class for an example implementation.";
			}
		}

		public override string HelpInfo
		{
			get { return "https://orkframework.com/guide/documentation/scripting/custom-settings/"; }
		}
	}
}
