﻿
using UnityEngine;
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.Editor;
using GamingIsLove.ORKFramework.Components;
using System.Collections.Generic;

namespace GamingIsLove.ORKFramework.Editor
{
	[EditorSettingInfo("Item Collector", "")]
	public class SceneWizard_CreateObject_ItemCollector : SceneWizard_BaseCreateObject
	{
		public static void Use()
		{
			ORKUnityMenuUtility.CreateItemCollector(null);
		}
	}

	[EditorSettingInfo("Shop Interaction", "")]
	public class SceneWizard_CreateObject_ShopInteraction : SceneWizard_BaseCreateObject
	{
		public static void Use()
		{
			ORKUnityMenuUtility.CreateShopInteraction(null);
		}
	}

	[EditorSettingInfo("Battle 2D", "")]
	public class SceneWizard_CreateObject_Battle2D : SceneWizard_BaseCreateObject
	{
		public static void Use()
		{
			ORKUnityMenuUtility.CreateBattle2D(null);
		}
	}

	[EditorSettingInfo("Battle 3D", "")]
	public class SceneWizard_CreateObject_Battle3D : SceneWizard_BaseCreateObject
	{
		public static void Use()
		{
			ORKUnityMenuUtility.CreateBattle3D(null);
		}
	}

	[EditorSettingInfo("Battle (None)", "")]
	public class SceneWizard_CreateObject_BattleNone : SceneWizard_BaseCreateObject
	{
		public static void Use()
		{
			ORKUnityMenuUtility.CreateBattleNone(null);
		}
	}

	[EditorSettingInfo("Random Battle Area 2D", "")]
	public class SceneWizard_CreateObject_RandomBattleArea2D : SceneWizard_BaseCreateObject
	{
		public static void Use()
		{
			ORKUnityMenuUtility.CreateRandomBattleArea2D(null);
		}
	}

	[EditorSettingInfo("Random Battle Area 3D", "")]
	public class SceneWizard_CreateObject_RandomBattleArea3D : SceneWizard_BaseCreateObject
	{
		public static void Use()
		{
			ORKUnityMenuUtility.CreateRandomBattleArea3D(null);
		}
	}

	[EditorSettingInfo("Real Time Battle Area (Scene)", "")]
	public class SceneWizard_CreateObject_RealTimeBattleArea : SceneWizard_BaseCreateObject
	{
		public static void Use()
		{
			ORKUnityMenuUtility.CreateRealTimeBattleArea(null);
		}
	}

	[EditorSettingInfo("Real Time Battle Area 2D", "")]
	public class SceneWizard_CreateObject_RealTimeBattleArea2D : SceneWizard_BaseCreateObject
	{
		public static void Use()
		{
			ORKUnityMenuUtility.CreateRealTimeBattleArea2D(null);
		}
	}

	[EditorSettingInfo("Real Time Battle Area 3D", "")]
	public class SceneWizard_CreateObject_RealTimeBattleArea3D : SceneWizard_BaseCreateObject
	{
		public static void Use()
		{
			ORKUnityMenuUtility.CreateRealTimeBattleArea3D(null);
		}
	}

	[EditorSettingInfo("Battle Grid", "")]
	public class SceneWizard_CreateObject_BattleGrid : SceneWizard_BaseCreateObject
	{
		public static void Use()
		{
			ORKUnityMenuUtility.CreateBattleGrid(null);
		}
	}

	[EditorSettingInfo("Combatant Spawner (Single)", "")]
	public class SceneWizard_CreateObject_CombatantSpawner : SceneWizard_BaseCreateObject
	{
		public static void Use()
		{
			ORKUnityMenuUtility.CreateCombatantSpawner(null);
		}
	}

	[EditorSettingInfo("Combatant Spawner 2D", "")]
	public class SceneWizard_CreateObject_CombatantSpawner2D : SceneWizard_BaseCreateObject
	{
		public static void Use()
		{
			ORKUnityMenuUtility.CreateCombatantSpawner2D(null);
		}
	}

	[EditorSettingInfo("Combatant Spawner 3D", "")]
	public class SceneWizard_CreateObject_CombatantSpawner3D : SceneWizard_BaseCreateObject
	{
		public static void Use()
		{
			ORKUnityMenuUtility.CreateCombatantSpawner3D(null);
		}
	}

	[EditorSettingInfo("Area", "")]
	public class SceneWizard_CreateObject_Area : SceneWizard_BaseCreateObject
	{
		public static void Use()
		{
			ORKUnityMenuUtility.CreateArea(null);
		}
	}

	[EditorSettingInfo("Area 2D", "")]
	public class SceneWizard_CreateObject_Area2D : SceneWizard_BaseCreateObject
	{
		public static void Use()
		{
			ORKUnityMenuUtility.CreateArea2D(null);
		}
	}

	[EditorSettingInfo("Area 3D", "")]
	public class SceneWizard_CreateObject_Area3D : SceneWizard_BaseCreateObject
	{
		public static void Use()
		{
			ORKUnityMenuUtility.CreateArea3D(null);
		}
	}

	[EditorSettingInfo("Level Zone (Scene)", "")]
	public class SceneWizard_CreateObject_LevelZone : SceneWizard_BaseCreateObject
	{
		public static void Use()
		{
			ORKUnityMenuUtility.CreateLevelZone(null);
		}
	}

	[EditorSettingInfo("Level Zone 2D", "")]
	public class SceneWizard_CreateObject_LevelZone2D : SceneWizard_BaseCreateObject
	{
		public static void Use()
		{
			ORKUnityMenuUtility.CreateLevelZone2D(null);
		}
	}

	[EditorSettingInfo("Level Zone 3D", "")]
	public class SceneWizard_CreateObject_LevelZone3D : SceneWizard_BaseCreateObject
	{
		public static void Use()
		{
			ORKUnityMenuUtility.CreateLevelZone3D(null);
		}
	}

	[EditorSettingInfo("Block Combatant Spawn 2D", "")]
	public class SceneWizard_CreateObject_BlockCombatantSpawn2D : SceneWizard_BaseCreateObject
	{
		public static void Use()
		{
			ORKUnityMenuUtility.CreateBlockCombatantSpawn2D(null);
		}
	}

	[EditorSettingInfo("Block Combatant Spawn 3D", "")]
	public class SceneWizard_CreateObject_BlockCombatantSpawn3D : SceneWizard_BaseCreateObject
	{
		public static void Use()
		{
			ORKUnityMenuUtility.CreateBlockCombatantSpawn3D(null);
		}
	}

	[EditorSettingInfo("Point of Interest (Move AI)", "")]
	public class SceneWizard_CreateObject_PointOfInterest : SceneWizard_BaseCreateObject
	{
		public static void Use()
		{
			ORKUnityMenuUtility.CreatePointOfInterest(null);
		}
	}

	[EditorSettingInfo("Move AI Area 2D", "")]
	public class SceneWizard_CreateObject_MoveAIArea2D : SceneWizard_BaseCreateObject
	{
		public static void Use()
		{
			ORKUnityMenuUtility.CreateMoveAIArea2D(null);
		}
	}

	[EditorSettingInfo("Move AI Area 3D", "")]
	public class SceneWizard_CreateObject_MoveAIArea3D : SceneWizard_BaseCreateObject
	{
		public static void Use()
		{
			ORKUnityMenuUtility.CreateMoveAIArea3D(null);
		}
	}

	[EditorSettingInfo("Move AI Range 2D", "")]
	public class SceneWizard_CreateObject_MoveAIRange2D : SceneWizard_BaseCreateObject
	{
		public static void Use()
		{
			ORKUnityMenuUtility.CreateMoveAIRange2D(null);
		}
	}

	[EditorSettingInfo("Move AI Range 3D", "")]
	public class SceneWizard_CreateObject_MoveAIRange3D : SceneWizard_BaseCreateObject
	{
		public static void Use()
		{
			ORKUnityMenuUtility.CreateMoveAIRange3D(null);
		}
	}

	[EditorSettingInfo("No Random Patrol 2D", "")]
	public class SceneWizard_CreateObject_NoRandomPatrol2D : SceneWizard_BaseCreateObject
	{
		public static void Use()
		{
			ORKUnityMenuUtility.CreateNoRandomPatrol2D(null);
		}
	}

	[EditorSettingInfo("No Random Patrol 3D", "")]
	public class SceneWizard_CreateObject_NoRandomPatrol3D : SceneWizard_BaseCreateObject
	{
		public static void Use()
		{
			ORKUnityMenuUtility.CreateNoRandomPatrol3D(null);
		}
	}

	[EditorSettingInfo("Camera Border 2D", "")]
	public class SceneWizard_CreateObject_CameraBorder2D : SceneWizard_BaseCreateObject
	{
		public static void Use()
		{
			CameraBorder cameraBorder = SceneObjectHelper.CreateSimple<CameraBorder>("Camera Border");
			ORKUnityMenuUtility.AddBoxTrigger2D(cameraBorder.gameObject);
		}
	}

	[EditorSettingInfo("Camera Border 3D", "")]
	public class SceneWizard_CreateObject_CameraBorder3D : SceneWizard_BaseCreateObject
	{
		public static void Use()
		{
			CameraBorder cameraBorder = SceneObjectHelper.CreateSimple<CameraBorder>("Camera Border");
			ORKUnityMenuUtility.AddBoxTrigger3D(cameraBorder.gameObject);
		}
	}

	[EditorSettingInfo("Combatant Trigger 2D", "")]
	public class SceneWizard_CreateObject_CombatantTrigger2D : SceneWizard_BaseCreateObject
	{
		public static void Use()
		{
			ORKUnityMenuUtility.CreateCombatantTrigger2D(null);
		}
	}

	[EditorSettingInfo("Combatant Trigger 3D", "")]
	public class SceneWizard_CreateObject_CombatantTrigger3D : SceneWizard_BaseCreateObject
	{
		public static void Use()
		{
			ORKUnityMenuUtility.CreateCombatantTrigger3D(null);
		}
	}
}
