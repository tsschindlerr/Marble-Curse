
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.Editor;
using GamingIsLove.ORKFramework;
using GamingIsLove.ORKFramework.Editor;
using GamingIsLove.ORKFramework.Components;
using UnityEditor;
using UnityEngine;
using System.Collections.Generic;

[CustomEditor(typeof(ORKHandler))]
public class ORKHandlerInspector : BaseInspector
{
	public override void OnInspectorGUI()
	{
		this.BaseInit(false);

		if(Application.isPlaying)
		{
			EditorGUILayout.LabelField("Language", Maki.Game.Language.GetName());
			EditorGUILayout.LabelField("Difficulty", ORK.Game.Difficulty.GetName());
			EditorGUILayout.LabelField("Control Maps Blocked", ORK.Control.ControlMapsBlocked.ToString());
			EditorGUILayout.LabelField("Menu Blocked", ORK.Control.MenuBlocked.ToString());
			EditorGUILayout.LabelField("In Menu", ORK.Control.InMenu.ToString());
			EditorGUILayout.LabelField("In Shop", ORK.Control.InShop.ToString());
			EditorGUILayout.LabelField("In Battle", ORK.Control.InBattle.ToString());
			if(ORK.Battle.System != null)
			{
				EditorGUILayout.LabelField("Battle System", ORK.Battle.System.EditorName);
				EditorGUILayout.LabelField("Battle Turn", ORK.Battle.Turn.ToString());
			}


			EditorGUILayout.Separator();
			EditorTool.BoldLabel("Battle Actions");
			EditorGUILayout.LabelField("Queued Actions", ORK.Battle.Actions.ActionCount.ToString());
			EditorGUILayout.LabelField("Casting Actions", ORK.Battle.Actions.CastingCount.ToString());
			EditorGUILayout.LabelField("Active Actions", ORK.Battle.Actions.ActiveCount.ToString());

			// faction infos
			if(this.baseEditor.BeginFoldout("Factions", "", "", false))
			{
				for(int i = 0; i < ORK.Factions.Count; i++)
				{
					FactionSetting faction = ORK.Factions.Get(i);
					EditorTool.BoldLabel(faction.GetName());
					for(int j = 0; j < ORK.Factions.Count; j++)
					{
						if(i != j)
						{
							FactionSetting faction2 = ORK.Factions.Get(j);
							EditorGUILayout.LabelField(faction2.GetName(), ORK.Game.Faction.GetSympathy(faction, faction2).ToString("0.0"));
						}
					}
					EditorGUILayout.Separator();
				}
			}
			this.baseEditor.EndFoldout();
		}
		else
		{
			GUILayout.Label("Shows information while playing.");
		}

		EditorGUILayout.Separator();
	}
}

