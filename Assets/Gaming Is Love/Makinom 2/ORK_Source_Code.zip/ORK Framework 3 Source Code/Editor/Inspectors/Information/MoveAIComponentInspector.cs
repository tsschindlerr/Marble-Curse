
using GamingIsLove.Makinom.Editor;
using GamingIsLove.ORKFramework;
using GamingIsLove.ORKFramework.Editor;
using GamingIsLove.ORKFramework.Components;
using UnityEditor;
using UnityEngine;
using GamingIsLove.Makinom;

[CustomEditor(typeof(MoveAIComponent))]
public class MoveAIComponentInspector : BaseInspector
{
	public override void OnInspectorGUI()
	{
		this.ComponentSetup((MoveAIComponent)target);
	}

	protected virtual void ComponentSetup(MoveAIComponent target)
	{
		this.BaseInit(false);

		EditorGUILayout.LabelField("Move AI", target.settings.name);
		EditorGUILayout.LabelField("Blocked", target.Blocked.ToString());
		EditorGUILayout.LabelField("Can Use", target.CanUse().ToString());
		EditorGUILayout.LabelField("Mode", target.mode.ToString());
		EditorGUILayout.LabelField("Use Mode", target.UseMode.ToString());
		EditorGUILayout.LabelField("Target Position", target.movePosition.ToString());
		if(target.TargetCombatant != null)
		{
			EditorGUILayout.LabelField("Target Combatant", target.TargetCombatant.GetName());
		}
		else
		{
			EditorGUILayout.LabelField("Target Object", target.TargetObject != null ? target.TargetObject.name : "");
		}
		EditorGUILayout.LabelField("Protected Combatant",
			target.ProtectedCombatant != null ?
				target.ProtectedCombatant.GetName() :
				"-");
		EditorGUILayout.LabelField("Point Of Interest",
			target.PointOfInterest != null ?
				target.PointOfInterest.name :
				"-");
		EditorGUILayout.Separator();
	}

	[DrawGizmo(GizmoType.Selected | GizmoType.Active)]
	public static void MoveAIDetectionGizmos(MoveAIComponent moveAI, GizmoType gizmoType)
	{
		if(Application.isPlaying &&
			moveAI != null &&
			moveAI.settings != null &&
			moveAI.settings.useDetection)
		{
			Color tmpColor = Handles.color;
			Color color = Color.red;
			color.a = 0.1f;
			Handles.color = color;
			for(int i = 0; i < moveAI.settings.detection.Length; i++)
			{
				if(MoveDetectionType.Sight == moveAI.settings.detection[i].type ||
					MoveDetectionType.Movement == moveAI.settings.detection[i].type)
				{
					float range = moveAI.settings.detectionRange.GetInRangeDistance(moveAI.Combatant);
					if(moveAI.settings.detection[i].additionalRangeCheck)
					{
						float tmpRange = moveAI.settings.detection[i].range.GetInRangeDistance(moveAI.Combatant);
						if(tmpRange < range)
						{
							range = tmpRange;
						}
					}
					Transform user = moveAI.settings.detection[i].fromChildObject.GetChild(moveAI.Combatant.GameObject.transform);
					Handles.DrawSolidArc(user.position, user.up,
						Quaternion.AngleAxis(-0.5f * moveAI.settings.detection[i].angle + moveAI.settings.detection[i].angleOffset, user.up) * (user.forward - Vector3.Dot(user.forward, user.up) * user.up),
						moveAI.settings.detection[i].angle, range);
				}
			}
			Handles.color = tmpColor;
		}
	}
}

