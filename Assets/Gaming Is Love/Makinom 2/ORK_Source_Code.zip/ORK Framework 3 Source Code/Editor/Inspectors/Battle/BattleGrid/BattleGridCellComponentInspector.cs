﻿
using UnityEditor;
using UnityEngine;
using GamingIsLove.ORKFramework;
using GamingIsLove.ORKFramework.Editor;
using GamingIsLove.ORKFramework.Components;
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.Editor;
using System.Collections.Generic;

[CustomEditor(typeof(BattleGridCellComponent))]
public class BattleGridCellComponentInspector : BattleGridBaseInspector
{
	public override void OnInspectorGUI()
	{
		this.ShowSettings(target as BattleGridCellComponent);
	}

	private void ShowSettings(BattleGridCellComponent target)
	{
		Undo.RecordObject(target, "Change to 'Battle Grid Cell' on " + target.name);
		this.BaseInit(true);

		EditorGUILayout.BeginHorizontal();
		if(EditorTool.Button(new GUIContent("", EditorContent.Instance.NavigateBackIcon)))
		{
			BattleGridCellComponent tmpCell = BattleGridHelper.GetPreviousCell(target);
			if(tmpCell != null)
			{
				Selection.objects = new Object[] { tmpCell.gameObject };
			}
		}
		if(EditorTool.Button(new GUIContent("Select Grid", EditorContent.Instance.EditIcon)))
		{
			Selection.objects = new Object[] { target.parentGrid.gameObject };
		}
		if(EditorTool.Button(new GUIContent("", EditorContent.Instance.NavigateForwardIcon)))
		{
			BattleGridCellComponent tmpCell = BattleGridHelper.GetNextCell(target);
			if(tmpCell != null)
			{
				Selection.objects = new Object[] { tmpCell.gameObject };
			}
		}
		EditorGUILayout.EndHorizontal();

		EditorGUILayout.LabelField("Current Cell Type", target.CellType != null ? target.CellType.GetName() : "-");
		EditorGUILayout.LabelField("Is Override Type", target.CellTypeOverride != null ? "Yes" : "No");
		EditorGUILayout.Separator();
		EditorGUILayout.LabelField("Row", target.row.ToString());
		EditorGUILayout.LabelField("Column", target.column.ToString());

		if(Application.isPlaying)
		{
			if(target.Occupation.singleOccupant)
			{
				EditorGUILayout.LabelField("Occupant", target.MainOccupant != null ? target.MainOccupant.GetName() : "Empty");
			}
			else
			{
				ListAsArray<Combatant> list = target.GetAllyCombatants();
				if(list != null)
				{
					for(int i = 0; i < list.Length; i++)
					{
						EditorGUILayout.LabelField("Ally " + i, list[i] != null ? list[i].GetName() : "Empty");
					}
				}
				list = target.GetEnemyCombatants();
				if(list != null)
				{
					for(int i = 0; i < list.Length; i++)
					{
						EditorGUILayout.LabelField("Enemy " + i, list[i] != null ? list[i].GetName() : "Empty");
					}
				}
			}
			if(target.MarkedForCombatant != null)
			{
				EditorGUILayout.LabelField("Marked For", target.MarkedForCombatant.GetName());
			}
			if(target.MarkedForAI != null)
			{
				EditorGUILayout.LabelField("Marked For AI", target.MarkedForAI.GetName());
			}
			if(target.HasGuests)
			{
				List<Combatant> list = target.GetGuests();
				for(int i = 0; i < list.Count; i++)
				{
					EditorGUILayout.LabelField("Guest " + i, list[i].GetName());
				}
			}
		}


		// grid settings
		this.ShowGridSettings(target);

		EditorAutomation.Automate(target.settings, this.baseEditor);
		if(target.CellType == null ?
			target.settings.cellType.StoredAsset != null : 
			(target.settings.cellType.StoredAsset == null ||
				target.CellType != target.settings.cellType.StoredAsset.Settings))
		{
			target.ClearSettings();
			if(target.PrefabInstance != null)
			{
				GameObject.DestroyImmediate(target.PrefabInstance);
			}
		}

		this.EndSetup();
	}
}
